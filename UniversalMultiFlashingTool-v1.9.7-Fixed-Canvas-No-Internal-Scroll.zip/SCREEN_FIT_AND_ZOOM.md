# Screen Fit, Pinch Zoom and Floating Window — v1.9.0

## Workspace zoom
- The landscape workspace still fits the available viewport automatically at its default scale.
- Use a two-finger pinch gesture to zoom the complete workspace between 0.50× and 2.00×.
- Drag with a finger to pan the magnified workspace; pan is bounded to the zoomed content.
- The header no longer contains zoom plus/minus controls. Maximize resets the workspace to its fitted full-screen view.

## Window controls
- Minimize requests Android's Display over other apps permission if it has not been granted. After permission is granted, tap Minimize again to show a draggable floating tool shortcut above other apps.
- Tap the floating shortcut to restore the app. Its close control dismisses the floating shortcut. A persistent low-importance notification is shown while the overlay service is active.
- Maximize restores the full app workspace and resets pinch zoom/pan.
- Close exits the activity when no flash job is active. If a job is marked active, the close request is blocked and logged rather than silently terminating it.

## Safety and platform notes
- The floating window is a launcher/restore control, not a second interactive flashing workspace. Flashing does not continue as a background task through this overlay service.
- Android requires the user to explicitly grant Display over other apps permission. The service uses a user-visible foreground notification while the overlay is present.
- Some Android versions or OEM power-management settings may restrict overlays or foreground services.

## Verification boundary
- The source-level regression script checks the pinch-zoom gesture, scale bounds, window callbacks, overlay service and absence of page-level scroll containers.
- ZIP integrity and source checks can be run locally. A real Android build, permission flow, overlay appearance, and gesture behavior still require GitHub Actions and device testing.

## Home dashboard readability correction — v1.9.1
- Partition row displays Boot, System, Vendor and Data with 28dp checkbox targets and high-contrast 10sp labels.
- Description panel appears directly below the firmware/device cards and above the primary action buttons.
- Start/Pause/Stop use softened action-only colors; connection/status indicators retain their original semantic colors.


## Readable workspace update — v1.9.6

- Default compact mode is off; the initial workspace uses a larger landscape design scale.
- Workspace fit baseline is now based on 700 × 370 dp and is allowed to scale up to 1.12×.
- Font scale is 1.08× by default; Compact mode remains available in Settings at 0.96×.
- Pinch zoom range is 0.65×–2.50×, with drag-to-pan when magnified.
- Sidebar, header, toolbar tiles, toolbar icons, Home dashboard panels, device illustration,
  partition checkbox targets, firmware picker text, description, log and progress typography
  have been enlarged for readability.
- The Home dashboard remains vertically scrollable so larger content is not forced into
  unreadably small controls on short landscape phone displays.
- The Select Firmware toolbar tile and Firmware File Browse control remain in their existing
  functional locations.
- Sidebar navigation is vertically scrollable to retain access to every destination on
  shorter screens.
