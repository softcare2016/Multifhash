# Focused update report

Only the two requested changes were made to the supplied source archive:

1. Firmware picker now reads the provider's actual `OpenableColumns.DISPLAY_NAME` instead of showing the opaque URI path segment (for example, `msf:10478`). Long names are compacted in the field with the leading filename portion and the original extension retained (for example, `.zip` or `.md5`).
2. The app is requested in portrait orientation in both `AndroidManifest.xml` and `MainActivity`.

No other UI layout, scrolling, pinch-zoom, page sizing, styling, or flashing/program logic was intentionally changed.

## Verification

- Offline Kotlin/JVM simulation: 32 passed, 0 failed.
- Android APK compilation and portrait rendering/touch testing were not available in this environment. Import into Android Studio and install on the target phone to evaluate the portrait experience.
