# Screen Fit and Two-Finger Pan/Zoom — v1.10.2

- App is locked to landscape orientation.
- Main workspace remains a fixed extended canvas with no nested page scrolling.
- Minimum canvas height is 840dp (reduced from 900dp) to trim some lower blank space.
- Outer horizontal inset is 2dp per side to use a little more screen width.
- Two-finger pinch zoom scales the complete workspace from 0.35× to 2.8×.
- While keeping two fingers on screen, moving both fingers pans the workspace in any direction; zoom and pan are applied around the gesture centroid.
- Single-finger interaction remains available for buttons and fields.
- Maximize resets both zoom and pan to the default position.
- Firmware filename display preserves a visible file extension when long names are compacted.

## Verification boundary

Static source checks and the Kotlin/JVM simulation suite are available. APK compilation and real-device touch/layout tests require Android Studio/Gradle and a target device or emulator.
