# UI Reference Audit — v1.7.0

Reference: user-provided `10200.png` (1536 × 1024).

## Main dashboard mapping
| Reference element | v1.7.0 implementation |
|---|---|
| Left lightning logo + product name | Sidebar logo asset and MULTI FLASHING TOOL title |
| Left navigation (Home, All Brands, ADB, Fastboot, Recovery, IMEI, Utilities, Settings, About) | Nine persistent navigation destinations with selected-state glow |
| Header product title, subtitle, version, ready indicator | Header composable with live connection indicator and zoom controls |
| Select Firmware / Open Folder / Options / Refresh / Clear Log | Five toolbar tiles with 3D icon assets and actions |
| Device Connected badge and phone illustration | Animated connection badge driven by USB detection state |
| Firmware & Flash Options | Brand, model, Normal/Force, Boot/Recovery/System/Vendor, firmware picker |
| Device Information | Brand/model/Android/status/battery rows and large phone visual |
| Start Flash / Pause / Stop | Large green/amber/red actions; destructive execution remains safely gated |
| Flash Log / Status | Scrollable timestamped terminal log |
| Progress | Percent, progress bar, elapsed and estimated fields |
| Bottom Ready strip and slogan | Persistent bottom status/footer |

## Secondary pages
- All Brands: searchable manufacturer tiles and selection back to Home.
- ADB Tools: USB interface detection, RSA host identity, authenticated shell_v2 command action and output logging.
- Fastboot Tools: USB detection and selected read-only `getvar` query.
- Recovery Tools: recovery action selector, package information and explicit session/model safety messaging.
- IMEI Tools: read-only identity diagnostics; no IMEI modification.
- Utilities: firmware inspection, checksum display, partition manager safety gate and log/checksum utilities.
- Settings: animation preference, confirmation preference, compact layout and language selector.
- About: application version, capability list and documentation pointers.

## Visual asset set
`icon_logo`, `icon_folder`, `icon_folder_download`, `icon_gear`, `icon_refresh`, `icon_broom`, `icon_home`, `icon_phone`, `icon_android`, `icon_bolt`, `icon_sync`, `icon_fingerprint`, `icon_tools`, `icon_info`, `icon_chip`, `icon_usb`.

## Known boundaries
- Window minimize/maximize/close controls in the desktop reference are intentionally represented by Android title-bar zoom controls; Android apps do not own desktop window controls.
- Example device identity in the reference is contradictory (Pixel 6a in the top badge and Samsung Galaxy A54 in Device Information). The implementation does not fabricate either identity; it uses the single detected USB/protocol identity state.
- Battery and Android version remain unavailable until a protocol-specific device query provides them.
- Full vendor flashing and all hardware operations remain subject to their existing documented support and hardware-validation status.

- v1.8.4 ADB Tools replaces free-form command input with grouped one-tap ADB phone actions and a live result panel; disruptive reboot/power actions are confirmation-gated.
