#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
UI="$ROOT/app/src/main/java/com/universalflasher/app/MainActivity.kt"
MANIFEST="$ROOT/app/src/main/AndroidManifest.xml"

# No nested page scrolling: the workspace is navigated with two-finger transforms.
if grep -En 'verticalScroll|horizontalScroll|rememberScrollState|LazyColumn|LazyRow|\.scrollable\(' "$UI"; then
  echo 'FAIL | scroll modifier/container remains in MainActivity.kt'
  exit 1
fi
grep -Fq 'SCREEN_ORIENTATION_LANDSCAPE' "$UI"
grep -Fq 'android:screenOrientation="landscape"' "$MANIFEST"
grep -Fq 'awaitEachGesture' "$UI"
grep -Fq 'event.changes.count { it.pressed } >= 2' "$UI"
grep -Fq 'val panChange = currentCentroid - previousCentroid' "$UI"
grep -Fq 'val zoomChange = if (previousRadius > 0.5f && currentRadius > 0f)' "$UI"
grep -Fq 'currentRadius / previousRadius' "$UI"
grep -Fq 'translationX = panOffset.x' "$UI"
grep -Fq 'translationY = panOffset.y' "$UI"
grep -Fq 'val canvasHeight = maxOf(maxHeight, 840.dp)' "$UI"
grep -Fq 'Text(compactFirmwareFileName(firmwareName)' "$UI"
grep -Fq 'transformOrigin = TransformOrigin.Center' "$UI"
echo 'PASS | landscape lock; no nested scrolling; manual two-finger centroid pan + radius pinch zoom; 840dp extended canvas; compact filename retains extension'
