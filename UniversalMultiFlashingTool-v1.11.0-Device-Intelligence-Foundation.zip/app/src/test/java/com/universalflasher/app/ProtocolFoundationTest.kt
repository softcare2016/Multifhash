package com.universalflasher.app

import com.universalflasher.app.adb.AdbPacket
import com.universalflasher.app.adb.AdbRsaIdentity
import com.universalflasher.app.jobs.FlashJob
import com.universalflasher.app.jobs.FlashJobState
import com.universalflasher.app.mediatek.ScatterInspector
import com.universalflasher.app.mediatek.BromProtocol
import com.universalflasher.app.qualcomm.SaharaProtocol
import com.universalflasher.app.qualcomm.SaharaProgrammerTransfer
import com.universalflasher.app.qualcomm.FirehoseProtocol
import com.universalflasher.app.qualcomm.FirehoseSession
import com.universalflasher.app.qualcomm.QualcommPackageInspector
import com.universalflasher.app.mediatek.XFlashDaProtocol
import com.universalflasher.app.mediatek.XmlDaProtocol
import com.universalflasher.app.mediatek.XmlDaSession
import com.universalflasher.app.mediatek.BromSession
import com.universalflasher.app.mediatek.DaPackageInspector
import com.universalflasher.app.partition.GptReader
import com.universalflasher.app.partition.GptPartition
import com.universalflasher.app.partition.PartitionService
import com.universalflasher.app.samsung.OdinProtocol
import java.io.ByteArrayInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.zip.CRC32
import org.junit.Assert.*
import org.junit.Test

class ProtocolFoundationTest {
    @Test fun adbPacketRoundTrip() {
        val packet = AdbPacket("CNXN", 0x01000000, 4096, "host::features=shell_v2".toByteArray())
        val encoded = packet.encode()
        val decoded = AdbPacket.decode(encoded.copyOfRange(0,24), encoded.copyOfRange(24,encoded.size))
        assertEquals(packet.command, decoded.command)
        assertArrayEquals(packet.payload, decoded.payload)
    }
    @Test fun jobStateTransitions() {
        val job = FlashJob(); job.queue(100); job.start(); job.checkpoint(40)
        assertEquals(0.4f, job.snapshot().progress, 0.001f)
        job.pause(); job.resume(); job.checkpoint(60); job.succeed()
        assertEquals(FlashJobState.SUCCEEDED, job.snapshot().state)
    }
    @Test fun parsesMtkScatterPartitions() {
        val rows = ScatterInspector.parse("""
            - partition_index: SYS0
              partition_name: boot
              file_name: boot.img
              is_download: true
              linear_start_addr: 0x0
              partition_size: 0x1000
        """.trimIndent())
        assertEquals(1, rows.size)
        assertEquals("boot", rows.first().name)
    }
    @Test fun saharaPacketRoundTripAndReadRequest() {
        val p = SaharaProtocol.Packet(SaharaProtocol.CMD_HELLO, ByteArray(24))
        val decoded = SaharaProtocol.decode(p.encode())
        assertEquals(SaharaProtocol.CMD_HELLO, decoded.command)
        val read = SaharaProtocol.decode(SaharaProtocol.readDataResponse(1, 0x1234, 512))
        assertEquals(SaharaProtocol.CMD_READ_DATA, read.command)
        assertEquals(12, read.payload.size)
    }

    @Test fun mediatekBromBigEndianAddressAndChecksum() {
        assertArrayEquals(byteArrayOf(0,0x20,0x10,0), BromProtocol.be32(0x201000L))
        assertEquals(0x04030201, BromProtocol.checksumXorLeWords(byteArrayOf(1,2,3,4)))
    }

    @Test fun gptReaderChecksHeaderAndEntryCrc() {
        val sector = 512
        val image = ByteArray(sector * 6)
        // One GPT entry at LBA2.
        val entry = ByteArray(128)
        val eb = ByteBuffer.wrap(entry).order(ByteOrder.LITTLE_ENDIAN)
        eb.putInt(0, 0xA2A0D0E5.toInt())
        eb.putLong(32, 3L); eb.putLong(40, 4L)
        "userdata".toByteArray(Charsets.UTF_16LE).copyInto(entry, 56)
        val entriesCrc = CRC32().apply { update(entry) }.value
        entry.copyInto(image, sector * 2)
        val h = image.copyOfRange(sector, sector * 2)
        val hb = ByteBuffer.wrap(h).order(ByteOrder.LITTLE_ENDIAN)
        h[0]='E'.code.toByte(); h[1]='F'.code.toByte(); h[2]='I'.code.toByte(); h[3]=' '.code.toByte()
        h[4]='P'.code.toByte(); h[5]='A'.code.toByte(); h[6]='R'.code.toByte(); h[7]='T'.code.toByte()
        hb.putInt(8, 0x00010000); hb.putInt(12, 92); hb.putInt(16, 0)
        hb.putLong(24, 1); hb.putLong(32, 5); hb.putLong(40, 3); hb.putLong(48, 4)
        hb.putLong(72, 2); hb.putInt(80, 1); hb.putInt(84, 128); hb.putInt(88, entriesCrc.toInt())
        val headerCrc = CRC32().apply { update(h.copyOfRange(0,92)) }.value
        hb.putInt(16, headerCrc.toInt())
        h.copyInto(image, sector)
        val report = GptReader.readReport(ByteArrayInputStream(image))
        assertTrue(report.headerCrcValid); assertTrue(report.entriesCrcValid)
        assertEquals("userdata", report.partitions.single().name)
        assertEquals(2L, report.partitions.single().sectorCount)
    }

    @Test fun saharaHelloUsesFullWireSize() {
        assertEquals(48, SaharaProtocol.helloResponse(2,1).size)
        val hello = SaharaProtocol.Packet(SaharaProtocol.CMD_HELLO, ByteArray(40))
        assertEquals(40, SaharaProtocol.parseHello(hello).let { 40 })
    }

    @Test fun firehoseCommandAndResponseValidation() {
        val xml=String(FirehoseProtocol.programXml("boot.img", 64, 2048, 0, 512), Charsets.UTF_8)
        assertTrue(xml.contains("start_sector=\"64\""))
        assertEquals("ACK", FirehoseProtocol.parseResponse("<data><response value=\"ACK\" /></data>").value)
        assertThrows(IllegalArgumentException::class.java) { FirehoseProtocol.programXml("../bad.img",0,1) }
    }

    @Test fun mediatekDaFrameRoundTrip() {
        val payload="<da><command>CMD:START</command></da>"
        val decoded=XmlDaProtocol.decode(XmlDaProtocol.encode(payload))
        assertEquals(payload,decoded.xml)
        val xflash=XFlashDaProtocol.decode(XFlashDaProtocol.encode(byteArrayOf(1,2,3)))
        assertArrayEquals(byteArrayOf(1,2,3),xflash.payload)
    }

    @Test fun qcomRawProgramXmlIsParsedAndPathChecked() {
        val xml="<data><program label=\"boot\" filename=\"boot.img\" start_sector=\"64\" num_partition_sectors=\"2048\" physical_partition_number=\"0\" SECTOR_SIZE_IN_BYTES=\"512\" /></data>"
        val row=QualcommPackageInspector.parseRawProgram(xml.byteInputStream()).single()
        assertEquals("boot",row.label);assertEquals(64L,row.startSector);assertEquals(2048L,row.sectorCount)
        assertThrows(IllegalArgumentException::class.java) { QualcommPackageInspector.parseRawProgram("<data><program filename=\"../bad\" /></data>".byteInputStream()) }
    }

    @Test fun firehosePartitionReadStreamsExactBytes() {
        val raw=ByteArray(512) { (it and 0xff).toByte() }
        val response="<data><response value=\"ACK\" /></data>".toByteArray()
        val inbound=response+raw+response
        val captured=java.io.ByteArrayOutputStream();val destination=java.io.ByteArrayOutputStream()
        val session=FirehoseSession(ByteArrayInputStream(inbound),captured)
        session.readPartitionTo(10,1,destination)
        assertArrayEquals(raw,destination.toByteArray())
        assertTrue(captured.toString("UTF-8").contains("start_sector=\"10\""))
    }

    @Test fun adbRsaPublicKeyUsesAndroidWireSize() {
        val identity=AdbRsaIdentity()
        val line=String(identity.publicKeyLine(),Charsets.US_ASCII)
        val encoded=line.substringBefore(' ')
        assertEquals(524,java.util.Base64.getDecoder().decode(encoded).size)
    }

    @Test fun samsungOdinPacketAndPitParser() {
        val packet=OdinProtocol.encode(OdinProtocol.Request(OdinProtocol.REGION_INIT,0))
        assertEquals(1024,packet.size)
        val pit=ByteBuffer.allocate(28+132).order(ByteOrder.LITTLE_ENDIAN)
        pit.putInt(OdinProtocol.PIT_MAGIC);pit.putInt(1);pit.position(28)
        repeat(9){pit.putInt(if(it==5||it==6)1 else 0)}
        pit.put("userdata".toByteArray());pit.position(28+36+32);pit.put(ByteArray(64))
        val entries=OdinProtocol.parsePit(pit.array())
        assertEquals("userdata",entries.single().partitionName)
    }

    @Test fun partitionBackupUsesFirehoseRawReadAndHash() {
        val raw=ByteArray(512){(it%251).toByte()};val ack="<data><response value=\"ACK\" /></data>".toByteArray()
        val session=FirehoseSession(ByteArrayInputStream(ack+raw+ack),java.io.ByteArrayOutputStream())
        val file=java.io.File.createTempFile("umt-partition",".img")
        try {
            val result=PartitionService.backup(session,GptPartition("boot",8,8,"type"),0,512,file)
            assertEquals(512L,result.bytes);assertEquals(64,result.sha256.length)
            assertArrayEquals(raw,file.readBytes())
        } finally { file.delete() }
    }

    @Test fun saharaProgrammerTransferStateMachineCompletes() {
        val hello=SaharaProtocol.Packet(SaharaProtocol.CMD_HELLO,ByteBuffer.allocate(40).order(ByteOrder.LITTLE_ENDIAN).putInt(2).putInt(1).putInt(4096).putInt(0).putInt(0).putInt(0).putInt(0).putInt(0).putInt(0).putInt(0).array()).encode()
        val read=SaharaProtocol.Packet(SaharaProtocol.CMD_READ_DATA,ByteBuffer.allocate(12).order(ByteOrder.LITTLE_ENDIAN).putInt(0).putInt(0).putInt(4).array()).encode()
        val end=SaharaProtocol.Packet(SaharaProtocol.CMD_END_IMAGE_TX,ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putInt(0).putInt(0).array()).encode()
        val done=SaharaProtocol.Packet(SaharaProtocol.CMD_DONE_RESP,ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(1).array()).encode()
        val file=java.io.File.createTempFile("umt-sahara",".mbn");file.writeBytes(byteArrayOf(9,8,7,6))
        try {
            val output=java.io.ByteArrayOutputStream()
            val transfer=java.io.RandomAccessFile(file,"r").use { SaharaProgrammerTransfer(ByteArrayInputStream(hello+read+end+done),output,it,4096).also { it.run() } }
            assertEquals(SaharaProgrammerTransfer.State.COMPLETE,transfer.state)
            assertEquals(4L,transfer.bytesSent)
        } finally { file.delete() }
    }

    @Test fun mediatekBromSyncUsesInvertedEcho() {
        val input=ByteArrayInputStream(byteArrayOf(0x5f,0xf5.toByte(),0xaf.toByte(),0xfa.toByte()))
        val output=java.io.ByteArrayOutputStream()
        BromSession(input,output).handshake()
        assertArrayEquals(BromProtocol.SYNC_SEQUENCE,output.toByteArray())
    }

    @Test fun mediatekDaContainerSelectsAndExtractsMatchingDa1() {
        val base=0x6c;val entrySize=0xdc;val tableEnd=base+entrySize
        val bytes=ByteArray(tableEnd+16)
        "MTK_DOWNLOAD_AGENT".toByteArray().copyInto(bytes)
        fun put16(o:Int,v:Int){bytes[o]=v.toByte();bytes[o+1]=(v ushr 8).toByte()}
        fun put32(o:Int,v:Long){for(i in 0..3)bytes[o+i]=(v ushr (i*8)).toByte()}
        put32(0x60,4);put32(0x64,0x99886622L);put32(0x68,1)
        put16(base,0xdada);put16(base+2,0x6768);put16(base+4,1);put16(base+6,2);put16(base+0x12,1)
        put32(base+0x14,tableEnd.toLong());put32(base+0x18,16);put32(base+0x1c,0x201000);put32(base+0x20,12);put32(base+0x24,4)
        val container=java.io.File.createTempFile("umt-mtk-da",".bin");val extracted=java.io.File.createTempFile("umt-mtk-da1",".bin")
        try {
            container.writeBytes(bytes)
            val report=DaPackageInspector.inspect(container);val selected=DaPackageInspector.select(report,0x6768,1,2)
            DaPackageInspector.extractDa1(container,selected,extracted)
            assertEquals(16L,extracted.length())
        } finally { container.delete();extracted.delete() }
    }

    @Test fun xmlDaCommandAckIsNulTerminatedAscii() {
        val session=XmlDaSession(ByteArrayInputStream(byteArrayOf('O'.code.toByte(),'K'.code.toByte(),0)),java.io.ByteArrayOutputStream())
        assertEquals("OK",session.readAck())
    }

}
