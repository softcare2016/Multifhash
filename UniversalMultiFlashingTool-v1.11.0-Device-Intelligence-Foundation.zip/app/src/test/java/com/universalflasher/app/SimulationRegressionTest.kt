package com.universalflasher.app

import com.universalflasher.app.adb.AdbPacket
import com.universalflasher.app.jobs.FlashJob
import com.universalflasher.app.jobs.FlashJobState
import com.universalflasher.app.workspace.*
import com.universalflasher.app.detection.DeviceIdentityResolver
import com.universalflasher.app.detection.IdentityEvidenceSource
import com.universalflasher.app.detection.IdentityFact
import com.universalflasher.app.detection.IdentityConfidence
import com.universalflasher.app.firmware.DeviceFirmwareIdentity
import com.universalflasher.app.firmware.FirmwareMetadata
import com.universalflasher.app.firmware.FirmwareCompatibility
import com.universalflasher.app.firmware.CompatibilityStatus
import com.universalflasher.app.engine.FlashPreflight
import com.universalflasher.app.engine.FlashPreflightInput
import com.universalflasher.app.engine.FlashOperation
import com.universalflasher.app.firmware.VendorPackagePlan
import com.universalflasher.app.mediatek.BromProtocol
import com.universalflasher.app.mediatek.ScatterInspector
import com.universalflasher.app.mediatek.XmlDaProtocol
import com.universalflasher.app.partition.GptReader
import com.universalflasher.app.partition.GptPartition
import com.universalflasher.app.partition.PartitionService
import com.universalflasher.app.qualcomm.FirehoseSession
import com.universalflasher.app.qualcomm.QualcommPackageInspector
import com.universalflasher.app.samsung.OdinProtocol
import com.universalflasher.app.samsung.SamsungPackageInspector
import java.io.*
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest
import java.util.zip.CRC32
import org.junit.Assert.*
import org.junit.Test

/** Hardware-free negative/positive fixtures for deterministic regression testing. */
class SimulationRegressionTest {
    private fun ack() = "<data><response value=\"ACK\" /></data>".toByteArray()
    private fun sha(bytes: ByteArray) = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }

    @Test fun adbCorruptChecksumRejected() {
        val packet=AdbPacket("CNXN",1,2,byteArrayOf(1,2,3)).encode();packet[packet.lastIndex]=4
        assertThrows(IllegalArgumentException::class.java) { AdbPacket.decode(packet.copyOfRange(0,24),packet.copyOfRange(24,packet.size)) }
    }
    @Test fun bromNackStopsSession() {
        assertThrows(SecurityException::class.java) { BromProtocol.requireAck(ByteArrayInputStream(byteArrayOf(BromProtocol.NACK.toByte()))) }
    }
    @Test fun scatterOverlapRejected() {
        val text="""
- partition_index: SYS0
  partition_name: boot
  file_name: boot.img
  linear_start_addr: 0x1000
  partition_size: 0x1000
- partition_index: SYS1
  partition_name: system
  file_name: system.img
  linear_start_addr: 0x1800
  partition_size: 0x1000
""".trimIndent()
        assertThrows(IllegalArgumentException::class.java) { ScatterInspector.parse(text) }
    }
    @Test fun xmlDaRejectsTraversal() {
        assertThrows(IllegalArgumentException::class.java) { XmlDaProtocol.readPartitionXml("../userdata","dump.bin") }
    }
    @Test fun firehoseNakRejected() {
        val nak="<data><response value=\"NAK\" /></data>".toByteArray()
        assertThrows(IllegalStateException::class.java) { FirehoseSession(ByteArrayInputStream(nak),ByteArrayOutputStream()).configure() }
    }
    @Test fun firehosePadsPartialSector() {
        val file=File.createTempFile("umt-program", ".img");val output=ByteArrayOutputStream()
        try {
            file.writeBytes(byteArrayOf(1,2,3));FirehoseSession(ByteArrayInputStream(ack()+ack()),output).programFile(file,4)
            val bytes=output.toByteArray();val marker="</data>".toByteArray();val start=(0..bytes.size-marker.size).first { i->marker.indices.all { bytes[i+it]==marker[it] } }+marker.size
            val raw=bytes.copyOfRange(start,bytes.size)
            assertEquals(512,raw.size);assertArrayEquals(byteArrayOf(1,2,3),raw.copyOfRange(0,3));assertTrue(raw.drop(3).all { it==0.toByte() })
        } finally { file.delete() }
    }
    @Test fun firehoseTruncatedReadRejected() {
        assertThrows(IllegalStateException::class.java) { FirehoseSession(ByteArrayInputStream(ack()+ByteArray(4)),ByteArrayOutputStream()).readPartitionTo(0,1,ByteArrayOutputStream()) }
    }
    @Test fun gptHeaderCrcCorruptionRejected() {
        val image=validGptImage();image[512+20]=(image[512+20].toInt() xor 0x55).toByte()
        assertThrows(IllegalArgumentException::class.java) { GptReader.readReport(ByteArrayInputStream(image)) }
    }
    @Test fun gptPartitionOverlapRejected() {
        assertThrows(IllegalArgumentException::class.java) { GptReader.readReport(ByteArrayInputStream(validGptImage(true))) }
    }
    @Test fun samsungTarMd5VerificationAndTamperDetection() {
        val tar=ByteArray(700){(it%251).toByte()};val digest=MessageDigest.getInstance("MD5").digest(tar).joinToString("") { "%02x".format(it) }.toByteArray()
        val file=File.createTempFile("umt-md5", ".tar.md5")
        try { file.writeBytes(tar+digest);assertTrue(SamsungPackageInspector.verifyTarMd5(file).valid);file.writeBytes(tar+"0".repeat(32).toByteArray());assertFalse(SamsungPackageInspector.verifyTarMd5(file).valid) }
        finally { file.delete() }
    }
    @Test fun restoreModelAndDigestGuardsRunBeforeTransport() {
        val output=ByteArrayOutputStream();val session=FirehoseSession(ByteArrayInputStream(byteArrayOf()),output);val file=File.createTempFile("umt-restore", ".img")
        try {
            file.writeBytes(ByteArray(512))
            assertThrows(IllegalArgumentException::class.java) { PartitionService.restore(session,GptPartition("boot",1,1,"type"),0,512,file,false,true,sha(file.readBytes())) }
            assertThrows(IllegalArgumentException::class.java) { PartitionService.restore(session,GptPartition("boot",1,1,"type"),0,512,file,true,true,"0".repeat(64)) }
            assertEquals(0,output.size())
        } finally { file.delete() }
    }
    @Test fun autoDetectDoesNotAssumeQualcomm() {
        assertEquals(VendorFamily.UNKNOWN, DeviceWorkspaceRegistry.forBrand("Auto Detect").vendor)
        assertEquals(ProtocolFamily.UNKNOWN, DeviceWorkspaceRegistry.forBrand("Auto Detect").protocol)
    }
    @Test fun usbDescriptorAloneCannotConfirmExactModel() {
        val result = DeviceIdentityResolver.resolve(listOf(
            IdentityFact("manufacturer", "Samsung", IdentityEvidenceSource.USB_DESCRIPTOR),
            IdentityFact("model", "SM-A546B", IdentityEvidenceSource.USB_DESCRIPTOR)
        ))
        assertFalse(result.exactModelConfirmed)
        assertNull(result.model)
        assertEquals(IdentityConfidence.LOW, result.confidence)
    }
    @Test fun adbEvidenceCanConfirmExactModel() {
        val result = DeviceIdentityResolver.resolve(listOf(
            IdentityFact("manufacturer", "samsung", IdentityEvidenceSource.ADB_PROPERTY),
            IdentityFact("model", "SM-A546B", IdentityEvidenceSource.ADB_PROPERTY),
            IdentityFact("chipset", "Exynos 1380", IdentityEvidenceSource.ADB_PROPERTY)
        ), ProtocolFamily.ADB, true)
        assertTrue(result.exactModelConfirmed)
        assertEquals(VendorFamily.SAMSUNG, result.vendor)
        assertEquals(IdentityConfidence.VERIFIED, result.confidence)
    }
    @Test fun conflictingModelEvidenceWithholdsConfirmation() {
        val result = DeviceIdentityResolver.resolve(listOf(
            IdentityFact("manufacturer", "Google", IdentityEvidenceSource.ADB_PROPERTY),
            IdentityFact("model", "Pixel 6a", IdentityEvidenceSource.ADB_PROPERTY),
            IdentityFact("model", "Pixel 7a", IdentityEvidenceSource.FASTBOOT_VARIABLE)
        ))
        assertFalse(result.exactModelConfirmed)
        assertNull(result.model)
    }
    @Test fun firmwareMismatchBlocksDestructiveOperations() {
        val report = FirmwareCompatibility.evaluate(
            DeviceFirmwareIdentity(model="SM-A546B", codename="a54x", chipset="Exynos 1380", identityVerified=true),
            FirmwareMetadata(model="SM-A546E", codenames=setOf("a54x"), chipset="Exynos 1380", integrityVerified=true, partitionLayoutKnown=true)
        )
        assertEquals(CompatibilityStatus.INCOMPATIBLE, report.status)
        assertFalse(report.destructiveOperationAllowed)
    }
    @Test fun incompleteFirmwareMetadataIsNeverCompatible() {
        val report = FirmwareCompatibility.evaluate(
            DeviceFirmwareIdentity(model="SM-A546B", codename="a54x", chipset="Exynos 1380", identityVerified=true),
            FirmwareMetadata(integrityVerified=true)
        )
        assertEquals(CompatibilityStatus.WARNING, report.status)
        assertFalse(report.destructiveOperationAllowed)
    }
    @Test fun antiRollbackDowngradeIsBlocked() {
        val report = FirmwareCompatibility.evaluate(
            DeviceFirmwareIdentity(model="model-x", codename="board-x", chipset="chip-x", bootloaderRevision=5, antiRollbackIndex=7, identityVerified=true),
            FirmwareMetadata(model="model-x", codenames=setOf("board-x"), chipset="chip-x", minimumBootloaderRevision=4, antiRollbackIndex=6, integrityVerified=true, signatureTrusted=true, partitionLayoutKnown=true)
        )
        assertEquals(CompatibilityStatus.INCOMPATIBLE, report.status)
        assertTrue(report.blockers.any { it.contains("anti-rollback") })
    }
    @Test fun exactFirmwareMatchCanPassCompatibilityGate() {
        val report = FirmwareCompatibility.evaluate(
            DeviceFirmwareIdentity(model="model-x", codename="board-x", chipset="chip-x", boardRevision="rev-a", region="global", bootloaderRevision=5, antiRollbackIndex=7, identityVerified=true),
            FirmwareMetadata(model="model-x", codenames=setOf("board-x"), chipset="chip-x", boardRevisions=setOf("rev-a"), regions=setOf("global"), minimumBootloaderRevision=4, antiRollbackIndex=7, integrityVerified=true, signatureTrusted=true, partitionLayoutKnown=true)
        )
        assertEquals(CompatibilityStatus.COMPATIBLE, report.status)
        assertTrue(report.destructiveOperationAllowed)
    }
    @Test fun dynamicWorkspaceKeepsVendorProfileAfterDisconnect() {
        val active = DeviceWorkspaceRegistry.detect(DeviceEvidence(manufacturer="Samsung", model="SM-A546B", chipset="Exynos 1380", protocol=ProtocolFamily.ODIN_DOWNLOAD, protocolVerified=true))
        val detached = DeviceWorkspaceRegistry.disconnected(active)
        assertEquals(active.profile, detached.profile)
        assertEquals(WorkspaceConnection.DISCONNECTED, detached.connection)
    }
    @Test fun googlePixelUsesFastbootFactoryImageProfile() {
        assertEquals(ProtocolFamily.FASTBOOT, DeviceWorkspaceRegistry.forBrand("Google Pixel").protocol)
    }
    @Test fun unknownUsbEvidenceDoesNotVerifyProtocol() {
        val result = DeviceWorkspaceRegistry.detect(DeviceEvidence(manufacturer="Samsung", usbVid=0x04e8, usbPid=0x6860))
        assertEquals(WorkspaceConnection.DETECTED_UNVERIFIED, result.connection)
    }
    @Test fun destructivePreflightBlocksWithoutProtocolAndAuthorization() {
        val result = FlashPreflight.evaluate(FlashPreflightInput(FlashOperation.FLASH, true, true, true, true, true, false, false, false, true))
        assertFalse(result.allowed)
        assertEquals(3, result.blockers.size)
    }
    @Test fun samsungSlotsNeedBlApAndCscChoice() {
        val plan = VendorPackagePlan.samsung(listOf("BL_x.tar.md5", "AP_x.tar.md5", "HOME_CSC_x.tar.md5"))
        assertTrue(plan.readyForHardwareTransfer)
        assertEquals("HOME_CSC_x.tar.md5", plan.slots.first { it.type == VendorPackagePlan.SamsungSlot.HOME_CSC }.fileName)
    }
    @Test fun xiaomiPackagePlanFiltersTraversal() {
        val plan = VendorPackagePlan.xiaomi(listOf("images/boot.img", "flash_all.bat", "../../evil.sh"))
        assertTrue(plan.files.none { it.contains("..") })
        assertTrue(plan.scripts.contains("flash_all.bat"))
    }
    @Test fun flashJobCancelCompletesAtSafeCheckpoint() {
        val job=FlashJob();job.queue(100);job.start();job.checkpoint(20);job.cancel();job.checkpoint(0)
        assertEquals(FlashJobState.CANCELLED,job.snapshot().state);assertEquals(20L,job.snapshot().completedBytes)
    }
    @Test fun qcomXmlDoctypeAndTraversalRejected() {
        val xxe="<!DOCTYPE data [<!ENTITY x SYSTEM \"file:///etc/passwd\">]><data><program label=\"&x;\" filename=\"boot.img\"/></data>"
        assertThrows(Exception::class.java) { QualcommPackageInspector.parseRawProgram(xxe.byteInputStream()) }
        val traversal="<data><program label=\"boot\" filename=\"../boot.img\"/></data>"
        assertThrows(IllegalArgumentException::class.java) { QualcommPackageInspector.parseRawProgram(traversal.byteInputStream()) }
    }
    @Test fun samsungPitTruncationRejected() {
        val pit=ByteBuffer.allocate(32).order(ByteOrder.LITTLE_ENDIAN).putInt(OdinProtocol.PIT_MAGIC).putInt(1).array()
        assertThrows(IllegalArgumentException::class.java) { OdinProtocol.parsePit(pit) }
    }

    private fun validGptImage(overlap:Boolean=false):ByteArray {
        val sector=512;val image=ByteArray(sector*8);val entry=ByteArray(128);val e=ByteBuffer.wrap(entry).order(ByteOrder.LITTLE_ENDIAN)
        e.putInt(0,0xA2A0D0E5.toInt());e.putLong(32,2);e.putLong(40,if(overlap)4 else 3);"boot".toByteArray(Charsets.UTF_16LE).copyInto(entry,56)
        val entriesCrc=CRC32().apply { update(entry) }.value;entry.copyInto(image,sector*2)
        val h=image.copyOfRange(sector,sector*2);val b=ByteBuffer.wrap(h).order(ByteOrder.LITTLE_ENDIAN);"EFI PART".toByteArray().copyInto(h)
        b.putInt(8,0x00010000);b.putInt(12,92);b.putInt(16,0);b.putLong(24,1);b.putLong(32,7);b.putLong(40,2);b.putLong(48,6);b.putLong(72,2);b.putInt(80,1);b.putInt(84,128);b.putInt(88,entriesCrc.toInt())
        b.putInt(16,CRC32().apply { update(h.copyOfRange(0,92)) }.value.toInt());h.copyInto(image,sector);return image
    }
}
