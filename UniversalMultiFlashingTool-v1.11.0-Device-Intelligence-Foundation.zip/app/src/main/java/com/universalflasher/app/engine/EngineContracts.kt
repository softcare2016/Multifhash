package com.universalflasher.app.engine

enum class EngineState { AVAILABLE, DEVICE_REQUIRED, PARTIAL, NOT_IMPLEMENTED, UNSUPPORTED }
data class EngineCapability(
    val id: String,
    val title: String,
    val state: EngineState,
    val detail: String,
    /** Software-only preparation/validation foundation; excludes live device transport acceptance. */
    val softwareFoundationPercent: Int = 0,
    val hardwareIntegrationPending: Boolean = true
)
object EngineRegistry {
    val capabilities = listOf(
        EngineCapability("workspace", "Dynamic Main Workspace", EngineState.PARTIAL, "Single Home workspace with vendor profile selection, workflow summaries, protocol-evidence model and disconnect persistence; automatic exact identity still requires verified device evidence.", 90),
        EngineCapability("adb", "Android Debug Bridge", EngineState.PARTIAL, "ADB packet codec, RSA AUTH, CNXN negotiation, shell_v2 command catalogue and USB transport adapters are present; Android Keystore/device runtime acceptance remains.", 90),
        EngineCapability("fastboot", "Fastboot", EngineState.PARTIAL, "Fastboot USB transport and read-only getvar diagnostics are present; command coverage and device-specific transfer acceptance remain.", 90),
        EngineCapability("qualcomm", "Qualcomm Sahara / Firehose", EngineState.PARTIAL, "Sahara state machine, programmer digest validation, Firehose command/session, XML inspection, GPT read and guarded partition services are present; worker orchestration and target acceptance remain.", 90),
        EngineCapability("mediatek", "MediaTek BROM / Download Agent", EngineState.PARTIAL, "BROM sync/identify/DA staging, DA digest and SoC checks, scatter/XML DA parsing and command helpers are present; complete device-specific DA storage data-flow and target acceptance remain.", 90),
        EngineCapability("samsung", "Samsung Download Mode", EngineState.PARTIAL, "TAR inventory/MD5 integrity, BL/AP/CP/CSC/HOME_CSC slot planning, Odin/Thor packet foundation and PIT parsing are present; full XMIT transfer and target acceptance remain.", 90),
        EngineCapability("xiaomi", "Xiaomi Fastboot ROM", EngineState.PARTIAL, "Fastboot profile, ROM/script inventory, path safety and model-hint validation are present; Xiaomi-specific flash script execution and device acceptance remain.", 90),
        EngineCapability("vivo", "Vivo Service Workflow", EngineState.PARTIAL, "Vendor-specific profile and offline package inventory/model-hint checks are present; authenticated protocol and write-worker integration remain.", 90),
        EngineCapability("oppo", "Oppo Service Workflow", EngineState.PARTIAL, "Vendor-specific profile and offline package inventory/model-hint checks are present; authenticated protocol and write-worker integration remain.", 90),
        EngineCapability("realme", "Realme Service Workflow", EngineState.PARTIAL, "Vendor-specific profile and offline package inventory/model-hint checks are present; authenticated protocol and write-worker integration remain.", 90),
        EngineCapability("gpt", "GPT Partition Reader", EngineState.PARTIAL, "Primary GPT header/entry CRC, geometry, GUID, bounds, overlap and names validation; backup GPT recovery and live acceptance remain.", 90),
        EngineCapability("jobs", "Flash Job Manager", EngineState.PARTIAL, "Thread-safe lifecycle state machine with progress, pause, cancellation and safe checkpoints; protocol-specific workers still need integration.", 90)
    )
}
