package com.universalflasher.app.engine

/** Hardware-independent safety gate shared by all vendor workflows. */
enum class FlashOperation { INSPECT, VERIFY, READ, BACKUP, WRITE, RESTORE, ERASE, FLASH }

data class FlashPreflightInput(
    val operation: FlashOperation,
    val deviceConnected: Boolean,
    val modelConfirmed: Boolean,
    val chipsetConfirmed: Boolean,
    val firmwareValid: Boolean,
    val partitionMapCompatible: Boolean,
    val protocolVerified: Boolean,
    val programmerOrDaTrusted: Boolean,
    val authorizationSatisfied: Boolean,
    val explicitConfirmation: Boolean
)

data class FlashPreflightResult(val allowed: Boolean, val checks: Map<String, Boolean>, val blockers: List<String>)

object FlashPreflight {
    fun evaluate(input: FlashPreflightInput): FlashPreflightResult {
        val checks = linkedMapOf(
            "Device session" to input.deviceConnected,
            "Exact model" to input.modelConfirmed,
            "Chipset" to input.chipsetConfirmed,
            "Firmware integrity" to input.firmwareValid,
            "Partition compatibility" to input.partitionMapCompatible,
            "Protocol" to input.protocolVerified,
            "Trusted programmer / DA" to input.programmerOrDaTrusted,
            "OEM authorization" to input.authorizationSatisfied,
            "Explicit confirmation" to input.explicitConfirmation
        )
        val requiredKeys = when (input.operation) {
            FlashOperation.INSPECT -> emptySet()
            FlashOperation.VERIFY -> setOf("Firmware integrity", "Partition compatibility")
            FlashOperation.READ -> setOf("Device session", "Exact model", "Chipset", "Protocol", "OEM authorization")
            FlashOperation.BACKUP -> setOf("Device session", "Exact model", "Chipset", "Partition compatibility", "Protocol", "Trusted programmer / DA", "OEM authorization", "Explicit confirmation")
            FlashOperation.WRITE, FlashOperation.RESTORE, FlashOperation.FLASH -> checks.keys
            FlashOperation.ERASE -> setOf("Device session", "Exact model", "Chipset", "Partition compatibility", "Protocol", "Trusted programmer / DA", "OEM authorization", "Explicit confirmation")
        }
        val blockers = requiredKeys.filter { checks[it] != true }.map { "$it check is not satisfied" }
        return FlashPreflightResult(blockers.isEmpty(), checks, blockers)
    }
}
