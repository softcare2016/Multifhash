package com.universalflasher.app.firmware

/** Values are extracted from device evidence and package metadata, never guessed from filenames alone. */
data class DeviceFirmwareIdentity(
    val model: String? = null,
    val codename: String? = null,
    val chipset: String? = null,
    val boardRevision: String? = null,
    val region: String? = null,
    val bootloaderRevision: Long? = null,
    val antiRollbackIndex: Long? = null,
    val identityVerified: Boolean = false
)

data class FirmwareMetadata(
    val model: String? = null,
    val codenames: Set<String> = emptySet(),
    val chipset: String? = null,
    val boardRevisions: Set<String> = emptySet(),
    val regions: Set<String> = emptySet(),
    val minimumBootloaderRevision: Long? = null,
    val antiRollbackIndex: Long? = null,
    val integrityVerified: Boolean = false,
    val signatureTrusted: Boolean = false,
    val partitionLayoutKnown: Boolean = false
)

enum class CompatibilityStatus { COMPATIBLE, WARNING, INCOMPATIBLE, UNKNOWN }

data class CompatibilityReport(
    val status: CompatibilityStatus,
    val checks: Map<String, Boolean?>,
    val blockers: List<String>,
    val warnings: List<String>
) {
    val destructiveOperationAllowed: Boolean get() = status == CompatibilityStatus.COMPATIBLE && blockers.isEmpty()
}

object FirmwareCompatibility {
    fun evaluate(device: DeviceFirmwareIdentity, firmware: FirmwareMetadata): CompatibilityReport {
        val checks = linkedMapOf<String, Boolean?>()
        val blockers = mutableListOf<String>()
        val warnings = mutableListOf<String>()

        checks["Device identity verified"] = device.identityVerified
        if (!device.identityVerified) blockers += "Device identity is not verified."

        checks["Exact model"] = compareRequired(device.model, firmware.model)
        if (checks["Exact model"] == false) blockers += "Firmware model does not match the connected device."
        if (checks["Exact model"] == null) warnings += "Exact model metadata is missing on one or both sides."

        checks["Codename"] = compareSet(device.codename, firmware.codenames)
        if (checks["Codename"] == false) blockers += "Firmware codename does not match the connected device."
        if (checks["Codename"] == null) warnings += "Codename match could not be established."

        checks["Chipset"] = compareRequired(device.chipset, firmware.chipset)
        if (checks["Chipset"] == false) blockers += "Firmware chipset does not match the connected device."
        if (checks["Chipset"] == null) warnings += "Chipset metadata is incomplete."

        checks["Board revision"] = compareSet(device.boardRevision, firmware.boardRevisions)
        if (checks["Board revision"] == false) blockers += "Board revision is incompatible."
        if (checks["Board revision"] == null) warnings += "Board revision compatibility is unverified."

        checks["Region"] = compareSet(device.region, firmware.regions)
        if (checks["Region"] == false) warnings += "Firmware region differs from the device region; verify OEM cross-region support."
        if (checks["Region"] == null) warnings += "Region compatibility is unknown."

        val bootloaderOk = if (device.bootloaderRevision != null && firmware.minimumBootloaderRevision != null)
            device.bootloaderRevision >= firmware.minimumBootloaderRevision else null
        checks["Bootloader revision"] = bootloaderOk
        if (bootloaderOk == false) blockers += "Device bootloader revision is below the firmware minimum."
        if (bootloaderOk == null) warnings += "Bootloader revision compatibility is unknown."

        val rollbackOk = if (device.antiRollbackIndex != null && firmware.antiRollbackIndex != null)
            firmware.antiRollbackIndex >= device.antiRollbackIndex else null
        checks["Anti-rollback"] = rollbackOk
        if (rollbackOk == false) blockers += "Firmware anti-rollback index is lower than the device requirement."
        if (rollbackOk == null) warnings += "Anti-rollback metadata is unavailable; downgrade safety is unverified."

        checks["Integrity verified"] = firmware.integrityVerified
        if (!firmware.integrityVerified) blockers += "Firmware integrity has not been verified."
        checks["Publisher signature trusted"] = firmware.signatureTrusted
        if (!firmware.signatureTrusted) warnings += "A trusted publisher signature has not been established."
        checks["Partition layout known"] = firmware.partitionLayoutKnown
        if (!firmware.partitionLayoutKnown) warnings += "Firmware partition layout has not been fully established."

        val status = when {
            blockers.isNotEmpty() -> CompatibilityStatus.INCOMPATIBLE
            warnings.isNotEmpty() -> CompatibilityStatus.WARNING
            else -> CompatibilityStatus.COMPATIBLE
        }
        return CompatibilityReport(status, checks, blockers, warnings)
    }

    private fun compareRequired(device: String?, firmware: String?): Boolean? {
        if (device.isNullOrBlank() || firmware.isNullOrBlank()) return null
        return normalize(device) == normalize(firmware)
    }

    private fun compareSet(device: String?, firmware: Set<String>): Boolean? {
        if (device.isNullOrBlank() || firmware.isEmpty()) return null
        return firmware.any { normalize(it) == normalize(device) }
    }

    private fun normalize(value: String) = value.trim().lowercase().replace(Regex("\\s+"), "")
}
