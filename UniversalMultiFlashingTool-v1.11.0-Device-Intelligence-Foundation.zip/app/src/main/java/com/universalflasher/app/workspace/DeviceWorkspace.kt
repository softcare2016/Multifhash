package com.universalflasher.app.workspace

/** Software-side device profile selection. A profile is a workflow hint, never proof of protocol support. */
enum class VendorFamily { QUALCOMM, SAMSUNG, XIAOMI, MEDIATEK, GOOGLE_PIXEL, VIVO, OPPO, REALME, GENERIC, UNKNOWN }
enum class ProtocolFamily { SAHARA_FIREHOSE, ODIN_DOWNLOAD, FASTBOOT, MTK_BROM_DA, OEM_AUTHENTICATED, ADB, UNKNOWN }
enum class WorkspaceConnection { NO_DEVICE, DETECTED_UNVERIFIED, CONNECTED_VERIFIED, DISCONNECTED }

data class DeviceEvidence(
    val manufacturer: String = "",
    val model: String = "",
    val chipset: String = "",
    val usbVid: Int? = null,
    val usbPid: Int? = null,
    val mode: String = "",
    val protocol: ProtocolFamily = ProtocolFamily.UNKNOWN,
    val protocolVerified: Boolean = false
)

data class WorkspaceProfile(
    val vendor: VendorFamily,
    val title: String,
    val protocol: ProtocolFamily,
    val workflow: List<String>,
    val hardwareAcceptanceRequired: Boolean = true
)

data class WorkspaceSnapshot(
    val profile: WorkspaceProfile,
    val evidence: DeviceEvidence,
    val connection: WorkspaceConnection,
    val warnings: List<String>
)

object DeviceWorkspaceRegistry {
    private val profiles = mapOf(
        VendorFamily.QUALCOMM to WorkspaceProfile(VendorFamily.QUALCOMM, "Qualcomm Sahara / Firehose", ProtocolFamily.SAHARA_FIREHOSE,
            listOf("Programmer manifest and SHA-256 validation", "Sahara packet/session preparation", "Firehose XML and ACK validation", "Rawprogram / patch and GPT mapping", "Read / write / erase preflight")),
        VendorFamily.SAMSUNG to WorkspaceProfile(VendorFamily.SAMSUNG, "Samsung Odin-style workspace", ProtocolFamily.ODIN_DOWNLOAD,
            listOf("BL / AP / CP / CSC / HOME_CSC package slots", "TAR inventory and TAR.MD5 integrity", "PIT parsing and partition comparison", "Model / binary revision validation", "Odin transfer requires verified OEM session")),
        VendorFamily.XIAOMI to WorkspaceProfile(VendorFamily.XIAOMI, "Xiaomi Fastboot ROM workspace", ProtocolFamily.FASTBOOT,
            listOf("Fastboot ROM archive inventory", "Flash script inspection", "Model / codename and region checks", "Partition map and image presence checks", "Lock / erase operations remain gated")),
        VendorFamily.MEDIATEK to WorkspaceProfile(VendorFamily.MEDIATEK, "MediaTek BROM / Download Agent", ProtocolFamily.MTK_BROM_DA,
            listOf("Scatter parsing and overlap validation", "DA package / SoC matching", "DA SHA-256 validation", "BROM / DA session preparation", "Read / write plan and authentication preflight")),
        VendorFamily.GOOGLE_PIXEL to WorkspaceProfile(VendorFamily.GOOGLE_PIXEL, "Google Pixel Fastboot / Factory Image", ProtocolFamily.FASTBOOT,
            listOf("Factory image archive inventory", "Build / device codename matching", "Bootloader and slot metadata checks", "Partition image mapping", "Fastboot transfer requires verified model/session")),
        VendorFamily.VIVO to WorkspaceProfile(VendorFamily.VIVO, "Vivo verified service workflow", ProtocolFamily.OEM_AUTHENTICATED,
            listOf("Exact model and chipset identification", "Firmware package and partition inventory", "Protocol and DA / programmer requirements", "OEM authorization prerequisite checks")),
        VendorFamily.OPPO to WorkspaceProfile(VendorFamily.OPPO, "Oppo verified service workflow", ProtocolFamily.OEM_AUTHENTICATED,
            listOf("Exact model and chipset identification", "Firmware package and partition inventory", "Protocol and DA / programmer requirements", "OEM authorization prerequisite checks")),
        VendorFamily.REALME to WorkspaceProfile(VendorFamily.REALME, "Realme verified service workflow", ProtocolFamily.OEM_AUTHENTICATED,
            listOf("Exact model and chipset identification", "Firmware package and partition inventory", "Protocol and DA / programmer requirements", "OEM authorization prerequisite checks")),
        VendorFamily.GENERIC to WorkspaceProfile(VendorFamily.GENERIC, "Generic verified Android workflow", ProtocolFamily.UNKNOWN,
            listOf("Identify model and chipset", "Inspect firmware and partition metadata", "Require a supported protocol before operations")),
        VendorFamily.UNKNOWN to WorkspaceProfile(VendorFamily.UNKNOWN, "Device profile pending", ProtocolFamily.UNKNOWN,
            listOf("Connect a device or select a brand", "USB descriptors alone do not prove model or protocol"))
    )

    fun forBrand(brand: String): WorkspaceProfile = when {
        brand.equals("Auto Detect", true) -> profiles.getValue(VendorFamily.UNKNOWN) // never assume a vendor before device evidence exists
        else -> profiles[vendorFromName(brand)] ?: profiles.getValue(VendorFamily.UNKNOWN)
    }

    fun detect(evidence: DeviceEvidence): WorkspaceSnapshot {
        val vendor = vendorFromName(evidence.manufacturer)
        val profile = profiles[vendor] ?: profiles.getValue(VendorFamily.UNKNOWN)
        val warnings = mutableListOf<String>()
        if (evidence.manufacturer.isBlank()) warnings += "Manufacturer is not confirmed."
        if (evidence.model.isBlank()) warnings += "Exact model is not confirmed."
        if (evidence.chipset.isBlank()) warnings += "Chipset is not confirmed."
        if (!evidence.protocolVerified || evidence.protocol == ProtocolFamily.UNKNOWN) warnings += "Protocol is not verified; destructive operations must remain blocked."
        val connection = if (evidence.manufacturer.isNotBlank() && evidence.model.isNotBlank() && evidence.chipset.isNotBlank() &&
            evidence.protocolVerified && evidence.protocol != ProtocolFamily.UNKNOWN)
            WorkspaceConnection.CONNECTED_VERIFIED else WorkspaceConnection.DETECTED_UNVERIFIED
        val selected = if (evidence.protocolVerified && evidence.protocol != ProtocolFamily.UNKNOWN) profileForProtocol(evidence.protocol, vendor) else profile
        return WorkspaceSnapshot(selected, evidence, connection, warnings)
    }

    fun disconnected(last: WorkspaceSnapshot): WorkspaceSnapshot = last.copy(
        connection = WorkspaceConnection.DISCONNECTED,
        warnings = (last.warnings.filterNot { it.contains("disconnected", true) } + "Device disconnected. Last workspace and device identity retained; write operations disabled.")
    )

    fun vendorFromName(name: String): VendorFamily = when {
        name.contains("qualcomm", true) -> VendorFamily.QUALCOMM
        name.contains("samsung", true) -> VendorFamily.SAMSUNG
        name.contains("xiaomi", true) || name.contains("poco", true) || name.contains("redmi", true) -> VendorFamily.XIAOMI
        name.contains("mediatek", true) || name.contains("mtk", true) -> VendorFamily.MEDIATEK
        name.contains("google", true) || name.contains("pixel", true) -> VendorFamily.GOOGLE_PIXEL
        name.contains("vivo", true) -> VendorFamily.VIVO
        name.contains("oppo", true) -> VendorFamily.OPPO
        name.contains("realme", true) -> VendorFamily.REALME
        name.isBlank() || name.equals("auto detect", true) -> VendorFamily.UNKNOWN
        else -> VendorFamily.GENERIC
    }

    private fun profileForProtocol(protocol: ProtocolFamily, vendor: VendorFamily): WorkspaceProfile = when (protocol) {
        ProtocolFamily.SAHARA_FIREHOSE -> profiles.getValue(VendorFamily.QUALCOMM)
        ProtocolFamily.ODIN_DOWNLOAD -> profiles.getValue(VendorFamily.SAMSUNG)
        ProtocolFamily.FASTBOOT -> if (vendor == VendorFamily.XIAOMI || vendor == VendorFamily.GOOGLE_PIXEL) profiles.getValue(vendor) else profiles.getValue(VendorFamily.GENERIC)
        ProtocolFamily.MTK_BROM_DA -> profiles.getValue(VendorFamily.MEDIATEK)
        ProtocolFamily.ADB, ProtocolFamily.OEM_AUTHENTICATED -> profiles[vendor] ?: profiles.getValue(VendorFamily.GENERIC)
        ProtocolFamily.UNKNOWN -> profiles.getValue(VendorFamily.UNKNOWN)
    }
}
