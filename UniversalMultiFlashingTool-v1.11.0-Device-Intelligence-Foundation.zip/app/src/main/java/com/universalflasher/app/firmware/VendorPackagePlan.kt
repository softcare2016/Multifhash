package com.universalflasher.app.firmware

/** Offline package planning only; does not implement or claim OEM device transfer. */
object VendorPackagePlan {
    enum class SamsungSlot { BL, AP, CP, CSC, HOME_CSC }
    data class Slot(val type: SamsungSlot, val fileName: String?, val required: Boolean)
    data class SamsungPlan(val slots: List<Slot>, val readyForHardwareTransfer: Boolean, val warnings: List<String>)
    data class XiaomiPlan(val files: List<String>, val scripts: List<String>, val modelHints: List<String>, val warnings: List<String>)

    fun samsung(entries: List<String>): SamsungPlan {
        val normalized = entries.map { it.substringAfterLast('/').substringAfterLast('\\') }
        fun find(token: String) = normalized.firstOrNull { it.startsWith(token, true) }
        val slots = listOf(
            Slot(SamsungSlot.BL, find("BL_"), true),
            Slot(SamsungSlot.AP, find("AP_"), true),
            Slot(SamsungSlot.CP, find("CP_"), false),
            Slot(SamsungSlot.CSC, find("CSC_"), false),
            Slot(SamsungSlot.HOME_CSC, find("HOME_CSC_"), false)
        )
        val warnings = mutableListOf<String>()
        if (slots.filter { it.required }.any { it.fileName == null }) warnings += "BL and AP package components are required for a complete package plan."
        val hasCscChoice = slots.any { (it.type == SamsungSlot.CSC || it.type == SamsungSlot.HOME_CSC) && it.fileName != null }
        if (!hasCscChoice) warnings += "A CSC or HOME_CSC component is required for a complete package plan."
        warnings += "Archive inventory is not an Odin transfer or publisher-signature verification."
        return SamsungPlan(slots, slots.filter { it.required }.all { it.fileName != null } && hasCscChoice, warnings)
    }

    data class OemPlan(val vendor: String, val safeEntries: List<String>, val partitionImages: List<String>, val modelHints: List<String>, val warnings: List<String>)

    fun inspectOemArchive(vendor: String, entries: List<String>): OemPlan {
        require(vendor.equals("Vivo", true) || vendor.equals("Oppo", true) || vendor.equals("Realme", true)) { "Unsupported OEM profile" }
        val safe = entries.filter { path ->
            val normalized = path.replace('\\', '/')
            !normalized.startsWith("/") && normalized.split('/').none { it == ".." }
        }
        val images = safe.filter { it.substringAfterLast('/').endsWith(".img", true) || it.substringAfterLast('/').endsWith(".bin", true) }
        val hints = safe.mapNotNull { Regex("(?i)(PD[0-9]{4}|CPH[0-9]{4}|RMX[0-9]{3,5}|V[0-9]{4})").find(it)?.value }.distinct()
        val warnings = buildList {
            if (images.isEmpty()) add("No partition image files identified in this archive listing.")
            if (hints.isEmpty()) add("No exact model identifier was identified from archive paths.")
            add("This is offline inventory only; vendor protocol, authorization and write support are not inferred.")
        }
        return OemPlan(vendor, safe, images, hints, warnings)
    }

    fun xiaomi(entries: List<String>): XiaomiPlan {
        val safe = entries.filter { path ->
            val normalized = path.replace('\\', '/')
            !normalized.startsWith("/") && normalized.split('/').none { it == ".." }
        }
        val scripts = safe.filter { it.substringAfterLast('/').matches(Regex("(?i)flash_(all|all_lock|all_except_data_storage)\\.(bat|sh)")) }
        val modelHints = safe.mapNotNull { Regex("(?i)(mi|redmi|poco)[-_ ]?[a-z0-9]+(?:[-_][a-z0-9]+)?").find(it)?.value }.distinct()
        val warnings = buildList {
            if (scripts.isEmpty()) add("No recognized Xiaomi flash script found; package may be incomplete or use another layout.")
            if (modelHints.isEmpty()) add("No reliable model/codename hint found in archive paths.")
            add("Script inspection is read-only; execution requires a verified Fastboot session and exact model match.")
        }
        return XiaomiPlan(safe, scripts, modelHints, warnings)
    }
}
