package com.universalflasher.app.detection

import com.universalflasher.app.workspace.DeviceEvidence
import com.universalflasher.app.workspace.ProtocolFamily
import com.universalflasher.app.workspace.VendorFamily
import com.universalflasher.app.workspace.DeviceWorkspaceRegistry

/**
 * Evidence-based identity resolution. USB descriptors are hints only and can never
 * establish an exact model or a flash-ready protocol by themselves.
 */
enum class IdentityEvidenceSource(val trust: Int) {
    USB_DESCRIPTOR(10),
    ADB_PROPERTY(85),
    FASTBOOT_VARIABLE(85),
    OEM_HANDSHAKE(95),
    USER_CONFIRMED(90)
}

data class IdentityFact(
    val key: String,
    val value: String,
    val source: IdentityEvidenceSource
)

enum class IdentityConfidence { NONE, LOW, MEDIUM, HIGH, VERIFIED }

data class ResolvedDeviceIdentity(
    val manufacturer: String?,
    val model: String?,
    val codename: String?,
    val chipset: String?,
    val vendor: VendorFamily,
    val confidence: IdentityConfidence,
    val exactModelConfirmed: Boolean,
    val protocol: ProtocolFamily,
    val protocolVerified: Boolean,
    val warnings: List<String>
) {
    fun toWorkspaceEvidence(usbVid: Int? = null, usbPid: Int? = null, mode: String = "") = DeviceEvidence(
        manufacturer = manufacturer.orEmpty(), model = model.orEmpty(), chipset = chipset.orEmpty(),
        usbVid = usbVid, usbPid = usbPid, mode = mode, protocol = protocol, protocolVerified = protocolVerified
    )
}

object DeviceIdentityResolver {
    private val manufacturerAliases = mapOf(
        "samsung electronics" to "Samsung", "samsung" to "Samsung",
        "xiaomi communications" to "Xiaomi", "xiaomi" to "Xiaomi", "redmi" to "Xiaomi", "poco" to "Xiaomi",
        "google" to "Google", "google llc" to "Google", "oneplus" to "OnePlus",
        "oppo" to "Oppo", "vivo" to "Vivo", "realme" to "Realme",
        "motorola" to "Motorola", "lenovo" to "Lenovo", "huawei" to "Huawei",
        "honor" to "Honor", "sony" to "Sony", "asus" to "ASUS", "tecno" to "TECNO",
        "infinix" to "Infinix", "itel" to "itel"
    )

    fun resolve(facts: List<IdentityFact>, protocol: ProtocolFamily = ProtocolFamily.UNKNOWN, protocolVerified: Boolean = false): ResolvedDeviceIdentity {
        val warnings = mutableListOf<String>()
        fun candidates(key: String) = facts.filter { it.key.equals(key, true) && it.value.isNotBlank() }
            .groupBy { normalize(it.value) }
            .map { (_, rows) -> rows.maxBy { it.source.trust } }
            .sortedByDescending { it.source.trust }

        val manufacturerFact = candidates("manufacturer").firstOrNull()
        val modelFacts = candidates("model").filter { it.source.trust >= IdentityEvidenceSource.ADB_PROPERTY.trust }
        val codenameFact = candidates("codename").firstOrNull()
        val chipsetFact = candidates("chipset").firstOrNull()
        val modelFact = modelFacts.firstOrNull { it.source.trust >= IdentityEvidenceSource.ADB_PROPERTY.trust }
        val conflictingModels = modelFacts.map { normalize(it.value) }.distinct().size > 1
        if (manufacturerFact == null) warnings += "Manufacturer is not established by available evidence."
        if (modelFact == null) warnings += "Exact model requires an authorized ADB/Fastboot property or OEM handshake."
        if (conflictingModels) warnings += "Conflicting model evidence detected; exact model confirmation withheld."
        if (chipsetFact == null) warnings += "Chipset is not confirmed."
        if (!protocolVerified || protocol == ProtocolFamily.UNKNOWN) warnings += "Flashing protocol is not verified."

        val manufacturer = manufacturerFact?.value?.let { canonicalManufacturer(it) }
        val vendor = DeviceWorkspaceRegistry.vendorFromName(manufacturer.orEmpty())
        val exactConfirmed = modelFact != null && !conflictingModels && manufacturerFact != null && manufacturerFact.source.trust >= IdentityEvidenceSource.ADB_PROPERTY.trust
        val trustValues = listOfNotNull(manufacturerFact?.source?.trust, modelFact?.source?.trust, chipsetFact?.source?.trust)
        val averageTrust = if (trustValues.isEmpty()) 0 else trustValues.average().toInt()
        val confidence = when {
            exactConfirmed && chipsetFact != null && protocolVerified && protocol != ProtocolFamily.UNKNOWN -> IdentityConfidence.VERIFIED
            exactConfirmed && chipsetFact != null -> IdentityConfidence.HIGH
            exactConfirmed || averageTrust >= 70 -> IdentityConfidence.MEDIUM
            averageTrust > 0 -> IdentityConfidence.LOW
            else -> IdentityConfidence.NONE
        }
        return ResolvedDeviceIdentity(
            manufacturer = manufacturer,
            model = modelFact?.takeUnless { conflictingModels }?.value,
            codename = codenameFact?.value,
            chipset = chipsetFact?.value,
            vendor = vendor,
            confidence = confidence,
            exactModelConfirmed = exactConfirmed,
            protocol = protocol,
            protocolVerified = protocolVerified && protocol != ProtocolFamily.UNKNOWN,
            warnings = warnings
        )
    }

    private fun canonicalManufacturer(value: String): String {
        val key = normalize(value)
        return manufacturerAliases[key] ?: value.trim()
    }

    private fun normalize(value: String) = value.trim().lowercase().replace(Regex("\\s+"), " ")
}
