# Focused update report — v1.10.2

Only the requested display/navigation changes were made on top of v1.10.1. The earlier full-filename provider lookup was retained.

1. **Landscape restored:** both the Activity orientation request and manifest orientation are set to landscape.
2. **Filename display retained and applied:** the firmware field now uses the compact display name helper, showing the leading part of long names and preserving the actual suffix (such as `.zip` or `.md5`).
3. **Two-finger canvas navigation:** two active fingers can pinch to zoom and move together to pan horizontally/vertically. A single finger remains available for normal button and field interaction. The transform follows the gesture centroid, like an image-editing canvas.
4. **Slightly shorter workspace:** minimum extended canvas height reduced from 900dp to 840dp to reclaim some lower blank space without introducing page scrolling.
5. **Slightly wider content area:** outer horizontal inset reduced from 4dp to 2dp on each side.

No flashing/ADB/USB/firmware operation logic, page contents, colors, or button actions were intentionally changed.

## Verification boundary

- Screen-layout static checks: see `tools/simulation/check_screen_layout.sh`.
- Kotlin/JVM simulation suite: run with `tools/simulation/run.sh`.
- Android APK compilation and real-device layout/gesture testing were not available in this environment because the archive has no Gradle wrapper and no system Gradle/Android build environment.
