# v1.6.0 source and simulation test results

## Executed in this workspace
Command: `./tools/simulation/run.sh`

Result: **20 passed, 0 failed**.

Scenarios include:
1. ADB packet checksum corruption rejection.
2. ADB malformed payload length rejection.
3. Qualcomm Sahara malformed packet length rejection.
4. MediaTek BROM NACK security stop.
5. MediaTek scatter partition overlap rejection.
6. MediaTek XML DA path traversal rejection.
7. Qualcomm Firehose NAK rejection.
8. Firehose final-sector zero padding and final ACK.
9. Firehose truncated raw partition read rejection.
10. GPT invalid signature rejection.
11. GPT header CRC corruption rejection.
12. GPT overlapping partition rejection.
13. Samsung TAR.MD5 valid appended digest accepted.
14. Samsung TAR.MD5 tampering detected.
15. Partition restore model mismatch blocked before transport.
16. Partition restore digest mismatch blocked before transport.
17. Flash job cancellation at safe checkpoint.
18. Qualcomm XML DOCTYPE/external entity rejected.
19. Qualcomm path traversal rejected.
20. Samsung truncated PIT rejected.

## JUnit coverage added
`app/src/test/java/com/universalflasher/app/SimulationRegressionTest.kt` contains corresponding JUnit tests. GitHub Actions runs `testDebugUnitTest` before `assembleDebug`.

## Not executed here
- Android Gradle build/APK assembly.
- Android emulator/instrumentation tests.
- USB OTG and any physical Qualcomm, MediaTek, Samsung, ADB or Fastboot session.
- Physical partition backup/restore/flash.

The offline tests validate source behavior against deterministic synthetic streams/files only. They do not prove real hardware interoperability.


## v1.7.0 re-run
- `tools/simulation/run.sh`: PASS — 20 passed, 0 failed after the UI/ADB transport source update.
- MainActivity and AdbUsbTransport Kotlin parser check: no syntax/parse errors observed. A standalone `kotlinc` check cannot resolve Android/Compose APIs because the Android SDK and Gradle dependency classpath are not installed in this environment; this is not an Android compile result.
- Resource audit: all drawable identifiers referenced by MainActivity resolve to bundled drawable resources.
- ZIP integrity: verified separately after packaging.
- Android Gradle build, APK install, rendering and physical USB device tests: not run in this environment.


## v1.9.6 readable workspace source checks

- Updated `tools/simulation/check_screen_layout.sh` for the current v1.9.6 source.
- The updated source-layout regression script passed in this environment.
- ZIP integrity was checked after packaging.
- Android Gradle compilation and real-device testing were not run in this environment.


## v1.9.7 software-foundation regression update
- `tools/simulation/run.sh`: **32 passed, 0 failed**.
- New coverage: vendor workspace selection, disconnect profile retention, unverified USB evidence, destructive-operation preflight blocking, read-only inspection preflight, Samsung five-slot plan, CSC/HOME_CSC requirement, Xiaomi script/path inspection, Vivo/Oppo/Realme read-only inventory, and backup confirmation gating.
- `tools/simulation/check_screen_layout.sh`: PASS.
- Android Gradle build, APK assembly, UI runtime rendering and physical hardware tests remain unverified.


## v1.10.0 — Strict no-scroll correction
- Removed the remaining nested ADB RESULT vertical scroll container found in v1.9.9.
- Disabled one-finger canvas pan; two-finger pinch now changes zoom only around the viewport centre.
- MainActivity source scan confirms no page/nested scroll modifiers remain.
- Runtime/device verification and APK build remain external validation items.
