#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
UI="$ROOT/app/src/main/java/com/universalflasher/app/MainActivity.kt"
MANIFEST="$ROOT/app/src/main/AndroidManifest.xml"

# No nested page scrolling: the workspace is navigated with two-finger transforms.
if grep -En 'verticalScroll|horizontalScroll|rememberScrollState|LazyColumn|LazyRow|\.scrollable\(' "$UI"; then
  echo 'FAIL | scroll modifier/container remains in MainActivity.kt'
  exit 1
fi
grep -Fq 'SCREEN_ORIENTATION_LANDSCAPE' "$UI"
grep -Fq 'android:screenOrientation="landscape"' "$MANIFEST"
grep -Fq 'awaitEachGesture' "$UI"
grep -Fq 'event.changes.count { it.pressed } >= 2' "$UI"
grep -Fq 'val panChange = currentCentroid - previousCentroid' "$UI"
grep -Fq 'currentRadius / previousRadius' "$UI"
grep -Fq 'translationX = panOffset.x' "$UI"
grep -Fq 'translationY = panOffset.y' "$UI"
grep -Fq 'val canvasHeight = maxOf(maxHeight, 700.dp)' "$UI"
grep -Fq 'height(300.dp)' "$UI"
if grep -Fq 'PanelCard("Description"' "$UI"; then
  echo 'FAIL | redundant Home Description card remains'
  exit 1
fi
grep -Fq 'Text(compactFirmwareFileName(firmwareName)' "$UI"
grep -Fq 'transformOrigin = TransformOrigin.Center' "$UI"
echo 'PASS | landscape lock; no nested scrolling; two-finger pinch zoom + pan; 700dp compact canvas; Description removed; 300dp upper panels; compact filename retains extension'
