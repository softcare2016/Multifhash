# Landscape compact Home dashboard — v1.10.4

## UI changes
- Removed the redundant Description card from the Home dashboard.
- Reduced the Firmware & Flash Options / Device Information row from 360dp to 300dp.
- Reduced Home dashboard vertical spacing and outer vertical padding.
- Reduced the minimum workspace canvas height from 840dp to 700dp so the default view exposes more of the dashboard.
- Removed outer horizontal insets so the workspace uses the full available width.

## Preserved
- Landscape orientation and immersive full-screen behavior.
- Existing two-finger-only pinch zoom and pan implementation.
- Single-finger button, dropdown, checkbox, and other control interaction.
- Firmware selection, USB detection, device information, Read / Backup / Restore / Flash callbacks, logs, progress, and all other application modules.

## Verification boundary
Source-level layout and regression checks should be run in CI. An Android APK build and real-device gesture/readability check are still required to certify the final rendered layout.
