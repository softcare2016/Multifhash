# Implementation status — v1.8.0

Current source revision: v1.8.0. The v1.6.0 core/protocol simulation status below is retained as historical test evidence; the v1.8.0 UI-specific changes and limitations are listed at the end.

This release completes additional offline-verifiable source work and expands deterministic regression coverage. It does not claim physical-device acceptance.

| Area | v1.6.0 source/simulation status | Hardware-dependent acceptance still required |
|---|---|---|
| Reference dashboard + 3D assets | Retained; version label updated | Runtime screenshot/layout verification on target display |
| USB host enumeration/permissions | Source helpers present | OTG attach/detach, permission and interface tests on Android phones |
| Firmware SHA-256/signatures | Streaming digest foundation | OEM trust roots, signed manifest corpus and package-specific signature verification |
| Qualcomm rawprogram/patch | Hardened XML parser, path and geometry checks | OEM sample corpus and exact programmer/model matching |
| Qualcomm Sahara | HELLO, READ_DATA/READ_DATA64 and bounded upload state machine | Endpoint quirks, multi-image IDs, chipset/loader tests |
| Qualcomm Firehose | Configure/read/program/erase command builders, ACK handling and streaming session | Negotiated sector/payload sizes, ZLP behavior, target tests |
| Qualcomm programmer trust | SHA-256 against caller-supplied trusted digest | Provenance of trusted manifest and per-model acceptance |
| MediaTek scatter | Hex address/size parsing, unsafe path and overlap validation | OEM scatter corpus and chipset tests |
| MediaTek DA package | Header, SoC entry, DA1 region bounds and extraction | Exact DA revisions, DA2 stage and secure-target tests |
| MediaTek BROM | Sync, target identification/config, SEND_DA and JUMP_DA source flow | Preloader quirks, chipset tests and authorized DA boot |
| MediaTek XFlash V5 | Frame codec, ACK flow and bounded chunk streaming | OEM command IDs and complete read/write target flow |
| MediaTek XML DA V6 | Framing, read/write/erase command builders and session ACK parsing | OEM schema validation and full data upload/download |
| Samsung TAR | TAR inventory and appended TAR.MD5 digest verification | Real Samsung package corpus; MD5 is integrity-only, not publisher trust |
| Samsung Odin/Thor | Handshake, packet codec, response parser and PIT parser | Full XMIT firmware transfer, compressed modes and hardware acceptance |
| ADB | RSA AUTH, CNXN and shell_v2 source implementation | Android Keystore integration, device authorization and shell tests |
| Fastboot | USB diagnostic transport and basic command foundation | Device-specific endpoints/framing and actual command tests |
| GPT/partition | CRC, geometry, name and overlap checks; Firehose live-read source path; file-backed backup/restore | Real GPT corpus, live device reads, backup-GPT recovery and model-specific tests |
| Partition backup/restore/erase | File-backed Firehose service with digest/model/confirmation guards | Physical read/write/restore round-trip and data integrity |
| Flash job lifecycle | State machine, progress, pause/resume/cancel checkpoints | Protocol-worker integration, process-death recovery and hardware tests |
| Offline simulation | 20 deterministic cases pass in local Kotlin/JVM runner; JUnit regressions added | CI execution and independent review of test fixtures |
| Gradle/CI | Gradle Kotlin DSL + workflow runs unit tests and assembleDebug | Clean GitHub Actions run and APK install/launch |

## Local simulation command
From the project root run:

```bash
./tools/simulation/run.sh
```

Expected terminal summary: `SIMULATION_RESULT passed=20 failed=0`. The runner compiles platform-independent protocol/core sources with `kotlinc`; it does not compile the Android app or emulate a real bootloader.

## Explicit limitations
- Qualcomm Firehose and MediaTek DA require exact-model, trusted OEM programmer/DA files.
- MediaTek DA2 and full OEM storage command flows are not claimed complete.
- Samsung Odin XMIT firmware transfer is not claimed complete.
- Android Keystore integration and complete ADB/Fastboot runtime wiring are not claimed complete.
- GPT parser validates primary GPT only; backup GPT recovery is not implemented.
- No Android APK build or physical-device test is claimed from this workspace.

## Release rule
A source module is complete only for the operations explicitly implemented and tested. A product feature is 100% supported only after clean build, unit tests, model/firmware matching, error handling and real-device tests pass.


## v1.8.0 UI implementation status (source-level)
- Reference dashboard structure rebuilt: sidebar, branded header, toolbar actions, connection badge, firmware controls, device info/phone visual, flash action row, terminal log, progress and footer.
- All nine navigation destinations now have dedicated workspaces and controls. Brand selection routes back to Home.
- 16 generated transparent 3D-style icon assets are bundled in `app/src/main/res/drawable-nodpi/`.
- ADB USB transport exposes stream adapters for the existing ADB AUTH/CNXN/shell_v2 host-session code. ADB command execution requires physical USB permission and RSA authorization.
- Fastboot selected-getvar action is connected to the USB transport.
- The dashboard deliberately blocks destructive flashing unless firmware inspection, exact model selection and a protocol-ready device state are established. The vendor engines are not yet fully wired into a production flash job runner.
- The reference illustration's example device identity is internally inconsistent (Pixel badge vs Samsung device panel); the app uses one live detected device state rather than displaying both contradictory identities.
- The original screenshot is a desktop/tablet-scale reference. Small Android landscape screens use responsive scaling; title-bar zoom is provided. Exact pixel parity depends on display size and density.
- Physical-device validation and Android Gradle build have not been run in this environment. Do not interpret source-level UI implementation as hardware certification.


## v1.8.0 screen-fit update

The original landscape dashboard is kept as the fixed visual workspace. It auto-fits to the available display, zooms independently from layout measurement, and supports drag-panning while magnified. Page-level scrolling containers were removed from the Home log, Brands catalogue and ADB output. See `SCREEN_FIT_AND_ZOOM.md`. Android build and on-device rendering still require external validation.

## v1.8.1 device guidance UI update (source-level)
- Added an Illustrated Mode Guide dialog to Device Information with Fastboot/Bootloader, Recovery, Samsung Download Mode and Qualcomm EDL guidance categories.
- USB refresh now displays available USB manufacturer/product descriptors where Android exposes them and logs that USB VID/PID/descriptors alone do not prove the exact handset model.
- The guide explicitly distinguishes its bundled generic handset illustration from a verified connected-model photograph. It does not invent button combinations or EDL test-point locations when the exact model/board revision is unverified.
- Exact per-model online product-photo retrieval, ADB/Fastboot model-property acquisition into the shared device identity state, and verified annotated OEM button/test-point diagrams remain follow-up implementation work. Internet retrieval is not represented as implemented in this update.
- Offline protocol simulation rerun for this update: 20 passed, 0 failed. Android Gradle compilation and physical-device UI validation were not available in this environment.


## v1.8.3 dashboard readability revision
- Increased the vertical allocation for Firmware & Flash Options so partition controls and their labels have room.
- Increased partition-label readability and made each checkbox easier to identify and tap.
- Reduced the intensity of the cyan/blue accent palette, panel borders and separators to reduce visual glare.
- Preserved checkbox state callbacks and all existing flash-action callbacks; no flashing-engine or protocol implementation was changed.
- Requires a fresh Android build and on-device visual check on the target phone.


## v1.8.4 ADB quick-action console revision
- Removed manual ADB command entry from the ADB Tools page.
- Added grouped, labelled quick actions for phone identity/build, battery, storage, RAM, network, installed apps, processes, CPU, uptime, system properties, USB mode, display, boot slot/reason, Wi-Fi, logs, Doze, and reboot/power operations.
- Every quick action uses the existing authenticated USB ADB CNXN/AUTH + shell_v2 path and reports stdout/stderr/exit status to the ADB result panel and application log.
- Reboot, bootloader, recovery, sideload and power-off actions require an in-app confirmation.
- Host-side ADB commands that require the ADB sync service (for example install, push and pull) are deliberately not shown as working controls because that service is outside the current implementation.
- Offline protocol regression suite remains hardware-free; actual ADB command behavior still requires testing with a physical phone, enabled USB debugging and accepted RSA authorization.

## v1.8.5 staged source update (2026-11-27)
- Home partition selector changed to a wrapping layout to reduce clipped checkbox labels on compact landscape screens.
- Added a Firmware Backup navigation workspace with selective backup/full backup prerequisites and firmware inventory comparison guidance.
- Existing Firehose PartitionService remains available with model-match, confirmation, size-capacity and SHA-256 checks.
- The new workspace is not yet wired to a live Firehose session/GPT, so it must not be represented as a completed universal device-backup feature.
- IMEI functionality remains read-only; no IMEI write/change feature is implemented.
- First-run Master Password setup and secure gating for privileged operations remain pending.
- Android Gradle compilation and hardware validation were not run in this environment.


## v1.9.0 pinch zoom and floating-window update (source-level)
- Added Compose transform gesture handling for two-finger pinch zoom, bounded to 0.50×–2.00×, with panning.
- Replaced header zoom controls with Minimize, Maximize and Close actions.
- Added a user-started foreground overlay service with a draggable floating restore shortcut; Android overlay permission is required.
- Maximize resets zoom and pan. Close is blocked while the app marks a flash job active.
- Source regression check passed and protocol simulation suite passed 20/20. Android Gradle compilation, permission UX and real-device rendering are not verified in this environment.


## v1.9.7 software-foundation completion update (2026-11-28)

This update addresses the software-only foundation requested for the single dynamic main workspace and vendor workflow preparation. The 90% figures in `SOFTWARE_FOUNDATION_COMPLETION_REPORT.md` are explicitly a software-foundation score: the final 10% is reserved for protocol-worker/device integration, OEM authorization/session wiring and physical acceptance. They are not a claim of 90% universal hardware compatibility or successful physical flashing.

Implemented in this update:
- Added `workspace/DeviceWorkspace.kt`: central vendor/protocol profile registry for Qualcomm, Samsung, Xiaomi, MediaTek, Vivo, Oppo, Realme, generic and unknown devices; protocol evidence is required before a detected session can be considered verified; USB VID/PID alone is insufficient; disconnect retains the last profile and evidence.
- Connected the selected profile to the existing Home workspace's Description panel without adding navigation or redesigning the dashboard. Auto Detect retains the requested Qualcomm-oriented default workspace; selecting a brand changes the in-place workspace summary.
- Added `engine/FlashPreflight.kt`: shared operation-specific gates for inspect, verify, read, backup, write, restore, erase and flash. Destructive actions require all model, chipset, firmware, partition, protocol, trusted loader, authorization and confirmation checks.
- Added `firmware/VendorPackagePlan.kt`: Samsung BL/AP/CP/CSC/HOME_CSC slot mapping, Xiaomi ROM script/path inspection, and read-only Vivo/Oppo/Realme archive inventory/model-hint inspection.
- Expanded `EngineRegistry` with explicit software-foundation percentages and hardware-integration-pending flags. Vendor engines remain `PARTIAL` until their protocol workers and authorized hardware sessions are integrated and accepted.
- Corrected UI wording from “SHA-256 verified locally” to “SHA-256 calculated locally”; calculating a digest is not a signature or trusted-hash verification.
- Added twelve more deterministic simulation cases; total simulation coverage is now 32 cases.

Validation:
- `bash tools/simulation/run.sh`: 32 passed, 0 failed.
- `bash tools/simulation/check_screen_layout.sh`: passed.
- ZIP integrity: verified after packaging.
- Android Gradle compilation, APK assembly, emulator and physical-device tests: not run in this environment.

Known remaining integration items include Samsung Odin XMIT transfer, full MediaTek DA storage data flow, Xiaomi device-specific flash worker, Vivo/Oppo/Realme authenticated protocol workers, end-to-end job-runner wiring, complete Fastboot command/flash support, Android Keystore-backed ADB identity acceptance and OEM trust-root/signature verification. These are not represented as implemented by the offline planning modules.


## v1.10.0 — Strict no-scroll correction
- Removed the remaining nested ADB RESULT vertical scroll container found in v1.9.9.
- Disabled one-finger canvas pan; two-finger pinch now changes zoom only around the viewport centre.
- MainActivity source scan confirms no page/nested scroll modifiers remain.
- Runtime/device verification and APK build remain external validation items.
