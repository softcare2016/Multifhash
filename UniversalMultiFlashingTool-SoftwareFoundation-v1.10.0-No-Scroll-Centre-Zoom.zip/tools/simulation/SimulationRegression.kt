package com.universalflasher.app.simulation

import com.universalflasher.app.adb.AdbPacket
import com.universalflasher.app.jobs.FlashJob
import com.universalflasher.app.jobs.FlashJobState
import com.universalflasher.app.workspace.*
import com.universalflasher.app.engine.FlashPreflight
import com.universalflasher.app.engine.FlashPreflightInput
import com.universalflasher.app.engine.FlashOperation
import com.universalflasher.app.firmware.VendorPackagePlan
import com.universalflasher.app.mediatek.BromProtocol
import com.universalflasher.app.mediatek.ScatterInspector
import com.universalflasher.app.mediatek.XmlDaProtocol
import com.universalflasher.app.partition.GptReader
import com.universalflasher.app.partition.GptPartition
import com.universalflasher.app.partition.PartitionService
import com.universalflasher.app.qualcomm.FirehoseSession
import com.universalflasher.app.qualcomm.QualcommPackageInspector
import com.universalflasher.app.samsung.SamsungPackageInspector
import java.io.*
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest
import java.util.zip.CRC32

/** Deterministic offline regression suite. No USB device or bootloader is contacted. */
object SimulationRegression {
    private var passed = 0
    private fun test(name: String, body: () -> Unit) {
        try { body(); passed++; println("PASS | $name") }
        catch (t: Throwable) { System.err.println("FAIL | $name | ${t::class.simpleName}: ${t.message}"); throw t }
    }
    private inline fun <reified T : Throwable> fails(noinline body: () -> Unit) {
        try { body() } catch (t: Throwable) { if (t is T) return else throw AssertionError("Expected ${T::class.simpleName}, got ${t::class.simpleName}", t) }
        throw AssertionError("Expected ${T::class.simpleName}, but operation succeeded")
    }
    private fun ack() = "<data><response value=\"ACK\" /></data>".toByteArray()
    private fun sha(bytes: ByteArray) = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }

    @JvmStatic fun main(args: Array<String>) {
        test("ADB packet checksum corruption rejected") {
            val encoded = AdbPacket("CNXN", 1, 2, byteArrayOf(1, 2, 3)).encode()
            encoded[encoded.lastIndex] = 4
            fails<IllegalArgumentException> { AdbPacket.decode(encoded.copyOfRange(0, 24), encoded.copyOfRange(24, encoded.size)) }
        }
        test("ADB malformed payload length rejected") {
            val encoded = AdbPacket("CNXN", 1, 2, byteArrayOf()).encode(); encoded[12] = 1
            fails<IllegalArgumentException> { AdbPacket.decode(encoded.copyOfRange(0,24), byteArrayOf()) }
        }
        test("Qualcomm Sahara malformed packet length rejected") {
            val b = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putInt(1).putInt(999).array()
            fails<IllegalArgumentException> { com.universalflasher.app.qualcomm.SaharaProtocol.decode(b) }
        }
        test("MediaTek BROM NACK maps to security stop") {
            fails<SecurityException> { BromProtocol.requireAck(ByteArrayInputStream(byteArrayOf(BromProtocol.NACK.toByte()))) }
        }
        test("MediaTek scatter overlap rejected") {
            val scatter = """
- partition_index: SYS0
  partition_name: boot
  file_name: boot.img
  linear_start_addr: 0x1000
  partition_size: 0x1000
- partition_index: SYS1
  partition_name: system
  file_name: system.img
  linear_start_addr: 0x1800
  partition_size: 0x1000
""".trimIndent()
            fails<IllegalArgumentException> { ScatterInspector.parse(scatter) }
        }
        test("MediaTek XML command path injection rejected") {
            fails<IllegalArgumentException> { XmlDaProtocol.readPartitionXml("../userdata", "dump.bin") }
        }
        test("Firehose NAK response rejected") {
            val nak = "<data><response value=\"NAK\" /></data>".toByteArray()
            fails<IllegalStateException> { FirehoseSession(ByteArrayInputStream(nak), ByteArrayOutputStream()).configure() }
        }
        test("Firehose program pads final sector and verifies final ACK") {
            val payload = byteArrayOf(1, 2, 3)
            val input = ByteArrayInputStream(ack() + ack())
            val output = ByteArrayOutputStream(); val file = File.createTempFile("umt-sim", ".img")
            try {
                file.writeBytes(payload)
                FirehoseSession(input, output).programFile(file, 10)
                val wire = output.toByteArray(); val rawStart = indexOfBytes(wire, "</data>".toByteArray()) + 7
                val raw = wire.copyOfRange(rawStart, wire.size)
                check(raw.size == 512 && raw.take(3) == payload.toList() && raw.drop(3).all { it == 0.toByte() })
            } finally { file.delete() }
        }
        test("Firehose truncated partition read rejected") {
            val input = ByteArrayInputStream(ack() + ByteArray(10))
            fails<IllegalStateException> { FirehoseSession(input, ByteArrayOutputStream()).readPartitionTo(0, 1, ByteArrayOutputStream()) }
        }
        test("GPT invalid signature rejected") {
            fails<IllegalArgumentException> { GptReader.readReport(ByteArrayInputStream(ByteArray(1024))) }
        }
        test("GPT header CRC corruption rejected") {
            val image = validGptImage(); image[512 + 20] = (image[512 + 20].toInt() xor 0x7f).toByte()
            fails<IllegalArgumentException> { GptReader.readReport(ByteArrayInputStream(image)) }
        }
        test("GPT overlapping partitions rejected") {
            val image = validGptImage(overlap = true)
            fails<IllegalArgumentException> { GptReader.readReport(ByteArrayInputStream(image)) }
        }
        test("Samsung TAR.MD5 valid digest accepted") {
            val tar = ByteArray(1024) { (it % 239).toByte() }
            val suffix = MessageDigest.getInstance("MD5").digest(tar).joinToString("") { "%02x".format(it) }.toByteArray()
            val file = File.createTempFile("umt-samsung", ".tar.md5")
            try { file.writeBytes(tar + suffix); val r = SamsungPackageInspector.verifyTarMd5(file); check(r.valid && r.tarBytes == tar.size.toLong()) }
            finally { file.delete() }
        }
        test("Samsung TAR.MD5 tampering detected") {
            val tar = byteArrayOf(1,2,3,4,5); val suffix = "00000000000000000000000000000000".toByteArray()
            val file = File.createTempFile("umt-samsung", ".tar.md5")
            try { file.writeBytes(tar + suffix); check(!SamsungPackageInspector.verifyTarMd5(file).valid) }
            finally { file.delete() }
        }
        test("Partition restore model mismatch blocks before transport") {
            val output = ByteArrayOutputStream(); val session = FirehoseSession(ByteArrayInputStream(byteArrayOf()), output)
            val image = File.createTempFile("umt-restore", ".img")
            try { image.writeBytes(ByteArray(512)); fails<IllegalArgumentException> { PartitionService.restore(session, GptPartition("boot", 1, 1, "type"), 0, 512, image, false, true, sha(image.readBytes())) }; check(output.size() == 0) }
            finally { image.delete() }
        }
        test("Partition restore digest mismatch blocks before transport") {
            val output = ByteArrayOutputStream(); val session = FirehoseSession(ByteArrayInputStream(byteArrayOf()), output)
            val image = File.createTempFile("umt-restore", ".img")
            try { image.writeBytes(ByteArray(512)); fails<IllegalArgumentException> { PartitionService.restore(session, GptPartition("boot", 1, 1, "type"), 0, 512, image, true, true, "0".repeat(64)) }; check(output.size() == 0) }
            finally { image.delete() }
        }
        test("Flash job cancellation reaches safe checkpoint") {
            val job = FlashJob(); job.queue(100); job.start(); job.checkpoint(20); job.cancel(); job.checkpoint(0)
            check(job.snapshot().state == FlashJobState.CANCELLED && job.snapshot().completedBytes == 20L)
        }
        test("Qualcomm XML external entity/DOCTYPE rejected") {
            val xml = "<!DOCTYPE data [<!ENTITY x SYSTEM \"file:///etc/passwd\">]><data><program label=\"&x;\" filename=\"boot.img\"/></data>"
            fails<Exception> { QualcommPackageInspector.parseRawProgram(xml.byteInputStream()) }
        }
        test("Qualcomm path traversal rejected") {
            val xml = "<data><program label=\"boot\" filename=\"../boot.img\" start_sector=\"1\" num_partition_sectors=\"1\"/></data>"
            fails<IllegalArgumentException> { QualcommPackageInspector.parseRawProgram(xml.byteInputStream()) }
        }
        test("Samsung truncated PIT rejected") {
            val b = ByteBuffer.allocate(32).order(ByteOrder.LITTLE_ENDIAN).putInt(com.universalflasher.app.samsung.OdinProtocol.PIT_MAGIC).putInt(1).array()
            fails<IllegalArgumentException> { com.universalflasher.app.samsung.OdinProtocol.parsePit(b) }
        }
        test("Dynamic workspace maps Xiaomi to Fastboot profile") {
            check(DeviceWorkspaceRegistry.forBrand("Xiaomi").protocol == ProtocolFamily.FASTBOOT)
        }
        test("Dynamic workspace maps Samsung to Odin profile") {
            check(DeviceWorkspaceRegistry.forBrand("Samsung").vendor == VendorFamily.SAMSUNG)
        }
        test("Google Pixel uses a Fastboot factory-image profile") {
            check(DeviceWorkspaceRegistry.forBrand("Google Pixel").protocol == ProtocolFamily.FASTBOOT)
        }
        test("Disconnect retains last selected workspace") {
            val active = DeviceWorkspaceRegistry.detect(DeviceEvidence(manufacturer="Samsung", model="SM-A546B", chipset="Exynos 1380", protocol=ProtocolFamily.ODIN_DOWNLOAD, protocolVerified=true))
            val detached = DeviceWorkspaceRegistry.disconnected(active)
            check(detached.profile == active.profile && detached.evidence.model == "SM-A546B")
            check(detached.connection == WorkspaceConnection.DISCONNECTED)
        }
        test("Unknown USB evidence cannot verify protocol") {
            val result = DeviceWorkspaceRegistry.detect(DeviceEvidence(manufacturer="Samsung", usbVid=0x04e8, usbPid=0x6860))
            check(result.connection == WorkspaceConnection.DETECTED_UNVERIFIED && result.warnings.isNotEmpty())
        }
        test("Destructive flash preflight blocks missing hardware integration gates") {
            val result = FlashPreflight.evaluate(FlashPreflightInput(FlashOperation.FLASH, true, true, true, true, true, false, false, false, true))
            check(!result.allowed && result.blockers.size == 3)
        }
        test("Read-only inspection does not require live hardware session") {
            val result = FlashPreflight.evaluate(FlashPreflightInput(FlashOperation.INSPECT, false, false, false, true, true, false, false, false, false))
            check(result.allowed)
        }
        test("Samsung package slots map BL AP CSC and HOME_CSC") {
            val plan = VendorPackagePlan.samsung(listOf("BL_x.tar.md5", "AP_x.tar.md5", "CSC_x.tar.md5", "HOME_CSC_x.tar.md5"))
            check(plan.slots.first { it.type == VendorPackagePlan.SamsungSlot.BL }.fileName == "BL_x.tar.md5")
            check(plan.slots.first { it.type == VendorPackagePlan.SamsungSlot.HOME_CSC }.fileName == "HOME_CSC_x.tar.md5")
            check(plan.readyForHardwareTransfer)
        }
        test("Xiaomi script inspection rejects unsafe archive paths") {
            val plan = VendorPackagePlan.xiaomi(listOf("images/boot.img", "flash_all.bat", "../../evil.sh"))
            check(plan.scripts.contains("flash_all.bat") && plan.files.none { it.contains("..") })
        }
        test("Samsung plan requires CSC or HOME_CSC") {
            val plan = VendorPackagePlan.samsung(listOf("BL_x.tar.md5", "AP_x.tar.md5"))
            check(!plan.readyForHardwareTransfer && plan.warnings.any { it.contains("CSC") })
        }
        test("Vivo Oppo Realme archive inventory remains read-only") {
            val plan = VendorPackagePlan.inspectOemArchive("Realme", listOf("images/boot.img", "RMX1234/metadata.txt", "../unsafe.img"))
            check(plan.partitionImages == listOf("images/boot.img") && plan.modelHints.contains("RMX1234"))
            check(plan.warnings.any { it.contains("not inferred") })
        }
        test("Backup preflight requires active session and explicit confirmation") {
            val result = FlashPreflight.evaluate(FlashPreflightInput(FlashOperation.BACKUP, true, true, true, true, true, true, true, true, false))
            check(!result.allowed && result.blockers.single().contains("confirmation"))
        }
        println("SIMULATION_RESULT passed=$passed failed=0")
    }

    private fun indexOfBytes(source: ByteArray, target: ByteArray): Int {
        for (i in 0..source.size - target.size) if (target.indices.all { source[i + it] == target[it] }) return i
        return -1
    }

    private fun validGptImage(overlap: Boolean = false): ByteArray {
        val sector = 512; val image = ByteArray(sector * 8)
        val entry = ByteArray(128); val e = ByteBuffer.wrap(entry).order(ByteOrder.LITTLE_ENDIAN)
        e.putInt(0, 0xA2A0D0E5.toInt()); e.putLong(32, 2); e.putLong(40, if (overlap) 4 else 3)
        "boot".toByteArray(Charsets.UTF_16LE).copyInto(entry, 56)
        val entriesCrc = CRC32().apply { update(entry) }.value
        entry.copyInto(image, sector * 2)
        val h = image.copyOfRange(sector, sector * 2); val b = ByteBuffer.wrap(h).order(ByteOrder.LITTLE_ENDIAN)
        "EFI PART".toByteArray().copyInto(h); b.putInt(8, 0x00010000); b.putInt(12, 92); b.putInt(16, 0)
        b.putLong(24, 1); b.putLong(32, 7); b.putLong(40, 2); b.putLong(48, 6); b.putLong(72, 2)
        b.putInt(80, 1); b.putInt(84, 128); b.putInt(88, entriesCrc.toInt())
        val crc = CRC32().apply { update(h.copyOfRange(0, 92)) }.value; b.putInt(16, crc.toInt())
        h.copyInto(image, sector); return image
    }
}
