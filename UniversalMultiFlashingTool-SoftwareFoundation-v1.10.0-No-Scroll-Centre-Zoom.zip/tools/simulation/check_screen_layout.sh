#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
UI="$ROOT/app/src/main/java/com/universalflasher/app/MainActivity.kt"

# Strict no-scroll contract: no scroll containers or scroll-state APIs in the main UI.
if grep -En 'verticalScroll|horizontalScroll|rememberScrollState|LazyColumn|LazyRow|\.scrollable\(' "$UI"; then
  echo 'FAIL | scroll modifier/container remains in MainActivity.kt'
  exit 1
fi
# Centre-anchored pinch zoom, with no pan/translation behavior.
grep -Fq 'detectTransformGestures { _, _, zoomChange, _ ->' "$UI"
grep -Fq 'zoom = (zoom * zoomChange).coerceIn(0.35f, 2.8f)' "$UI"
grep -Fq 'transformOrigin = TransformOrigin.Center' "$UI"
grep -Fq 'translationX = 0f' "$UI"
grep -Fq 'translationY = 0f' "$UI"
grep -Fq 'val canvasHeight = maxOf(maxHeight, 900.dp)' "$UI"
grep -Fq 'maxLines = 10' "$UI"
if grep -Eq 'panX|panY|rememberScrollState|verticalScroll' "$UI"; then
  echo 'FAIL | stale pan/scroll state remains'
  exit 1
fi
echo 'PASS | no scroll containers; fixed extended canvas; centre-anchored pinch-only zoom; no drag-pan; ADB result is fixed/non-scrollable'
