# Screen Fit and Centre Pinch Zoom — v1.10.0

- The app workspace is a fixed extended-height canvas (minimum 900dp), not a vertically scrollable page.
- All page-level and nested Compose scrolling containers were removed from the main UI source.
- Two-finger pinch zoom scales the complete workspace from 0.35× to 2.8× around the centre of the visible viewport.
- Single-finger dragging does not pan or scroll the workspace; zoom remains centre-anchored.
- ADB RESULT is a fixed non-scrollable area showing the latest result (up to 10 lines); detailed logs remain available through the existing log/export workflow.
- Maximize resets zoom to 1×.

## Verification boundary
- Source audit checks for absence of scroll modifiers and confirms centre-pinch zoom.
- This is a source-level correction. APK compilation and real-device touch testing require an Android build environment and device/emulator.
