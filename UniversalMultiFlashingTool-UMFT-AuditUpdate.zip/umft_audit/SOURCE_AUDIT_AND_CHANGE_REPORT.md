# Universal Multi Flashing Tool — Source Audit & Change Report

Audit input: uploaded `UMFT.zip` (3,855,600 bytes), extracted without errors.

## Project identity
- Android application using Kotlin and Jetpack Compose.
- Namespace/application ID: `com.universalflasher.app` (preserved).
- Compile SDK 35, min SDK 26, target SDK 35.
- AGP 8.7.3, Kotlin 2.0.21, Java/JVM 17.
- 104 files in the extracted archive; Android manifest, Gradle Kotlin DSL, resources, tests, simulation scripts and GitHub Actions workflow are present.

## Existing functionality inventory
- MainActivity Compose landscape dashboard, sidebar navigation, firmware picker, log/progress areas, zoom/pan and floating shortcut service.
- USB host enumeration, permission helper/receiver and USB diagnostics.
- Qualcomm: Sahara protocol, programmer transfer/validation, Firehose protocol/session, package/XML inspection and engine entry points.
- MediaTek: BROM protocol/session, DA package inspection/transfer, scatter inspection and XML DA protocol helpers.
- Samsung: TAR/TAR.MD5 package inspection, Odin/Thor handshake/packet codec, response and PIT parsing.
- Firmware: package inspection and SHA-256 calculation.
- Partition: primary GPT reader and Firehose-backed backup/restore/erase service with guards.
- ADB: USB transport, RSA AUTH/CNXN and shell_v2 host session.
- Fastboot: USB transport and limited diagnostic/getvar path.
- Flash job lifecycle state machine and deterministic JVM simulation suite.

## UI/navigation inventory
Home, All Brands, ADB Tools, Fastboot Tools, Recovery Tools, Firmware Backup, IMEI Tools, Utilities, Settings and About are implemented in the existing MainActivity navigation. Existing dashboard assets and styles are retained.

## Protocol/engine capability findings
The project’s own `EngineContracts.kt`, `IMPLEMENTATION_STATUS.md`, README and implementation sources classify Qualcomm, MediaTek, Samsung, GPT and Flash Job Manager as partial or hardware-dependent. The source explicitly says vendor write engines are not yet connected to a production flash job runner. Samsung full XMIT transfer, full MediaTek device-specific storage data flow, full Xiaomi/Vivo/Oppo/Realme engines, full Android Keystore ADB identity integration, complete Fastboot runtime coverage and real-device acceptance are not established by this archive.

## Missing/incomplete or unverified areas
- Automatic exact model/chipset/protocol identification and dynamic single-workspace vendor profile switching are not implemented as a verified end-to-end flow.
- Disconnect handling previously cleared the last device label; fixed in this update to retain the last label and show a disconnected session state.
- Samsung five-slot BL/AP/CP/CSC/HOME_CSC UI and complete XMIT flashing are not present as a verified implementation.
- No verified universal Xiaomi Mi Flash-style, Vivo, Oppo or Realme write engine was found.
- Destructive operations are not orchestrated through a complete production hardware worker.
- Hardware compatibility, OEM authentication, trusted programmer/DA provenance and firmware publisher trust require external model-specific evidence.

## Duplicate implementations
No duplicate production flashing engine was confirmed in this source review. Multiple protocol/helper layers are intentionally separate (protocol, session, inspector and engine facade).

## Dependency/build risks
- No Gradle wrapper JAR/scripts are included; the GitHub Actions workflow provisions Gradle 8.9.
- Local environment has no Android SDK/ANDROID_HOME and no Gradle executable, so Android compilation and APK assembly cannot be run here.
- Existing workflow runs layout script, unit tests and assembleDebug. It is retained unchanged.
- Hardware USB endpoints, permissions, device modes and OEM-specific protocol behavior need real device tests.

## Change-impact map
| Area | Existing state | Change | Scope |
|---|---|---|---|
| Main UI | Existing Compose dashboard | None | Untouched |
| USB disconnect state | Last device label cleared | Retain last label; mark session disconnected | MainActivity only |
| Device detection | USB descriptors + protocol diagnostics; exact model not automatic | No new claims or heuristics added | Untouched |
| Qualcomm/Samsung/MediaTek engines | Partial protocol implementations | None | Untouched |
| Xiaomi/Vivo/Oppo/Realme | No verified complete write engines | None | Untouched |
| Firmware/partition | Existing parsers and guarded services | None | Untouched |
| Navigation/theme/assets | Existing | None | Untouched |
| CI/build config/dependencies | Existing | None | Untouched |

## Modified files
1. `app/src/main/java/com/universalflasher/app/MainActivity.kt`
   - USB detach now sets `Disconnected · session closed` without clearing the last device identity.
   - Refresh with no attached USB device preserves the last identity and sets disconnected state.
   - Existing Flash preflight requires exact status `Connected`, so disconnected state remains blocked.
   - No layout, styling, navigation or asset code changed.
2. `SOURCE_AUDIT_AND_CHANGE_REPORT.md`
   - Added this audit and implementation record.

## Validation performed
- ZIP extraction: passed.
- `bash tools/simulation/run.sh`: 20 passed, 0 failed.
- `bash tools/simulation/check_screen_layout.sh`: passed.
- Android Gradle build/APK: not run; Gradle and Android SDK are unavailable in this environment.
- Emulator/physical USB and hardware flashing: not run.

## Honest completion snapshot
Percentages below describe the requested project scope supported by this audit, not planned work. They are conservative source-level estimates, not hardware acceptance scores.
| Category | Status | Completion |
|---|---|---:|
| Dynamic Main Workspace | Missing | 10% |
| Device Detection | Partial | 30% |
| Samsung Engine | Partial | 35% |
| Qualcomm Engine | Partial | 55% |
| MediaTek Engine | Partial | 40% |
| Xiaomi Engine | Missing | 5% |
| Vivo / Oppo / Realme | Missing | 5% |
| Firmware Analyzer | Partial | 45% |
| Partition Management | Partial | 50% |
| Writing / Flashing | Partial | 20% |
| ADB / Fastboot | Partial | 45% |
| UI Preservation | Verified at source/layout-check level | 98% |
| Build Stability | Not verified | 0% |

## Limitations and next acceptance steps
Run the GitHub Actions workflow or a local Android Gradle build, inspect the generated APK on target Android versions, then test each protocol only with authorized, exact-model hardware and trusted OEM firmware/programmer/DA assets. Do not treat protocol simulations as device flashing results. Security/authorization controls are not bypassed.
