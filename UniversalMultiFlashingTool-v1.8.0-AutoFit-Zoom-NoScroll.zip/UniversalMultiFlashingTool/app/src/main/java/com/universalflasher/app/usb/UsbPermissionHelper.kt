package com.universalflasher.app.usb

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager

object UsbPermissionHelper {
    const val ACTION_USB_PERMISSION = "com.universalflasher.app.USB_PERMISSION"
    fun request(context: Context, device: UsbDevice) {
        val manager = context.getSystemService(Context.USB_SERVICE) as UsbManager
        val intent = Intent(context, UsbPermissionReceiver::class.java).setAction(ACTION_USB_PERMISSION)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or if (android.os.Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0
        val pending = PendingIntent.getBroadcast(context, device.deviceId, intent, flags)
        manager.requestPermission(device, pending)
    }
}
