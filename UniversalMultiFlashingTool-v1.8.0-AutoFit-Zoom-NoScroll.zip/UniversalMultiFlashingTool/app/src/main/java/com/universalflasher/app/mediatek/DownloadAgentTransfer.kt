package com.universalflasher.app.mediatek

import java.io.InputStream
import java.io.OutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** MediaTek XFlash/V5 Download Agent framing (12-byte FEEEEEEF envelope). */
object XFlashDaProtocol {
    const val MAGIC = 0xFEEEEEEFu
    const val TYPE_PROTOCOL_FLOW = 1
    const val TYPE_MESSAGE = 2
    const val MAX_FRAME = 16 * 1024 * 1024
    data class Frame(val type: Int, val payload: ByteArray)

    fun encode(payload: ByteArray, type: Int = TYPE_PROTOCOL_FLOW): ByteArray {
        require(type in TYPE_PROTOCOL_FLOW..TYPE_MESSAGE && payload.size <= MAX_FRAME)
        return ByteBuffer.allocate(12 + payload.size).order(ByteOrder.LITTLE_ENDIAN)
            .putInt(MAGIC.toInt()).putInt(type).putInt(payload.size).put(payload).array()
    }
    fun decode(bytes: ByteArray): Frame {
        require(bytes.size >= 12)
        val b=ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        require(b.int.toUInt()==MAGIC) { "Invalid MediaTek XFlash magic" }
        val type=b.int; val length=b.int
        require(type in TYPE_PROTOCOL_FLOW..TYPE_MESSAGE && length in 0..MAX_FRAME && length==bytes.size-12)
        return Frame(type,bytes.copyOfRange(12,bytes.size))
    }
    fun read(input: InputStream): Frame {
        val h=ByteArray(12); readFully(input,h)
        val b=ByteBuffer.wrap(h).order(ByteOrder.LITTLE_ENDIAN); require(b.int.toUInt()==MAGIC)
        val type=b.int; val len=b.int; require(type in TYPE_PROTOCOL_FLOW..TYPE_MESSAGE && len in 0..MAX_FRAME)
        val p=ByteArray(len); if(len>0)readFully(input,p)
        return Frame(type,p)
    }
    fun write(output: OutputStream, payload: ByteArray, type: Int = TYPE_PROTOCOL_FLOW) { output.write(encode(payload,type));output.flush() }
    private fun readFully(i:InputStream,b:ByteArray){var p=0;while(p<b.size){val n=i.read(b,p,b.size-p);if(n<0)throw IllegalStateException("MediaTek DA transport closed");if(n>0)p+=n}}
}

/** XFlash flow helpers: command/status framing only; per-device DA command IDs remain explicit. */
class XFlashDaSession(private val input: InputStream, private val output: OutputStream) {
    fun sendU32(value: Long) { require(value in 0..0xffffffffL); XFlashDaProtocol.write(output,ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(value.toInt()).array()) }
    fun receiveU32(): Long { val f=XFlashDaProtocol.read(input);require(f.payload.size>=4);return ByteBuffer.wrap(f.payload).order(ByteOrder.LITTLE_ENDIAN).int.toLong() and 0xffffffffL }
    fun requireSuccess() { val status=receiveU32();check(status==0L){"MediaTek XFlash DA returned status 0x${status.toString(16)}"} }
    /** Executes an explicit XFlash command and checks each framed parameter acknowledgement. */
    fun executeCommand(opcode:Long,parameters:List<ByteArray> = emptyList()) {
        sendU32(opcode);requireSuccess()
        parameters.forEach { parameter ->
            require(parameter.size<=XFlashDaProtocol.MAX_FRAME)
            XFlashDaProtocol.write(output,parameter);requireSuccess()
        }
    }
    /** Sends a data stream in protocol frames; each frame is ACKed before the next one. */
    fun sendData(data:InputStream,totalBytes:Long,chunkSize:Int=0x200,onProgress:(Long,Long)->Unit={_,_->}) {
        require(totalBytes>=0 && chunkSize in 1..0x20000)
        var sent=0L;val buffer=ByteArray(chunkSize)
        while(sent<totalBytes){val wanted=minOf(chunkSize.toLong(),totalBytes-sent).toInt();var nread=0
            while(nread<wanted){val n=data.read(buffer,nread,wanted-nread);if(n<0)throw IllegalStateException("MediaTek DA source ended early");if(n>0)nread+=n}
            XFlashDaProtocol.write(output,buffer.copyOf(wanted));requireSuccess();sent+=wanted;onProgress(sent,totalBytes)
        }
    }
    fun readData(destination:OutputStream,totalBytes:Long,chunkSize:Int=0x200,onProgress:(Long,Long)->Unit={_,_->}) {
        require(totalBytes>=0 && chunkSize in 1..0x20000);var received=0L
        while(received<totalBytes){val frame=XFlashDaProtocol.read(input);require(frame.payload.isNotEmpty() && frame.payload.size<=chunkSize && frame.payload.size<=totalBytes-received);destination.write(frame.payload);sendU32(0);received+=frame.payload.size;onProgress(received,totalBytes)}
        destination.flush()
    }
}
