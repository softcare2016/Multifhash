package com.universalflasher.app.jobs

import java.util.concurrent.atomic.AtomicReference

enum class FlashJobState { IDLE, QUEUED, RUNNING, PAUSED, CANCELLING, CANCELLED, SUCCEEDED, FAILED }
data class FlashJobSnapshot(val state: FlashJobState, val completedBytes: Long, val totalBytes: Long, val message: String) {
    val progress: Float get() = if (totalBytes <= 0) 0f else (completedBytes.toDouble()/totalBytes).toFloat().coerceIn(0f,1f)
}
/** Lifecycle-safe job state machine. Protocol workers must call checkpoints before each transfer block. */
class FlashJob {
    private val state = AtomicReference(FlashJobSnapshot(FlashJobState.IDLE,0,0,"Idle"))
    fun snapshot() = state.get()
    fun queue(total: Long) { require(total >= 0); transition(setOf(FlashJobState.IDLE,FlashJobState.SUCCEEDED,FlashJobState.FAILED,FlashJobState.CANCELLED), FlashJobSnapshot(FlashJobState.QUEUED,0,total,"Queued")) }
    fun start() = transition(setOf(FlashJobState.QUEUED,FlashJobState.PAUSED), snapshot().copy(state=FlashJobState.RUNNING,message="Running"))
    fun pause() = transition(setOf(FlashJobState.RUNNING), snapshot().copy(state=FlashJobState.PAUSED,message="Paused"))
    fun resume() = start()
    fun cancel() = transition(setOf(FlashJobState.QUEUED,FlashJobState.RUNNING,FlashJobState.PAUSED), snapshot().copy(state=FlashJobState.CANCELLING,message="Cancellation requested"))
    fun checkpoint(bytes: Long) {
        while(true) { val old=state.get(); if(old.state==FlashJobState.CANCELLING){state.compareAndSet(old,old.copy(state=FlashJobState.CANCELLED,message="Cancelled at safe checkpoint"));return}; require(old.state==FlashJobState.RUNNING || old.state==FlashJobState.PAUSED); if(old.state==FlashJobState.PAUSED) throw IllegalStateException("Job paused"); val next=old.copy(completedBytes=(old.completedBytes+bytes).coerceAtMost(old.totalBytes)); if(state.compareAndSet(old,next)) return }
    }
    fun succeed() = transition(setOf(FlashJobState.RUNNING), snapshot().copy(state=FlashJobState.SUCCEEDED,completedBytes=snapshot().totalBytes,message="Completed"))
    fun fail(reason: String) = transition(setOf(FlashJobState.RUNNING,FlashJobState.CANCELLING), snapshot().copy(state=FlashJobState.FAILED,message=reason))
    private fun transition(from:Set<FlashJobState>, next:FlashJobSnapshot) { while(true){val old=state.get();check(old.state in from){"Invalid job transition ${old.state} -> ${next.state}"};if(state.compareAndSet(old,next))return} }
}
