package com.universalflasher.app.adb

import java.io.InputStream
import java.io.OutputStream
import java.math.BigInteger
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.KeyFactory
import java.security.Signature
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.X509EncodedKeySpec
import java.io.File
import java.util.Base64

/** ADB AUTH token signing and host public-key encoding (RSA-2048). */
class AdbRsaIdentity(private val keyPair: KeyPair = KeyPairGenerator.getInstance("RSA").apply { initialize(2048) }.generateKeyPair()) {
    companion object {
        /** Loads or creates an app-private ADB identity so the authorization key remains stable across launches. */
        fun loadOrCreate(directory: File): AdbRsaIdentity {
            require(directory.exists() || directory.mkdirs()) { "Cannot create ADB identity directory" }
            val privateFile=File(directory,"adb_host.pk8");val publicFile=File(directory,"adb_host.x509")
            val factory=KeyFactory.getInstance("RSA")
            if(privateFile.isFile && publicFile.isFile){
                val privateKey=factory.generatePrivate(PKCS8EncodedKeySpec(privateFile.readBytes()))
                val publicKey=factory.generatePublic(X509EncodedKeySpec(publicFile.readBytes()))
                return AdbRsaIdentity(KeyPair(publicKey,privateKey))
            }
            val pair=KeyPairGenerator.getInstance("RSA").apply{initialize(2048)}.generateKeyPair()
            privateFile.writeBytes(pair.private.encoded);publicFile.writeBytes(pair.public.encoded)
            privateFile.setReadable(false,false);privateFile.setWritable(false,false);privateFile.setReadable(true,true);privateFile.setWritable(true,true)
            publicFile.setReadable(true,true);publicFile.setWritable(false,false)
            return AdbRsaIdentity(pair)
        }
    }
    fun sign(token: ByteArray): ByteArray = Signature.getInstance("SHA1withRSA").run { initSign(keyPair.private);update(token);sign() }
    fun publicKeyLine(comment: String = "universal-multi-flasher@android"): ByteArray {
        val key=keyPair.public as java.security.interfaces.RSAPublicKey
        val n=key.modulus;val radix=BigInteger.ONE.shiftLeft(32)
        val n0inv=radix.subtract(n.mod(radix).modInverse(radix)).mod(radix).toLong()
        val rr=BigInteger.ONE.shiftLeft(4096).mod(n)
        val out=ByteBuffer.allocate(524).order(ByteOrder.LITTLE_ENDIAN)
        out.putInt(64);out.putInt(n0inv.toInt());putLittleWords(out,n,64);putLittleWords(out,rr,64);out.putInt(key.publicExponent.toInt())
        return (Base64.getEncoder().encodeToString(out.array())+" $comment\u0000").toByteArray(Charsets.US_ASCII)
    }
    private fun putLittleWords(out:ByteBuffer,value:BigInteger,words:Int){
        val raw=value.toByteArray();val little=ByteArray(words*4)
        for(i in 0 until minOf(raw.size,little.size)) little[i]=raw[raw.size-1-i]
        for(i in 0 until words){val p=i*4;out.putInt((little[p].toInt() and 255) or ((little[p+1].toInt() and 255) shl 8) or ((little[p+2].toInt() and 255) shl 16) or ((little[p+3].toInt() and 255) shl 24))}
    }
}

/** Complete ADB transport negotiation through AUTH; caller supplies USB bulk input/output streams. */
class AdbHostSession(private val input:InputStream,private val output:OutputStream,private val identity:AdbRsaIdentity=AdbRsaIdentity()) {
    enum class State { DISCONNECTED, CNXN_SENT, AUTH_SIGNED, PUBLIC_KEY_SENT, AUTHORIZED, FAILED }
    var state=State.DISCONNECTED;private set
    fun connect(maxRounds:Int=6):String {
        check(state==State.DISCONNECTED)
        try {
            send(AdbPacket("CNXN",0x01000000,1024*1024,"host::features=shell_v2,cmd,stat_v2,ls_v2\u0000".toByteArray()))
            state=State.CNXN_SENT
            repeat(maxRounds){
                val p=receive()
                when(p.command){
                    "CNXN"->{state=State.AUTHORIZED;return String(p.payload,Charsets.UTF_8).trimEnd('\u0000')}
                    "AUTH"->{
                        when(p.arg0){
                            1->{send(AdbPacket("AUTH",2,0,identity.sign(p.payload)));state=State.AUTH_SIGNED}
                            3->{send(AdbPacket("AUTH",3,0,identity.publicKeyLine()));state=State.PUBLIC_KEY_SENT}
                            else->error("Unsupported ADB AUTH type ${p.arg0}")
                        }
                    }
                    else->error("Unexpected ADB handshake packet ${p.command}")
                }
            }
            error("ADB authorization did not complete; accept the RSA prompt on the device and reconnect")
        }catch(t:Throwable){state=State.FAILED;throw t}
    }
    fun send(packet:AdbPacket){val bytes=packet.encode();output.write(bytes);output.flush()}
    fun receive(maxPayload:Int=1024*1024):AdbPacket {
        val header=ByteArray(24);readFully(input,header)
        val len=ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN).getInt(12)
        require(len in 0..maxPayload)
        val payload=ByteArray(len);if(len>0)readFully(input,payload)
        return AdbPacket.decode(header,payload,maxPayload)
    }
    private fun readFully(i:InputStream,b:ByteArray){var p=0;while(p<b.size){val n=i.read(b,p,b.size-p);if(n<0)throw IllegalStateException("ADB transport closed");if(n>0)p+=n}}
}

/** Executes a shell_v2 command over an authorized ADB session. No root escalation is attempted. */
class AdbShellService(private val session:AdbHostSession) {
    data class Result(val stdout:String,val stderr:String,val exitCode:Int?)
    fun execute(command:String,localId:Int=1,maxBytes:Int=8*1024*1024):Result {
        require(command.isNotBlank() && command.length<=8192 && '\u0000' !in command)
        session.send(AdbPacket("OPEN",localId,0,"shell,v2,raw:$command\u0000".toByteArray(Charsets.UTF_8)))
        var remoteId:Int?=null;val stdout=java.io.ByteArrayOutputStream();val stderr=java.io.ByteArrayOutputStream();var exit:Int?=null;var total=0
        while(exit==null){
            val p=session.receive(maxBytes)
            when(p.command){
                "OKAY"->{require(p.arg1==localId);remoteId=p.arg0}
                "WRTE"->{
                    require(remoteId!=null && p.arg0==remoteId && p.arg1==localId)
                    var pos=0
                    while(pos+5<=p.payload.size){val id=p.payload[pos].toInt() and 255;val len=ByteBuffer.wrap(p.payload,pos+1,4).order(ByteOrder.LITTLE_ENDIAN).int;pos+=5;require(len>=0 && pos+len<=p.payload.size);val chunk=p.payload.copyOfRange(pos,pos+len);pos+=len;total+=len;require(total<=maxBytes)
                        when(id){1->stdout.write(chunk);2->stderr.write(chunk);3->{require(chunk.isNotEmpty());exit=chunk[0].toInt() and 255};else->Unit}
                    }
                    session.send(AdbPacket("OKAY",localId,remoteId,byteArrayOf()))
                }
                "CLSE"->{session.send(AdbPacket("CLSE",localId,p.arg0,byteArrayOf()));exit=-1}
                else->error("Unexpected ADB shell packet ${p.command}")
            }
        }
        return Result(stdout.toString("UTF-8"),stderr.toString("UTF-8"),exit)
    }
}
