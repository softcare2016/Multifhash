package com.universalflasher.app.adb

import java.nio.ByteBuffer
import java.nio.ByteOrder

/** ADB wire packet codec (host protocol framing). Authentication and command execution are separate states. */
data class AdbPacket(val command: String, val arg0: Int, val arg1: Int, val payload: ByteArray) {
    init { require(command.length == 4 && command.all { it.code in 0x20..0x7e }) }
    fun encode(): ByteArray {
        val cmd = command.toByteArray(Charsets.US_ASCII)
        val checksum = payload.fold(0L) { a, b -> (a + (b.toInt() and 0xff)) and 0xffffffffL }.toInt()
        val out = ByteBuffer.allocate(24 + payload.size).order(ByteOrder.LITTLE_ENDIAN)
        out.put(cmd); out.putInt(arg0); out.putInt(arg1); out.putInt(payload.size); out.putInt(checksum)
        out.put(cmd.map { (it.toInt() xor 0xff).toByte() }.toByteArray()); out.put(payload)
        return out.array()
    }
    companion object {
        fun decode(header: ByteArray, payload: ByteArray, maxPayload: Int = 1024 * 1024): AdbPacket {
            require(header.size == 24) { "ADB header must be 24 bytes" }
            val b = ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN)
            val cmdBytes = ByteArray(4); b.get(cmdBytes)
            val command = String(cmdBytes, Charsets.US_ASCII)
            val arg0 = b.int; val arg1 = b.int; val length = b.int; val checksum = b.int; val magic = b.int
            val commandWord = ByteBuffer.wrap(cmdBytes).order(ByteOrder.LITTLE_ENDIAN).int
            require(length in 0..maxPayload && payload.size == length) { "Invalid ADB payload length" }
            require(magic == (commandWord xor -1)) { "ADB command magic mismatch" }
            val actual = payload.fold(0L) { a, v -> (a + (v.toInt() and 0xff)) and 0xffffffffL }.toInt()
            require(actual == checksum) { "ADB checksum mismatch" }
            return AdbPacket(command, arg0, arg1, payload)
        }
    }
}

enum class AdbSessionState { DISCONNECTED, TRANSPORT_OPEN, AUTH_REQUIRED, AUTHORIZED, FAILED }
