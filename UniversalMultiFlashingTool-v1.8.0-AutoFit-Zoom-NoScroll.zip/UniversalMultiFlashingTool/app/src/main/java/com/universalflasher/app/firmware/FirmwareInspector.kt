package com.universalflasher.app.firmware

import android.content.ContentResolver
import android.net.Uri
import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.BufferedInputStream
import java.security.MessageDigest
import java.util.zip.ZipFile

/** Read-only package inspection. Never writes to a connected device. */
data class FirmwareReport(
    val displayName: String,
    val sizeBytes: Long,
    val sha256: String,
    val detectedType: String,
    val warnings: List<String> = emptyList()
)

data class ScatterEntry(val partition: String, val fileName: String, val startAddress: String, val size: String)

object FirmwareInspector {
    data class Report(val displayName: String, val sizeBytes: Long, val sha256: String, val detectedType: String, val warnings: List<String>, val partitionNames: List<String>)

    fun inspect(resolver: ContentResolver, uri: Uri, displayName: String): Report {
        val digest = MessageDigest.getInstance("SHA-256")
        var size = 0L
        val header = ByteArray(4096)
        var headerCount = 0
        resolver.openInputStream(uri)?.use { raw ->
            BufferedInputStream(raw).use { input ->
                val buffer = ByteArray(64 * 1024)
                while (true) {
                    val n = input.read(buffer)
                    if (n < 0) break
                    if (headerCount < header.size) {
                        val copy = minOf(n, header.size - headerCount)
                        System.arraycopy(buffer, 0, header, headerCount, copy)
                        headerCount += copy
                    }
                    digest.update(buffer, 0, n)
                    size += n
                }
            }
        } ?: throw IllegalArgumentException("Cannot open selected firmware")
        val type = detectType(displayName, header, headerCount)
        val warnings = mutableListOf<String>()
        if (size == 0L) warnings += "The selected file is empty."
        if (type == "Unknown") warnings += "File type is not recognized; no flashing operation is permitted."
        val partitionNames = when {
            displayName.endsWith(".txt", true) -> runCatching { resolver.openInputStream(uri)?.bufferedReader()?.use { parseScatter(it.readText()).map { row -> row.partition } }.orEmpty() }.getOrDefault(emptyList())
            displayName.contains("rawprogram", true) && displayName.endsWith(".xml", true) -> runCatching { resolver.openInputStream(uri)?.use { parseRawProgramXml(it).mapNotNull { row -> row["label"] ?: row["filename"] } }.orEmpty() }.getOrDefault(emptyList())
            else -> emptyList()
        }
        return Report(displayName, size, digest.digest().joinToString("") { "%02x".format(it) }, type, warnings, partitionNames)
    }

    private fun detectType(name: String, bytes: ByteArray, count: Int): String {
        val lower = name.lowercase()
        if (lower.endsWith(".zip")) return "ZIP package (inspection required)"
        if (lower.endsWith(".tar") || lower.endsWith(".md5")) return "Samsung TAR/MD5 package (inspection required)"
        if (lower.endsWith(".xml") && lower.contains("rawprogram")) return "Qualcomm rawprogram XML"
        if (lower.endsWith(".txt") && lower.contains("scatter")) return "MediaTek scatter text"
        if (count >= 4 && bytes[0] == 0x3a.toByte() && bytes[1] == 0xff.toByte() && bytes[2] == 0x26.toByte() && bytes[3] == 0xed.toByte()) return "Android sparse image"
        if (count >= 8 && String(bytes, 0, 8, Charsets.US_ASCII) == "ANDROID!") return "Android boot image"
        if (lower.endsWith(".img")) return "IMG image (format requires deeper inspection)"
        if (lower.endsWith(".bin")) return "Binary image (format unknown)"
        return "Unknown"
    }

    fun parseScatter(text: String): List<ScatterEntry> {
        val result = mutableListOf<ScatterEntry>()
        val block = Regex("""(?ms)^\s*-\s*partition_index:.*?(?=^\s*-\s*partition_index:|\z)""")
        for (match in block.findAll(text)) {
            val value = match.value
            fun field(key: String) = Regex("(?m)^\\s*${Regex.escape(key)}\\s*:\\s*([^\\r\\n#]+)").find(value)?.groupValues?.get(1)?.trim().orEmpty()
            val name = field("partition_name")
            if (name.isNotBlank()) result += ScatterEntry(name, field("file_name"), field("linear_start_addr"), field("partition_size"))
        }
        return result
    }

    fun parseRawProgramXml(input: java.io.InputStream): List<Map<String, String>> {
        val parser = Xml.newPullParser().apply { setInput(input, "UTF-8") }
        val rows = mutableListOf<Map<String, String>>()
        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            if (event == XmlPullParser.START_TAG && parser.name == "program") {
                val row = linkedMapOf<String, String>()
                for (i in 0 until parser.attributeCount) row[parser.getAttributeName(i)] = parser.getAttributeValue(i)
                rows += row
            }
            event = parser.next()
        }
        return rows
    }
}
