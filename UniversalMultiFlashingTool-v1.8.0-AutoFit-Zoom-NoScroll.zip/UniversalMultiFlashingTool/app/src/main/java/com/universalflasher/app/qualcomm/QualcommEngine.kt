package com.universalflasher.app.qualcomm

import java.io.File
import java.io.RandomAccessFile
import java.security.MessageDigest

/** Offline validation and session composition for authorized Qualcomm service packages. */
object QualcommEngine {
    data class ProgrammerValidation(val file: File, val size: Long, val sha256: String, val accepted: Boolean, val reason: String)
    fun validateProgrammer(file: File, expectedSha256: String, minBytes: Long = 1024): ProgrammerValidation {
        require(expectedSha256.matches(Regex("(?i)[0-9a-f]{64}"))) { "A trusted SHA-256 digest is required" }
        require(file.isFile && file.length() >= minBytes && file.length() <= 512L*1024*1024) { "Programmer file size is invalid" }
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().buffered().use { input -> val buf = ByteArray(64*1024); while (true) { val n=input.read(buf); if(n<0) break; digest.update(buf,0,n) } }
        val actual = digest.digest().joinToString("") { "%02x".format(it) }
        val ok = actual.equals(expectedSha256, true)
        return ProgrammerValidation(file, file.length(), actual, ok, if (ok) "Digest matches trusted manifest" else "Programmer digest mismatch")
    }

    fun readLiveGpt(session: FirehoseSession, physicalPartition: Int = 0, sectorSize: Int = 512): com.universalflasher.app.partition.GptReport {
        require(physicalPartition >= 0 && sectorSize in setOf(512,4096))
        val sectors = if (sectorSize == 512) 34L else 6L
        val bytes = java.io.ByteArrayOutputStream((sectors*sectorSize).toInt())
        session.readPartitionTo(0, sectors, bytes, physicalPartition, sectorSize)
        return com.universalflasher.app.partition.GptReader.readReport(bytes.toByteArray().inputStream(), sectorSize)
    }

    fun uploadAuthorizedProgrammer(input: java.io.InputStream, output: java.io.OutputStream, programmer: File, expectedSha256: String,
                                   onProgress: (Long,Long)->Unit = {_,_->}): SaharaProgrammerTransfer.State {
        val validation=validateProgrammer(programmer,expectedSha256)
        require(validation.accepted) { validation.reason }
        RandomAccessFile(programmer, "r").use { raf ->
            val session = SaharaProgrammerTransfer(input, output, raf)
            session.run(onProgress)
            return session.state
        }
    }
}
