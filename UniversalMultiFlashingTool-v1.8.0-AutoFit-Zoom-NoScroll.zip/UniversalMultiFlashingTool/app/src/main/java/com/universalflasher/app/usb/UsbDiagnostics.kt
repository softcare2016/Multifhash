package com.universalflasher.app.usb

import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager

data class UsbDeviceReport(val name: String, val vendorId: Int, val productId: Int, val family: String, val protocolState: String, val interfaceSummary: String)

object UsbDiagnostics {
    fun scan(manager: UsbManager): List<UsbDeviceReport> = manager.deviceList.values.map { device ->
        val family = when (device.vendorId) {
            0x05c6 -> "Qualcomm USB"
            0x0e8d -> "MediaTek USB"
            0x04e8 -> "Samsung USB"
            0x18d1 -> "Google/Android USB"
            else -> "USB device"
        }
        val interfaces = (0 until device.interfaceCount).joinToString { index ->
            val intf = device.getInterface(index)
            "${intf.id}:class=${intf.interfaceClass},sub=${intf.interfaceSubclass},proto=${intf.interfaceProtocol},ep=${intf.endpointCount}"
        }.ifBlank { "No interfaces" }
        val state = if (manager.hasPermission(device)) "USB permission granted" else "USB permission required"
        UsbDeviceReport(device.deviceName, device.vendorId, device.productId, family, state, interfaces)
    }
}
