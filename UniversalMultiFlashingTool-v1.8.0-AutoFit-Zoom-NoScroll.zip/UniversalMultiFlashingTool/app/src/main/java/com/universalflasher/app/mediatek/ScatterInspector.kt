package com.universalflasher.app.mediatek

data class MtkPartition(
    val name: String, val file: String, val start: String, val size: String, val isDownload: Boolean,
    val region: String = "EMMC_USER", val storage: String = "HW_STORAGE_EMMC", val linearStart: ULong? = null, val byteSize: ULong? = null
)
object ScatterInspector {
    private val blockPattern = Regex("(?ms)^\\s*-\\s*partition_index\\s*:.*?(?=^\\s*-\\s*partition_index\\s*:|\\z)")
    fun parse(text: String): List<MtkPartition> {
        require(text.length <= 4 * 1024 * 1024) { "Scatter file too large" }
        val rows = blockPattern.findAll(text).mapNotNull { m ->
            val s = m.value
            fun f(k: String) = Regex("(?m)^\\s*${Regex.escape(k)}\\s*:\\s*([^\\r\\n#]+)").find(s)?.groupValues?.get(1)?.trim().orEmpty()
            val name = f("partition_name")
            if (name.isBlank()) null else {
                val start = f("linear_start_addr").removePrefix("0x").toULongOrNull(16)
                val size = f("partition_size").removePrefix("0x").toULongOrNull(16)
                val file = f("file_name")
                require(file.isBlank() || (!file.contains("..") && !file.contains('/') && !file.contains('\\'))) { "Unsafe scatter filename" }
                MtkPartition(name, file, f("linear_start_addr"), f("partition_size"), f("is_download").equals("true", true),
                    f("region").ifBlank { "EMMC_USER" }, f("storage").ifBlank { "HW_STORAGE_EMMC" }, start, size)
            }
        }.toList()
        require(rows.isNotEmpty()) { "No MediaTek partitions found" }
        val ranges = rows.filter { it.linearStart != null && it.byteSize != null && it.byteSize > 0uL }
            .sortedBy { it.linearStart }
        ranges.zipWithNext().forEach { (a, b) -> require(a.linearStart!! + a.byteSize!! <= b.linearStart!!) { "Overlapping scatter partitions: ${a.name} / ${b.name}" } }
        return rows
    }
}
