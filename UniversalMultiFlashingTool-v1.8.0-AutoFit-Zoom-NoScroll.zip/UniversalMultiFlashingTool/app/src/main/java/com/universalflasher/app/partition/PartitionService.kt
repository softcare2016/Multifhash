package com.universalflasher.app.partition

import com.universalflasher.app.qualcomm.FirehoseSession
import java.io.File
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.security.MessageDigest

/** File-backed partition backup/restore through an active Firehose session. */
object PartitionService {
    data class BackupResult(val file:File,val bytes:Long,val sha256:String,val partition:GptPartition)

    fun backup(session:FirehoseSession,partition:GptPartition,physicalPartition:Int,sectorSize:Int,destination:File,
               onProgress:(Long,Long)->Unit={_,_->}):BackupResult {
        require(partition.firstLba>=0 && partition.sectorCount>0 && physicalPartition>=0 && sectorSize in setOf(512,4096))
        val expected=Math.multiplyExact(partition.sectorCount,sectorSize.toLong())
        val parent=destination.absoluteFile.parentFile;require(parent.exists()||parent.mkdirs())
        val temp=File(parent,destination.name+".partial")
        try {
            temp.outputStream().buffered().use { out -> session.readPartitionTo(partition.firstLba,partition.sectorCount,out,physicalPartition,sectorSize,onProgress) }
            require(temp.length()==expected) { "Partition backup length mismatch" }
            val hash=sha256(temp)
            Files.move(temp.toPath(),destination.toPath(),StandardCopyOption.REPLACE_EXISTING)
            return BackupResult(destination,expected,hash,partition)
        } catch(t:Throwable) { temp.delete();throw t }
    }

    fun restore(session:FirehoseSession,partition:GptPartition,physicalPartition:Int,sectorSize:Int,image:File,
                modelMatched:Boolean,confirmed:Boolean,expectedSha256:String,
                onProgress:(Long,Long)->Unit={_,_->}):FirehoseSession.Result {
        require(modelMatched) { "Device/firmware model mismatch: restore blocked" }
        require(confirmed) { "Explicit restore confirmation is required" }
        require(expectedSha256.matches(Regex("(?i)[0-9a-f]{64}"))) { "Trusted SHA-256 digest is required" }
        require(partition.firstLba>=0 && partition.sectorCount>0 && physicalPartition>=0 && sectorSize in setOf(512,4096))
        val capacity=Math.multiplyExact(partition.sectorCount,sectorSize.toLong())
        require(image.isFile && image.length() in 1..capacity) { "Restore image exceeds selected partition capacity" }
        require(sha256(image).equals(expectedSha256,true)) { "Restore image digest mismatch" }
        return session.programFile(image,partition.firstLba,physicalPartition,sectorSize,onProgress)
    }

    fun erase(session:FirehoseSession,partition:GptPartition,physicalPartition:Int,sectorSize:Int,modelMatched:Boolean,confirmed:Boolean):FirehoseSession.Result {
        require(modelMatched) { "Device/firmware model mismatch: erase blocked" }
        require(confirmed) { "Explicit erase confirmation is required" }
        require(partition.firstLba>=0 && partition.sectorCount>0 && physicalPartition>=0 && sectorSize in setOf(512,4096))
        return session.erase(partition.firstLba,partition.sectorCount,physicalPartition,sectorSize,true)
    }

    fun sha256(file:File):String {
        val digest=MessageDigest.getInstance("SHA-256")
        file.inputStream().buffered().use { input -> val b=ByteArray(64*1024);while(true){val n=input.read(b);if(n<0)break;digest.update(b,0,n)} }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }
}
