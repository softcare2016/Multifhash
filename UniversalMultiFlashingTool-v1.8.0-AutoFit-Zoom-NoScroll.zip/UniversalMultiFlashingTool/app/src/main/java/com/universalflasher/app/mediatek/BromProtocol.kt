package com.universalflasher.app.mediatek

import java.io.InputStream
import java.io.OutputStream

/** MediaTek BootROM primitives based on the documented inverted-echo command protocol. */
object BromProtocol {
    val SYNC_SEQUENCE = byteArrayOf(0xA0.toByte(), 0x0A, 0x50, 0x05)
    const val ACK = 0x5A
    const val NACK = 0xA5
    const val CONT = 0x69
    const val CMD_JUMP_DA = 0xD5
    const val CMD_SEND_DA = 0xD7
    const val CMD_GET_TARGET_CONFIG = 0xD8
    const val CMD_GET_HW_SW_VERSION = 0xFC
    const val CMD_GET_HW_CODE = 0xFD
    const val MAX_DA_SIZE = 64 * 1024 * 1024

    data class TargetConfig(val slaRequired: Boolean, val daaRequired: Boolean, val swJtag: Boolean, val memRead: Boolean, val memWrite: Boolean)

    fun readByte(input: InputStream): Int = input.read().also { if (it < 0) throw IllegalStateException("MediaTek BootROM transport closed") }
    fun readExact(input: InputStream, size: Int): ByteArray { require(size in 1..MAX_DA_SIZE); val out=ByteArray(size); var p=0; while(p<size){val n=input.read(out,p,size-p);if(n<0)throw IllegalStateException("MediaTek transport closed");if(n>0)p+=n};return out }
    fun requireAck(input: InputStream) { when(val b=readByte(input)){ ACK->Unit; NACK->throw SecurityException("MediaTek target rejected command (NACK)"); else->throw IllegalStateException("Unexpected MediaTek response 0x${b.toString(16)}") } }
    fun be32(value: Long): ByteArray { require(value in 0..0xffffffffL); return byteArrayOf((value ushr 24).toByte(),(value ushr 16).toByte(),(value ushr 8).toByte(),value.toByte()) }
    fun checksumXorLeWords(data: ByteArray): Int { var result=0; var i=0; while(i<data.size){var word=0; for(j in 0..3) if(i+j<data.size) word = word or ((data[i+j].toInt() and 0xff) shl (j*8)); result = result xor word; i+=4 }; return result }
    fun parseTargetConfig(bytes: ByteArray): TargetConfig { require(bytes.size>=4){"Target config truncated"}; val f=(bytes[0].toInt() and 255) or ((bytes[1].toInt() and 255) shl 8) or ((bytes[2].toInt() and 255) shl 16) or ((bytes[3].toInt() and 255) shl 24); return TargetConfig(f and 1!=0,f and 2!=0,f and 4!=0,f and 8!=0,f and 16!=0) }
    fun validateDaImage(size: Long) { require(size in 1..MAX_DA_SIZE.toLong()) { "DA image size outside safety limit" } }
}
