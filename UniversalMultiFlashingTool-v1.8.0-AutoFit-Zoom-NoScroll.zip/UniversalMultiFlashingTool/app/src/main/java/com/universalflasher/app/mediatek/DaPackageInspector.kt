package com.universalflasher.app.mediatek

import java.io.File
import java.io.RandomAccessFile

/** Offline parser for MTK_DOWNLOAD_AGENT containers and per-SoC DA1 region metadata. */
object DaPackageInspector {
    data class Region(val fileOffset: Long,val signedLength: Long,val loadAddress: Long,val payloadLength: Long,val signatureLength: Long)
    data class Entry(val hwCode: Int,val hwSubCode: Int,val hwVersion: Int,val regions: List<Region>)
    data class Report(val version: Long,val entries: List<Entry>)

    fun inspect(file: File): Report {
        require(file.isFile && file.length() in 0x6cL..BromProtocol.MAX_DA_SIZE.toLong()) { "Invalid MediaTek DA file size" }
        RandomAccessFile(file,"r").use { raf ->
            val magic=ByteArray(18);raf.readFully(magic)
            require(String(magic,Charsets.US_ASCII).startsWith("MTK_DOWNLOAD_AGENT")) { "MTK DA signature not found" }
            raf.seek(0x60);val version=readU32(raf);val daMagic=readU32(raf);val count=readU32(raf)
            require(daMagic==0x99886622L && count in 1..128) { "Invalid MTK DA container header" }
            val tableEnd=0x6cL+count*0xdcL;require(tableEnd<=raf.length()) { "Truncated MTK DA entry table" }
            val entries=mutableListOf<Entry>()
            repeat(count.toInt()) {
                val base=0x6cL+it*0xdcL;raf.seek(base)
                require(readU16(raf)==0xDADA) { "Invalid MTK DA entry magic" }
                val hw=readU16(raf);val sub=readU16(raf);val ver=readU16(raf)
                raf.seek(base+0x12);val regionCount=readU16(raf)
                require(regionCount in 1..6) { "Unsupported MTK DA region count" }
                val regions=mutableListOf<Region>()
                repeat(regionCount) { index ->
                    raf.seek(base+0x14+index*0x20)
                    val offset=readU32(raf);val length=readU32(raf);val address=readU32(raf);val payload=readU32(raf);val sig=readU32(raf)
                    require(length>0 && payload<=length && sig<=length && offset>=tableEnd && offset+length<=raf.length()) { "MTK DA region points outside file" }
                    regions+=Region(offset,length,address,payload,sig)
                }
                entries+=Entry(hw,sub,ver,regions)
            }
            return Report(version,entries)
        }
    }
    fun select(report:Report,hwCode:Int,hwSubCode:Int?=null,hwVersion:Int?=null):Entry {
        return report.entries.firstOrNull { it.hwCode==hwCode && (hwSubCode==null || it.hwSubCode==hwSubCode) && (hwVersion==null || it.hwVersion==hwVersion) }
            ?: throw IllegalArgumentException("No DA entry matches detected MediaTek hardware code")
    }
    fun extractDa1(container:File,entry:Entry,destination:File):Pair<File,Region> {
        val region=entry.regions.first()
        val parent=destination.absoluteFile.parentFile
        require(parent.exists() || parent.mkdirs()) { "Cannot create DA output directory" }
        RandomAccessFile(container,"r").use { source -> destination.outputStream().buffered().use { out ->
            source.seek(region.fileOffset);val buffer=ByteArray(64*1024);var remaining=region.signedLength
            while(remaining>0){val n=source.read(buffer,0,minOf(buffer.size.toLong(),remaining).toInt());require(n>0){"Truncated DA1 region"};out.write(buffer,0,n);remaining-=n}
        } }
        return destination to region
    }
    private fun readU16(r:RandomAccessFile)=r.readUnsignedByte() or (r.readUnsignedByte() shl 8)
    private fun readU32(r:RandomAccessFile):Long=(r.readUnsignedByte().toLong() or (r.readUnsignedByte().toLong() shl 8) or (r.readUnsignedByte().toLong() shl 16) or (r.readUnsignedByte().toLong() shl 24))
}
