package com.universalflasher.app.mediatek

import java.io.File
import java.io.RandomAccessFile
import java.security.MessageDigest

/** MediaTek BROM + DA validators and staged session entry points. */
object MediaTekEngine {
    data class DaValidation(val file: File, val sha256: String, val matchesTrustedDigest: Boolean, val size: Long)
    fun validateDownloadAgent(file: File, expectedSha256: String): DaValidation {
        require(expectedSha256.matches(Regex("(?i)[0-9a-f]{64}"))) { "Trusted DA SHA-256 digest required" }
        BromProtocol.validateDaImage(file.length())
        val digest=MessageDigest.getInstance("SHA-256")
        file.inputStream().buffered().use { stream -> val buf=ByteArray(64*1024);while(true){val n=stream.read(buf);if(n<0)break;digest.update(buf,0,n)} }
        val hash=digest.digest().joinToString(""){ "%02x".format(it) }
        return DaValidation(file,hash,hash.equals(expectedSha256,true),file.length())
    }
    fun prepareMatchingDa1(container:File,hwCode:Int,hwSubCode:Int?=null,hwVersion:Int?=null,destination:File):Pair<File,DaPackageInspector.Region> {
        val report=DaPackageInspector.inspect(container)
        val entry=DaPackageInspector.select(report,hwCode,hwSubCode,hwVersion)
        return DaPackageInspector.extractDa1(container,entry,destination)
    }


    data class DaStartResult(val hwCode:Int,val hwSubCode:Int,val hwVersion:Int,val da1File:File,val loadAddress:Long)
    fun uploadMatchingDaAndStart(input:java.io.InputStream,output:java.io.OutputStream,container:File,stagingFile:File,
                                 expectedSha256:String,onProgress:(Long,Long)->Unit={_,_->}):DaStartResult {
        val brom=BromSession(input,output);brom.handshake();val id=brom.identifyAfterHandshake()
        val report=DaPackageInspector.inspect(container);val entry=DaPackageInspector.select(report,id.hwCode,id.hwSubCode,id.hwVersion)
        val extracted=DaPackageInspector.extractDa1(container,entry,stagingFile)
        val validation=validateDownloadAgent(extracted.first,expectedSha256)
        require(validation.matchesTrustedDigest) { "Selected MediaTek DA1 does not match trusted digest" }
        RandomAccessFile(extracted.first,"r").use { raf ->
            brom.sendDownloadAgent(raf,extracted.second.loadAddress,extracted.second.signatureLength,onProgress=onProgress)
            brom.jumpToDownloadAgent(extracted.second.loadAddress)
        }
        return DaStartResult(id.hwCode,id.hwSubCode,id.hwVersion,extracted.first,extracted.second.loadAddress)
    }

    fun uploadAndStartDa(input:java.io.InputStream,output:java.io.OutputStream,agent:File,loadAddress:Long,signatureLength:Long=0,
                         onProgress:(Long,Long)->Unit={_,_->}) {
        require(agent.isFile) { "Download Agent file missing" }
        RandomAccessFile(agent,"r").use { raf ->
            val brom=BromSession(input,output);brom.handshake();brom.sendDownloadAgent(raf,loadAddress,signatureLength,onProgress=onProgress);brom.jumpToDownloadAgent(loadAddress)
        }
    }
}
