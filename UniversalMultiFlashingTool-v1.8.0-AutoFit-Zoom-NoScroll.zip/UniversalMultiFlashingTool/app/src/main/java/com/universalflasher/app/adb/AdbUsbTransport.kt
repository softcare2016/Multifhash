package com.universalflasher.app.adb

import android.content.Context
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** ADB USB interface transport and CNXN handshake probe. AUTH signing/shell services are intentionally separate. */
class AdbUsbTransport(context: Context, private val device: UsbDevice) : AutoCloseable {
    private val manager = context.getSystemService(Context.USB_SERVICE) as UsbManager
    private var connection: UsbDeviceConnection? = null
    private var claimed: UsbInterface? = null
    private var input: UsbEndpoint? = null
    private var output: UsbEndpoint? = null

    fun open(): Boolean {
        if (!manager.hasPermission(device)) return false
        for (i in 0 until device.interfaceCount) {
            val intf = device.getInterface(i)
            if (intf.interfaceClass != 0xff || intf.interfaceSubclass != 0x42 || intf.interfaceProtocol != 0x01) continue
            val ins = (0 until intf.endpointCount).map { intf.getEndpoint(it) }.firstOrNull { it.type == UsbConstants.USB_ENDPOINT_XFER_BULK && it.direction == UsbConstants.USB_DIR_IN }
            val outs = (0 until intf.endpointCount).map { intf.getEndpoint(it) }.firstOrNull { it.type == UsbConstants.USB_ENDPOINT_XFER_BULK && it.direction == UsbConstants.USB_DIR_OUT }
            if (ins != null && outs != null) {
                val c = manager.openDevice(device) ?: return false
                if (!c.claimInterface(intf, true)) { c.close(); return false }
                connection = c; claimed = intf; input = ins; output = outs
                return true
            }
        }
        return false
    }

    fun send(packet: AdbPacket, timeoutMs: Int = 3000) {
        val c = connection ?: error("ADB USB transport is not open")
        val endpoint = output ?: error("ADB bulk OUT endpoint unavailable")
        val bytes = packet.encode()
        check(c.bulkTransfer(endpoint, bytes, bytes.size, timeoutMs) == bytes.size) { "ADB packet write failed" }
    }

    fun receive(timeoutMs: Int = 3000, maxPayload: Int = 1 shl 20): AdbPacket {
        val c = connection ?: error("ADB USB transport is not open")
        val endpoint = input ?: error("ADB bulk IN endpoint unavailable")
        val header = ByteArray(24)
        readExact(c, endpoint, header, timeoutMs)
        val length = ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN).getInt(12)
        require(length in 0..maxPayload) { "ADB payload exceeds safety limit" }
        val payload = ByteArray(length)
        if (length > 0) readExact(c, endpoint, payload, timeoutMs)
        return AdbPacket.decode(header, payload, maxPayload)
    }

    /** Input stream adapter for the full ADB CNXN/AUTH/shell_v2 host session. */
    fun inputStream(timeoutMs: Int = 5000): java.io.InputStream {
        return object : java.io.InputStream() {
            override fun read(): Int {
                val one = ByteArray(1)
                val n = read(one, 0, 1)
                return if (n < 0) -1 else one[0].toInt() and 0xff
            }
            override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
                require(offset >= 0 && length >= 0 && offset + length <= buffer.size)
                if (length == 0) return 0
                val c = connection ?: throw IllegalStateException("ADB USB transport is closed")
                val ep = input ?: throw IllegalStateException("ADB bulk IN endpoint unavailable")
                val temp = ByteArray(length)
                val n = c.bulkTransfer(ep, temp, length, timeoutMs)
                if (n < 0) return -1
                if (n > 0) System.arraycopy(temp, 0, buffer, offset, n)
                return n
            }
        }
    }

    /** Output stream adapter; large ADB packets are split into USB-safe chunks. */
    fun outputStream(timeoutMs: Int = 5000): java.io.OutputStream {
        return object : java.io.OutputStream() {
            override fun write(value: Int) { write(byteArrayOf(value.toByte()), 0, 1) }
            override fun write(buffer: ByteArray, offset: Int, length: Int) {
                require(offset >= 0 && length >= 0 && offset + length <= buffer.size)
                val c = connection ?: throw IllegalStateException("ADB USB transport is closed")
                val ep = output ?: throw IllegalStateException("ADB bulk OUT endpoint unavailable")
                var pos = 0
                while (pos < length) {
                    val count = minOf(16 * 1024, length - pos)
                    val chunk = buffer.copyOfRange(offset + pos, offset + pos + count)
                    val sent = c.bulkTransfer(ep, chunk, chunk.size, timeoutMs)
                    check(sent == count) { "ADB USB packet write failed" }
                    pos += sent
                }
            }
        }
    }

    /** Sends the standard host CNXN packet and returns the first device packet (usually CNXN or AUTH). */
    fun probeHandshake(timeoutMs: Int = 3000): AdbPacket {
        send(AdbPacket("CNXN", 0x01000000, 1024 * 1024, "host::features=shell_v2,cmd,stat_v2,ls_v2\u0000".toByteArray(Charsets.UTF_8)), timeoutMs)
        return receive(timeoutMs)
    }

    private fun readExact(c: UsbDeviceConnection, endpoint: UsbEndpoint, target: ByteArray, timeoutMs: Int) {
        var offset = 0
        while (offset < target.size) {
            val chunk = ByteArray(target.size - offset)
            val n = c.bulkTransfer(endpoint, chunk, chunk.size, timeoutMs)
            check(n > 0) { "ADB USB read timed out or disconnected" }
            System.arraycopy(chunk, 0, target, offset, n)
            offset += n
        }
    }

    override fun close() {
        val c = connection ?: return
        try { claimed?.let { c.releaseInterface(it) } } finally { c.close(); connection = null; claimed = null; input = null; output = null }
    }
}
