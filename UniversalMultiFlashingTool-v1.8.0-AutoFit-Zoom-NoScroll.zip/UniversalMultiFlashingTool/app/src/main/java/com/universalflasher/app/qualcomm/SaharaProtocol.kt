package com.universalflasher.app.qualcomm

import java.io.InputStream
import java.io.OutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Qualcomm Sahara wire protocol primitives. No security bypass or programmer acquisition is performed. */
object SaharaProtocol {
    const val CMD_HELLO = 0x01
    const val CMD_HELLO_RESP = 0x02
    const val CMD_READ_DATA = 0x03
    const val CMD_END_IMAGE_TX = 0x04
    const val CMD_DONE = 0x05
    const val CMD_DONE_RESP = 0x06
    const val CMD_RESET = 0x07
    const val CMD_RESET_RESP = 0x08
    const val CMD_MEMORY_DEBUG = 0x09
    const val CMD_MEMORY_READ = 0x0A
    const val CMD_CMD_READY = 0x0B
    const val CMD_SWITCH_MODE = 0x0C
    const val CMD_EXECUTE = 0x0D
    const val CMD_EXECUTE_RESP = 0x0E
    const val CMD_EXECUTE_DATA = 0x0F
    const val CMD_READ_DATA64 = 0x12
    const val MODE_IMAGE_TX_PENDING = 0
    const val MODE_IMAGE_TX_COMPLETE = 1
    const val MODE_MEMORY_DEBUG = 2
    const val MODE_COMMAND = 3
    const val HEADER_SIZE = 8
    const val MAX_PACKET_SIZE = 1024 * 1024

    data class Packet(val command: Int, val payload: ByteArray) {
        fun encode(): ByteArray {
            require(command in 0..0xffff)
            val length = HEADER_SIZE + payload.size
            require(length <= MAX_PACKET_SIZE)
            return ByteBuffer.allocate(length).order(ByteOrder.LITTLE_ENDIAN)
                .putInt(command).putInt(length).put(payload).array()
        }
    }

    data class Hello(
        val version: Int, val versionSupported: Int, val maxCommandPacketLength: Long,
        val mode: Long, val reserved: Long, val endian: Long
    )

    fun decode(bytes: ByteArray): Packet {
        require(bytes.size >= HEADER_SIZE) { "Sahara packet header truncated" }
        val b = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        val command = b.int
        val length = b.int
        require(length >= HEADER_SIZE && length <= MAX_PACKET_SIZE && length == bytes.size) { "Invalid Sahara packet length" }
        return Packet(command, bytes.copyOfRange(HEADER_SIZE, length))
    }

    fun parseHello(packet: Packet): Hello {
        require(packet.command == CMD_HELLO) { "Expected Sahara HELLO" }
        require(packet.payload.size >= 40) { "Sahara HELLO payload truncated (expected 0x30-byte wire packet)" }
        val b = ByteBuffer.wrap(packet.payload).order(ByteOrder.LITTLE_ENDIAN)
        val version = b.int; val compatible = b.int; val maxLen = b.int.toLong() and 0xffffffffL
        val mode = b.int.toLong() and 0xffffffffL
        val reserved = b.int.toLong() and 0xffffffffL
        val endian = b.int.toLong() and 0xffffffffL
        return Hello(version, compatible, maxLen, mode, reserved, endian)
    }

    fun helloResponse(version: Int, versionSupported: Int, status: Int = 0, mode: Int = 0): ByteArray {
        val payload = ByteBuffer.allocate(40).order(ByteOrder.LITTLE_ENDIAN)
            .putInt(version).putInt(versionSupported).putInt(status).putInt(mode)
            .putInt(0).putInt(0).putInt(0).putInt(0).putInt(0).putInt(0).array()
        return Packet(CMD_HELLO_RESP, payload).encode()
    }

    fun readDataResponse(imageId: Int, offset: Long, length: Long): ByteArray {
        require(offset in 0..0xffffffffL && length in 1..0xffffffffL)
        val payload = ByteBuffer.allocate(12).order(ByteOrder.LITTLE_ENDIAN)
            .putInt(imageId).putInt(offset.toInt()).putInt(length.toInt()).array()
        return Packet(CMD_READ_DATA, payload).encode()
    }

    fun readData64Response(imageId: Long, offset: Long, length: Long): ByteArray {
        require(imageId >= 0 && offset >= 0 && length > 0)
        val payload = ByteBuffer.allocate(24).order(ByteOrder.LITTLE_ENDIAN)
            .putLong(imageId).putLong(offset).putLong(length).array()
        return Packet(CMD_READ_DATA64, payload).encode()
    }

    fun readExact(input: InputStream, size: Int): ByteArray {
        require(size in 0..MAX_PACKET_SIZE)
        val out = ByteArray(size)
        var p = 0
        while (p < size) { val n = input.read(out, p, size - p); if (n < 0) throw IllegalStateException("Sahara transport closed"); if (n > 0) p += n }
        return out
    }

    fun readPacket(input: InputStream): Packet {
        val header = readExact(input, HEADER_SIZE)
        val b = ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN)
        b.int
        val length = b.int
        require(length in HEADER_SIZE..MAX_PACKET_SIZE) { "Invalid Sahara packet size" }
        return decode(header + readExact(input, length - HEADER_SIZE))
    }

    fun writePacket(output: OutputStream, packet: Packet) { output.write(packet.encode()); output.flush() }
}
