package com.universalflasher.app.partition

import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.zip.CRC32

data class GptPartition(
    val name: String, val firstLba: Long, val lastLba: Long, val typeGuid: String,
    val uniqueGuid: String = "", val attributes: Long = 0
) { val sectorCount: Long get() = lastLba - firstLba + 1 }

data class GptReport(
    val revision: Long, val currentLba: Long, val backupLba: Long, val firstUsableLba: Long,
    val lastUsableLba: Long, val diskGuid: String, val sectorSize: Int,
    val partitions: List<GptPartition>, val headerCrcValid: Boolean, val entriesCrcValid: Boolean
)

/** Strict primary-GPT reader with header and entry-array CRC validation. Input begins at LBA0. */
object GptReader {
    fun readReport(input: InputStream, sectorSize: Int = 512, maxEntries: Int = 4096): GptReport {
        require(sectorSize in setOf(512, 1024, 2048, 4096))
        val mbr = readFully(input, sectorSize)
        require(mbr.size == sectorSize) { "Missing protective MBR / LBA0" }
        val h = readFully(input, sectorSize)
        require(h.size == sectorSize) { "Missing GPT header at LBA1" }
        require(String(h, 0, 8, Charsets.US_ASCII) == "EFI PART") { "GPT signature not found" }
        val b = ByteBuffer.wrap(h).order(ByteOrder.LITTLE_ENDIAN)
        val revision = b.getInt(8).toLong() and 0xffffffffL
        val headerSize = b.getInt(12)
        require(headerSize in 92..sectorSize) { "Invalid GPT header size" }
        val storedHeaderCrc = b.getInt(16).toLong() and 0xffffffffL
        val headerForCrc = h.copyOfRange(0, headerSize).also { ByteBuffer.wrap(it).order(ByteOrder.LITTLE_ENDIAN).putInt(16, 0) }
        val headerCrc = crc32(headerForCrc)
        require(storedHeaderCrc == headerCrc) { "GPT header CRC mismatch" }
        val currentLba = b.getLong(24); val backupLba = b.getLong(32)
        val firstUsable = b.getLong(40); val lastUsable = b.getLong(48)
        require(currentLba == 1L && backupLba > currentLba && firstUsable >= 2L && firstUsable <= lastUsable && lastUsable < backupLba) { "Invalid GPT LBA geometry" }
        val diskGuid = guid(h.copyOfRange(56, 72))
        val entryLba = b.getLong(72); val count = b.getInt(80); val entrySize = b.getInt(84)
        val storedEntriesCrc = b.getInt(88).toLong() and 0xffffffffL
        require(entryLba >= 2 && count in 1..maxEntries && entrySize in 128..4096 && entrySize % 8 == 0) { "Invalid GPT entry geometry" }
        val entryBytesLong = count.toLong() * entrySize
        require(entryBytesLong <= 16L * 1024 * 1024) { "GPT entry array exceeds safety limit" }
        val entrySectors = (entryBytesLong + sectorSize - 1L) / sectorSize
        require(entryLba + entrySectors <= firstUsable) { "GPT entry array overlaps usable partition area" }
        skipFully(input, (entryLba - 2L) * sectorSize)
        val entryBytes = readFully(input, entryBytesLong.toInt())
        require(entryBytes.size == entryBytesLong.toInt()) { "Truncated GPT entry array" }
        val entriesCrc = crc32(entryBytes)
        require(entriesCrc == storedEntriesCrc) { "GPT partition-entry CRC mismatch" }
        val partitions = mutableListOf<GptPartition>()
        repeat(count) { index ->
            val e = entryBytes.copyOfRange(index * entrySize, (index + 1) * entrySize)
            if (e.copyOfRange(0, 16).all { it == 0.toByte() }) return@repeat
            val x = ByteBuffer.wrap(e).order(ByteOrder.LITTLE_ENDIAN)
            val type = guid(e.copyOfRange(0, 16)); val unique = guid(e.copyOfRange(16, 32))
            val first = x.getLong(32); val last = x.getLong(40); val attrs = x.getLong(48)
            require(first >= firstUsable && last <= lastUsable && last >= first) { "Partition outside usable GPT range" }
            val nameBytes = e.copyOfRange(56, minOf(entrySize, 128))
            val name = String(nameBytes, Charsets.UTF_16LE).trimEnd('\u0000')
            require(name.isNotBlank()) { "GPT partition name is empty" }
            partitions += GptPartition(name, first, last, type, unique, attrs)
        }
        val ordered = partitions.sortedBy { it.firstLba }
        ordered.zipWithNext().forEach { (a, b) ->
            require(a.lastLba < b.firstLba) { "Overlapping GPT partitions: ${a.name} / ${b.name}" }
        }
        return GptReport(revision, currentLba, backupLba, firstUsable, lastUsable, diskGuid, sectorSize,
            partitions, true, true)
    }

    fun read(input: InputStream, sectorSize: Int = 512, maxEntries: Int = 4096): List<GptPartition> =
        readReport(input, sectorSize, maxEntries).partitions

    private fun guid(raw: ByteArray): String {
        val b = ByteBuffer.wrap(raw).order(ByteOrder.LITTLE_ENDIAN)
        val a = b.int.toLong() and 0xffffffffL; val c = b.short.toInt() and 0xffff; val d = b.short.toInt() and 0xffff
        val tail = raw.copyOfRange(8, 16).joinToString("") { "%02x".format(it.toInt() and 0xff) }
        return "%08x-%04x-%04x-%s-%s".format(a, c, d, tail.substring(0, 4), tail.substring(4))
    }
    private fun crc32(bytes: ByteArray): Long = CRC32().apply { update(bytes) }.value
    private fun readFully(i: InputStream, size: Int): ByteArray { val out = ByteArray(size); var p = 0; while (p < size) { val n = i.read(out, p, size-p); if (n < 0) break; if (n > 0) p += n }; return if (p == size) out else out.copyOf(p) }
    private fun skipFully(i: InputStream, count: Long) { var left = count; val buf = ByteArray(8192); while (left > 0) { val n = i.read(buf, 0, minOf(buf.size.toLong(), left).toInt()); require(n > 0) { "Image too short for GPT entries" }; left -= n } }
}
