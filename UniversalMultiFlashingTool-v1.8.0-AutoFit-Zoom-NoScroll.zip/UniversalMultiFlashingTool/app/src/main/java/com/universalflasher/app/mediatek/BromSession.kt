package com.universalflasher.app.mediatek

import java.io.InputStream
import java.io.OutputStream
import java.io.RandomAccessFile

/** MediaTek BROM session: inverted-echo sync, chip identification, SEND_DA and JUMP_DA. */
class BromSession(private val input: InputStream, private val output: OutputStream) {
    data class Identification(val hwCode: Int, val hwSubCode: Int, val hwVersion: Int, val swVersion: Int, val config: BromProtocol.TargetConfig)

    fun handshake() {
        for (v in intArrayOf(0xA0, 0x0A, 0x50, 0x05)) {
            output.write(v); output.flush()
            val response = BromProtocol.readByte(input)
            check(response == (v xor 0xff)) { "MediaTek BROM sync mismatch (sent 0x${v.toString(16)}, got 0x${response.toString(16)})" }
        }
    }

    fun identify(): Identification { handshake(); return identifyAfterHandshake() }

    fun identifyAfterHandshake(): Identification {
        val hw = queryWords(BromProtocol.CMD_GET_HW_CODE, 2)
        val versions = queryWords(BromProtocol.CMD_GET_HW_SW_VERSION, 4)
        val cfg = queryConfig()
        if (cfg.slaRequired || cfg.daaRequired) throw SecurityException("Target requires OEM-authorized SLA/DAA; authentication bypass is not supported")
        return Identification(hw[0], hw[1], versions[0], versions[1], cfg)
    }

    private fun echoByte(value: Int) { output.write(value); output.flush(); val got=BromProtocol.readByte(input); check(got==value){"BROM command echo mismatch"} }
    private fun echoBlock(bytes: ByteArray) { output.write(bytes); output.flush(); val got=BromProtocol.readExact(input,bytes.size); check(got.contentEquals(bytes)){"BROM command parameter echo mismatch"} }
    private fun queryWords(command: Int, words: Int): List<Int> {
        echoByte(command); val bytes=BromProtocol.readExact(input,words*2)
        return (0 until words).map { i -> ((bytes[i*2].toInt() and 255) shl 8) or (bytes[i*2+1].toInt() and 255) }
    }
    private fun queryConfig(): BromProtocol.TargetConfig {
        echoByte(BromProtocol.CMD_GET_TARGET_CONFIG)
        return BromProtocol.parseTargetConfig(BromProtocol.readExact(input,4))
    }

    /** Sends a DA1 image to the caller-supplied, model-specific SRAM address; secure targets can reject it. */
    fun sendDownloadAgent(agent: RandomAccessFile, loadAddress: Long, signatureLength: Long = 0, chunkSize: Int = 8192,
                          onProgress: (Long,Long)->Unit = {_,_->}) {
        val size=agent.length(); BromProtocol.validateDaImage(size)
        require(loadAddress in 0..0xffffffffL && signatureLength in 0..size && chunkSize in 512..0x10000)
        echoByte(BromProtocol.CMD_SEND_DA)
        echoBlock(BromProtocol.be32(loadAddress)); echoBlock(BromProtocol.be32(size)); echoBlock(BromProtocol.be32(signatureLength))
        val preStatus=BromProtocol.readExact(input,2)
        val status=((preStatus[0].toInt() and 255) shl 8) or (preStatus[1].toInt() and 255)
        if(status!=0) throw SecurityException("MediaTek SEND_DA rejected: status 0x${status.toString(16)}")
        agent.seek(0); var sent=0L
        while(sent<size){val n=minOf(chunkSize.toLong(),size-sent).toInt();val block=ByteArray(n);agent.readFully(block);output.write(block);output.flush();sent+=n;onProgress(sent,size)}
        val tail=BromProtocol.readExact(input,4)
        val receivedChecksum=((tail[0].toInt() and 255) shl 8) or (tail[1].toInt() and 255)
        val receivedStatus=((tail[2].toInt() and 255) shl 8) or (tail[3].toInt() and 255)
        val expected=BromProtocol.checksumXorLeWords(readAgentBytes(agent,size)).let { it and 0xffff }
        check(receivedChecksum==expected){"MediaTek DA transfer checksum mismatch"}
        if(receivedStatus!=0) throw SecurityException("MediaTek DA transfer rejected: status 0x${receivedStatus.toString(16)}")
    }

    fun jumpToDownloadAgent(loadAddress: Long) {
        echoByte(BromProtocol.CMD_JUMP_DA); echoBlock(BromProtocol.be32(loadAddress))
        val status=BromProtocol.readExact(input,2); val code=((status[0].toInt() and 255) shl 8) or (status[1].toInt() and 255)
        check(code==0) { "MediaTek JUMP_DA rejected: status 0x${code.toString(16)}" }
    }

    private fun readAgentBytes(file: RandomAccessFile,size:Long):ByteArray { require(size<=BromProtocol.MAX_DA_SIZE);val old=file.filePointer;val b=ByteArray(size.toInt());file.seek(0);file.readFully(b);file.seek(old);return b }
}
