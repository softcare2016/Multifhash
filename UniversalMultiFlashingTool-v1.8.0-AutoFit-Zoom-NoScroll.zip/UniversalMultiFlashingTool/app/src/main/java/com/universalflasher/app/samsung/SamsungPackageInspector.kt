package com.universalflasher.app.samsung

import java.io.InputStream
import java.io.File
import java.security.MessageDigest
import java.io.RandomAccessFile

/** Read-only TAR inventory for Samsung-style firmware archives; no Odin transfer implementation. */
data class TarEntryInfo(val name: String, val size: Long)
object SamsungPackageInspector {
    data class Md5Verification(val expected: String, val actual: String, val valid: Boolean, val tarBytes: Long)

    /** Verifies the 32-hex digest appended by common Samsung .tar.md5 packages. */
    fun verifyTarMd5(file: File): Md5Verification {
        require(file.isFile && file.length() > 32L) { "Samsung TAR.MD5 file is missing or too small" }
        RandomAccessFile(file, "r").use { raf ->
            val tailLength = minOf(128L, file.length()).toInt()
            val tail = ByteArray(tailLength)
            raf.seek(file.length() - tailLength)
            raf.readFully(tail)
            val text = String(tail, Charsets.US_ASCII)
            val match = Regex("([0-9a-fA-F]{32})\\s*$").find(text)
                ?: throw IllegalArgumentException("Samsung TAR.MD5 suffix not found")
            val expected = match.groupValues[1].lowercase()
            val suffixStart = file.length() - tailLength + match.range.first
            require(suffixStart > 0L) { "Invalid Samsung TAR.MD5 boundary" }
            val digest = MessageDigest.getInstance("MD5")
            raf.seek(0)
            val buffer = ByteArray(64 * 1024)
            var remaining = suffixStart
            while (remaining > 0) {
                val n = raf.read(buffer, 0, minOf(buffer.size.toLong(), remaining).toInt())
                require(n > 0) { "Truncated Samsung TAR.MD5 payload" }
                digest.update(buffer, 0, n)
                remaining -= n
            }
            val actual = digest.digest().joinToString("") { "%02x".format(it) }
            return Md5Verification(expected, actual, expected == actual, suffixStart)
        }
    }

    fun inspectTar(input: InputStream, maxEntries: Int = 10000): List<TarEntryInfo> {
        val result = mutableListOf<TarEntryInfo>()
        val header = ByteArray(512)
        var entries = 0
        while (true) {
            val n = readFully(input, header)
            if (n == 0 || header.all { it == 0.toByte() }) break
            require(n == 512) { "Truncated TAR header" }
            val stored = parseOctal(header, 148, 8)
            var sum = 0L
            for (i in header.indices) sum += if (i in 148..155) 32 else (header[i].toInt() and 0xff)
            require(stored == sum) { "TAR header checksum mismatch" }
            val name = String(header, 0, 100, Charsets.US_ASCII).trimEnd('\u0000')
            val prefix = String(header, 345, 155, Charsets.US_ASCII).trimEnd('\u0000')
            val fullName = if (prefix.isBlank()) name else "$prefix/$name"
            val size = parseOctal(header, 124, 12)
            require(size >= 0) { "Invalid TAR entry size" }
            result += TarEntryInfo(fullName, size)
            val skip = ((size + 511) / 512) * 512
            skipFully(input, skip)
            entries++
            require(entries <= maxEntries) { "TAR entry limit exceeded" }
        }
        return result
    }
    private fun parseOctal(b: ByteArray, off: Int, len: Int): Long {
        val s = String(b, off, len, Charsets.US_ASCII).trim('\u0000', ' ')
        return if (s.isBlank()) 0 else s.toLongOrNull(8) ?: error("Invalid TAR octal field")
    }
    private fun readFully(i: InputStream, b: ByteArray): Int { var p=0; while(p<b.size) { val n=i.read(b,p,b.size-p); if(n<0) break; p+=n }; return p }
    private fun skipFully(i: InputStream, count: Long) { var left=count; val buf=ByteArray(8192); while(left>0) { val n=i.read(buf,0,minOf(buf.size.toLong(),left).toInt()); require(n>0) { "Truncated TAR payload" }; left-=n } }
}
