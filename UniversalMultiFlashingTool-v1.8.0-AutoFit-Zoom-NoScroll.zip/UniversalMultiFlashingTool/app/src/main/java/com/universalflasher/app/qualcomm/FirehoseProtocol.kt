package com.universalflasher.app.qualcomm

import java.io.ByteArrayInputStream
import java.io.InputStream
import java.nio.charset.StandardCharsets
import javax.xml.parsers.DocumentBuilderFactory
import org.xml.sax.SAXParseException
import org.xml.sax.helpers.DefaultHandler

/** Firehose XML command construction and hardened response parsing. */
object FirehoseProtocol {
    data class Configure(val MemoryName: String = "emmc", val Verbose: Int = 0, val AlwaysValidate: Int = 1,
                         val MaxPayloadSizeToTargetInBytes: Int = 1048576)
    data class Response(val value: String, val rawXml: String)

    fun configureXml(c: Configure = Configure()): ByteArray {
        require(c.MemoryName in setOf("emmc", "ufs", "nand"))
        require(c.MaxPayloadSizeToTargetInBytes in 4096..16*1024*1024)
        return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><data><configure MemoryName=\"${c.MemoryName}\" Verbose=\"${c.Verbose}\" AlwaysValidate=\"${c.AlwaysValidate}\" MaxPayloadSizeToTargetInBytes=\"${c.MaxPayloadSizeToTargetInBytes}\" ZlpAwareHost=\"1\" /></data>".toByteArray(StandardCharsets.UTF_8)
    }
    fun readXml(startSector: Long, sectorCount: Long, physicalPartition: Int = 0, fileName: String = "readback.bin", sectorSize: Int = 512): ByteArray {
        require(startSector >= 0 && sectorCount > 0 && physicalPartition >= 0 && sectorSize in setOf(512,4096))
        require(fileName.matches(Regex("[A-Za-z0-9_.-]{1,128}")))
        return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><data><read SECTOR_SIZE_IN_BYTES=\"$sectorSize\" filename=\"$fileName\" num_partition_sectors=\"$sectorCount\" physical_partition_number=\"$physicalPartition\" start_sector=\"$startSector\" /></data>".toByteArray(StandardCharsets.UTF_8)
    }
    fun eraseXml(startSector:Long,sectorCount:Long,physicalPartition:Int=0,sectorSize:Int=512):ByteArray {
        require(startSector>=0 && sectorCount>0 && physicalPartition>=0 && sectorSize in setOf(512,4096))
        return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><data><erase SECTOR_SIZE_IN_BYTES=\"$sectorSize\" num_partition_sectors=\"$sectorCount\" physical_partition_number=\"$physicalPartition\" start_sector=\"$startSector\" /></data>".toByteArray(StandardCharsets.UTF_8)
    }
    fun programXml(fileName: String, startSector: Long, sectorCount: Long, physicalPartition: Int = 0, sectorSize: Int = 512, fileSectorOffset: Long = 0): ByteArray {
        require(fileName.matches(Regex("[A-Za-z0-9_.-]{1,128}"))) { "Unsafe programmer file name" }
        require(startSector >= 0 && sectorCount > 0 && physicalPartition >= 0 && sectorSize in setOf(512,4096) && fileSectorOffset >= 0)
        return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><data><program SECTOR_SIZE_IN_BYTES=\"$sectorSize\" filename=\"$fileName\" file_sector_offset=\"$fileSectorOffset\" num_partition_sectors=\"$sectorCount\" physical_partition_number=\"$physicalPartition\" start_sector=\"$startSector\" /></data>".toByteArray(StandardCharsets.UTF_8)
    }
    fun parseResponse(xml: String): Response {
        require(xml.toByteArray().size <= 1024*1024) { "Firehose response too large" }
        val factory=DocumentBuilderFactory.newInstance().apply {
            setFeature("http://apache.org/xml/features/disallow-doctype-decl",true)
            setFeature("http://xml.org/sax/features/external-general-entities",false)
            setFeature("http://xml.org/sax/features/external-parameter-entities",false)
            isXIncludeAware=false;isExpandEntityReferences=false
        }
        val builder=factory.newDocumentBuilder().apply {
            setErrorHandler(object: DefaultHandler() {
                override fun warning(e:SAXParseException) { throw e }
                override fun error(e:SAXParseException) { throw e }
                override fun fatalError(e:SAXParseException) { throw e }
            })
        }
        val doc=builder.parse(ByteArrayInputStream(xml.toByteArray(StandardCharsets.UTF_8)))
        require(doc.documentElement.tagName=="data") { "Unexpected Firehose response root" }
        val nodes=doc.documentElement.childNodes
        var value="unknown"
        for(i in 0 until nodes.length){val n=nodes.item(i);if(n.nodeType==org.w3c.dom.Node.ELEMENT_NODE && n.nodeName!="log"){value=n.attributes?.getNamedItem("value")?.nodeValue ?: "unknown";break}}
        return Response(value,xml)
    }
}
