package com.universalflasher.app.usb

import android.content.Context
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager

/** Minimal Fastboot USB bulk transport foundation. It intentionally exposes no flash/erase API. */
class FastbootUsbTransport(context: Context, private val device: UsbDevice) : AutoCloseable {
    private val manager = context.getSystemService(Context.USB_SERVICE) as UsbManager
    private var connection: UsbDeviceConnection? = null
    private var usbInterface: UsbInterface? = null
    private var input: UsbEndpoint? = null
    private var output: UsbEndpoint? = null

    fun open(): Boolean {
        if (!manager.hasPermission(device)) return false
        for (i in 0 until device.interfaceCount) {
            val intf = device.getInterface(i)
            if (intf.interfaceClass != 0xff || intf.interfaceSubclass != 0x42 || intf.interfaceProtocol != 0x03) continue
            val ins = (0 until intf.endpointCount).map { intf.getEndpoint(it) }.firstOrNull { it.type == UsbConstants.USB_ENDPOINT_XFER_BULK && it.direction == UsbConstants.USB_DIR_IN }
            val outs = (0 until intf.endpointCount).map { intf.getEndpoint(it) }.firstOrNull { it.type == UsbConstants.USB_ENDPOINT_XFER_BULK && it.direction == UsbConstants.USB_DIR_OUT }
            if (ins != null && outs != null) {
                val conn = manager.openDevice(device) ?: return false
                if (!conn.claimInterface(intf, true)) { conn.close(); return false }
                connection = conn; usbInterface = intf; input = ins; output = outs
                return true
            }
        }
        return false
    }

    @Synchronized fun getVar(name: String, timeoutMs: Int = 3000): String = exchange("getvar:$name", timeoutMs)
    @Synchronized fun rebootBootloader(timeoutMs: Int = 3000): String = exchange("reboot-bootloader", timeoutMs)

    private fun exchange(command: String, timeoutMs: Int): String {
        val conn = connection ?: error("Fastboot transport is not open")
        val out = output ?: error("Fastboot OUT endpoint unavailable")
        val inp = input ?: error("Fastboot IN endpoint unavailable")
        val bytes = command.toByteArray(Charsets.US_ASCII)
        check(conn.bulkTransfer(out, bytes, bytes.size, timeoutMs) == bytes.size) { "Fastboot command write failed" }
        val buffer = ByteArray(4096)
        val response = StringBuilder()
        var reads = 0
        while (reads++ < 32) {
            val n = conn.bulkTransfer(inp, buffer, buffer.size, timeoutMs)
            if (n <= 0) break
            val packet = String(buffer, 0, n, Charsets.US_ASCII)
            response.append(packet)
            if (packet.startsWith("OKAY") || packet.startsWith("FAIL")) return response.toString()
        }
        return response.toString().ifBlank { "No response (timeout)" }
    }

    override fun close() {
        val conn = connection ?: return
        try { usbInterface?.let { conn.releaseInterface(it) } } finally { conn.close(); connection = null; usbInterface = null; input = null; output = null }
    }
}
