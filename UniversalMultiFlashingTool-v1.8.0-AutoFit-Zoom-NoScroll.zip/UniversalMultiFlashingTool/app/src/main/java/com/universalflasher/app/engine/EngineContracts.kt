package com.universalflasher.app.engine

enum class EngineState { AVAILABLE, DEVICE_REQUIRED, PARTIAL, NOT_IMPLEMENTED, UNSUPPORTED }
data class EngineCapability(val id: String, val title: String, val state: EngineState, val detail: String)
object EngineRegistry {
    val capabilities = listOf(
        EngineCapability("adb", "Android Debug Bridge", EngineState.PARTIAL, "ADB RSA-2048 AUTH token signing/public-key response and shell_v2 command stream are implemented; app-private persistent RSA identity support is implemented; USB device validation remains."),
        EngineCapability("fastboot", "Fastboot", EngineState.PARTIAL, "USB bulk transport supports diagnostic getvar/reboot commands; hardware compatibility remains unverified."),
        EngineCapability("qualcomm", "Qualcomm Sahara / Firehose", EngineState.PARTIAL, "Sahara packet codec, HELLO/read-data programmer transfer state machine, programmer SHA-256 validation, Firehose XML command/session layer, raw partition reads and guarded partition operations are implemented. Exact programmer and real target validation required."),
        EngineCapability("mediatek", "MediaTek BROM / Download Agent", EngineState.PARTIAL, "BROM inverted-echo sync, hardware/config query, SEND_DA checksum/status and JUMP_DA, DA container matching/extraction, XFlash V5 command/ACK/chunk flow, XML V6 partition command builders, DA digest validation and scatter parser are implemented. Full device-specific DA storage data-flow and target validation remain."),
        EngineCapability("samsung", "Samsung Download Mode", EngineState.PARTIAL, "TAR inventory, Odin-Thor handshake, 1024-byte packet codec, response parsing, PIT parser and session initialization are implemented. Full XMIT firmware transfer and hardware validation remain."),
        EngineCapability("gpt", "GPT Partition Reader", EngineState.PARTIAL, "Primary GPT reader validates header and partition-entry CRC32, geometry, GUIDs, bounds and names for raw disk images. Qualcomm Firehose live partition-table read and file-backed partition backup/restore are implemented in source; backup-GPT recovery and real target validation remain."),
        EngineCapability("jobs", "Flash Job Manager", EngineState.PARTIAL, "Thread-safe lifecycle state machine with progress, pause, cancel and safe checkpoints; no hardware worker is connected yet.")
    )
}
