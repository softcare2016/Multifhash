package com.universalflasher.app.qualcomm

import java.io.InputStream
import java.io.OutputStream
import java.io.RandomAccessFile

/** Host-side Sahara programmer upload state machine for an authorized, model-matched programmer image. */
class SaharaProgrammerTransfer(
    private val input: InputStream,
    private val output: OutputStream,
    private val programmer: RandomAccessFile,
    private val maxChunk: Int = 1024 * 1024
) {
    enum class State { WAIT_HELLO, TRANSFERRING, WAIT_DONE, COMPLETE, FAILED }
    var state: State = State.WAIT_HELLO; private set
    var bytesSent: Long = 0; private set
    val totalBytes: Long = programmer.length()

    init { require(totalBytes in 1..512L*1024*1024); require(maxChunk in 4096..1024*1024) }

    fun run(onProgress: (Long, Long) -> Unit = { _, _ -> }) {
        check(state == State.WAIT_HELLO)
        try {
            val helloPacket = SaharaProtocol.readPacket(input)
            val hello = SaharaProtocol.parseHello(helloPacket)
            require(hello.maxCommandPacketLength >= 4096) { "Target advertised invalid Sahara packet size" }
            val targetChunkLimit=minOf(maxChunk.toLong(),hello.maxCommandPacketLength).toInt()
            SaharaProtocol.writePacket(output, SaharaProtocol.Packet(SaharaProtocol.CMD_HELLO_RESP,
                java.nio.ByteBuffer.allocate(40).order(java.nio.ByteOrder.LITTLE_ENDIAN)
                    .putInt(2).putInt(1).putInt(0).putInt(hello.mode.toInt())
                    .putInt(0).putInt(0).putInt(0).putInt(0).putInt(0).putInt(0).array()))
            state = State.TRANSFERRING
            while (true) {
                when (val packet = SaharaProtocol.readPacket(input)) {
                    else -> when (packet.command) {
                        SaharaProtocol.CMD_READ_DATA -> {
                            require(packet.payload.size >= 12) { "Malformed Sahara READ_DATA" }
                            val b = java.nio.ByteBuffer.wrap(packet.payload).order(java.nio.ByteOrder.LITTLE_ENDIAN)
                            val imageId = b.int
                            val offset = b.int.toLong() and 0xffffffffL
                            val length = b.int.toLong() and 0xffffffffL
                            require(imageId == 0) { "Unexpected Sahara image id $imageId for single programmer transfer" }
                            require(offset + length <= totalBytes && length in 1..targetChunkLimit.toLong()) { "Sahara requested data outside programmer image" }
                            val data = ByteArray(length.toInt()); programmer.seek(offset); programmer.readFully(data)
                            output.write(data); output.flush(); bytesSent += length; onProgress(bytesSent, totalBytes)
                        }
                        SaharaProtocol.CMD_READ_DATA64 -> {
                            require(packet.payload.size >= 24) { "Malformed Sahara READ_DATA64" }
                            val b = java.nio.ByteBuffer.wrap(packet.payload).order(java.nio.ByteOrder.LITTLE_ENDIAN)
                            val imageId = b.long; val offset = b.long; val length = b.long
                            require(imageId == 0L) { "Unexpected Sahara image id $imageId for single programmer transfer" }
                            require(offset >= 0 && length in 1..targetChunkLimit.toLong() && length <= totalBytes && offset <= totalBytes - length) { "Sahara READ_DATA64 outside programmer image" }
                            val data=ByteArray(length.toInt());programmer.seek(offset);programmer.readFully(data)
                            output.write(data);output.flush();bytesSent+=length;onProgress(bytesSent,totalBytes)
                        }
                        SaharaProtocol.CMD_END_IMAGE_TX -> {
                            require(packet.payload.size >= 8) { "Malformed Sahara END_OF_IMAGE" }
                            val end = java.nio.ByteBuffer.wrap(packet.payload).order(java.nio.ByteOrder.LITTLE_ENDIAN)
                            val imageId = end.int; val status = end.int
                            require(imageId == 0 && status == 0) { "Sahara image transfer rejected: image=$imageId status=$status" }
                            state = State.WAIT_DONE
                            SaharaProtocol.writePacket(output, SaharaProtocol.Packet(SaharaProtocol.CMD_DONE, byteArrayOf()))
                        }
                        SaharaProtocol.CMD_DONE_RESP -> {
                            require(packet.payload.size >= 4) { "Malformed Sahara DONE_RESPONSE" }
                            val status = java.nio.ByteBuffer.wrap(packet.payload).order(java.nio.ByteOrder.LITTLE_ENDIAN).int
                            require(status == 1) { "Sahara target reports additional images pending (status=$status); multi-image transfer is not enabled" }
                            state = State.COMPLETE; return
                        }
                        SaharaProtocol.CMD_RESET -> error("Target requested Sahara reset")
                        else -> error("Unexpected Sahara command 0x${packet.command.toString(16)}")
                    }
                }
            }
        } catch (t: Throwable) { state = State.FAILED; throw t }
    }
}
