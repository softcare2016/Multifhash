package com.universalflasher.app.qualcomm

import java.io.InputStream
import javax.xml.parsers.DocumentBuilderFactory
import org.xml.sax.SAXParseException
import org.xml.sax.helpers.DefaultHandler

data class QcomProgramEntry(
    val label: String, val fileName: String, val startSector: Long?, val sectorCount: Long?,
    val physicalPartition: Int?, val sectorSize: Int?, val sparse: Boolean, val isPatch: Boolean
)
object QualcommPackageInspector {
    fun parseRawProgram(input: InputStream): List<QcomProgramEntry> {
        val factory=DocumentBuilderFactory.newInstance().apply {
            setFeature("http://apache.org/xml/features/disallow-doctype-decl",true)
            setFeature("http://xml.org/sax/features/external-general-entities",false)
            setFeature("http://xml.org/sax/features/external-parameter-entities",false)
            isXIncludeAware=false;isExpandEntityReferences=false
        }
        val builder=factory.newDocumentBuilder().apply {
            setErrorHandler(object: DefaultHandler() {
                override fun warning(e:SAXParseException) { throw e }
                override fun error(e:SAXParseException) { throw e }
                override fun fatalError(e:SAXParseException) { throw e }
            })
        }
        val doc=builder.parse(input)
        val nodes=doc.getElementsByTagName("program");val patches=doc.getElementsByTagName("patch")
        val out=mutableListOf<QcomProgramEntry>()
        fun append(node:org.w3c.dom.Node,patch:Boolean){
            val e=node as org.w3c.dom.Element
            fun a(n:String)=e.getAttribute(n)
            val start=a("start_sector").toLongOrNull();val count=a("num_partition_sectors").toLongOrNull()
            val physical=a("physical_partition_number").toIntOrNull();val sector=a("SECTOR_SIZE_IN_BYTES").toIntOrNull();val file=a("filename")
            require(start==null||start>=0);require(count==null||count>=0);require(physical==null||physical>=0)
            require(sector==null||sector in setOf(512,4096))
            require(file.isBlank()||(!file.contains("..")&&!file.contains('/')&&!file.contains('\\'))) { "Unsafe firmware filename" }
            out+=QcomProgramEntry(a("label").ifBlank{file},file,start,count,physical,sector,a("sparse").equals("true",true),patch)
        }
        for(i in 0 until nodes.length) append(nodes.item(i),false)
        for(i in 0 until patches.length) append(patches.item(i),true)
        require(out.isNotEmpty()){ "No Qualcomm program/patch entries found" }
        return out
    }
}
