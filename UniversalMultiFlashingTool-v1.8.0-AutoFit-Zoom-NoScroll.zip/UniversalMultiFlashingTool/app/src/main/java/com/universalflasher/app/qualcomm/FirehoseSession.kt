package com.universalflasher.app.qualcomm

import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.nio.charset.StandardCharsets

/** Firehose XML + raw data session over an already-open authorized programmer transport. */
class FirehoseSession(private val input: InputStream, private val output: OutputStream, private val maxResponseBytes: Int = 1024 * 1024) {
    data class Result(val xml: String, val value: String, val raw: FirehoseProtocol.Response)
    @Volatile var maxPayloadBytes: Int = 1024 * 1024
        private set

    @Synchronized fun configure(config: FirehoseProtocol.Configure = FirehoseProtocol.Configure()): Result {
        maxPayloadBytes = config.MaxPayloadSizeToTargetInBytes
        return exchange(FirehoseProtocol.configureXml(config))
    }
    @Synchronized fun erase(startSector:Long,sectorCount:Long,physicalPartition:Int=0,sectorSize:Int=512,confirmed:Boolean):Result {
        require(confirmed) { "Explicit partition erase confirmation is required" }
        val result=exchange(FirehoseProtocol.eraseXml(startSector,sectorCount,physicalPartition,sectorSize))
        require(result.value.equals("ACK",true)) { "Firehose did not ACK erase" }
        return result
    }

    /** Sends a model-validated image with sector padding and checks both setup and final ACKs. */
    @Synchronized fun programFile(file: File, startSector: Long, physicalPartition: Int = 0, sectorSize: Int = 512,
                                  onProgress: (Long,Long)->Unit = {_,_->}): Result {
        require(file.isFile && file.length() > 0 && startSector >= 0 && physicalPartition >= 0 && sectorSize in setOf(512,4096))
        val sectors = (file.length() + sectorSize - 1) / sectorSize
        val paddedBytes = sectors * sectorSize
        val setup = exchange(FirehoseProtocol.programXml(file.name, startSector, sectors, physicalPartition, sectorSize))
        require(setup.value.equals("ACK", true)) { "Firehose did not ACK program setup" }
        file.inputStream().buffered().use { source ->
            val alignedChunk=((maxPayloadBytes.coerceIn(sectorSize,16*1024*1024)/sectorSize)*sectorSize).coerceAtLeast(sectorSize)
            val buf=ByteArray(alignedChunk);var sent=0L
            while(sent<paddedBytes){
                val target=minOf(buf.size.toLong(),paddedBytes-sent).toInt();var got=0
                while(got<target){val n=source.read(buf,got,target-got);if(n<0)break;got+=n}
                if(got<target) java.util.Arrays.fill(buf,got,target,0.toByte())
                output.write(buf,0,target);output.flush();sent+=target;onProgress(minOf(sent,file.length()),file.length())
            }
        }
        return readResponseResult()
    }

    /** Reads a raw partition range to the supplied output stream; caller chooses a safe destination. */
    @Synchronized fun readPartitionTo(startSector: Long, sectorCount: Long, destination: OutputStream,
                                      physicalPartition: Int = 0, sectorSize: Int = 512,
                                      onProgress: (Long,Long)->Unit = {_,_->}): Result {
        require(startSector >= 0 && sectorCount > 0 && physicalPartition >= 0 && sectorSize in setOf(512,4096))
        val total= Math.multiplyExact(sectorCount,sectorSize.toLong())
        val setup=exchange(FirehoseProtocol.readXml(startSector,sectorCount,physicalPartition,"readback.bin",sectorSize))
        require(setup.value.equals("ACK",true)){"Firehose did not ACK read setup"}
        val buffer=ByteArray(minOf(maxPayloadBytes.coerceAtLeast(sectorSize),1024*1024));var copied=0L
        while(copied<total){val need=minOf(buffer.size.toLong(),total-copied).toInt();var p=0;while(p<need){val n=input.read(buffer,p,need-p);if(n<0)throw IllegalStateException("Firehose read ended early at $copied/$total bytes");if(n>0)p+=n};destination.write(buffer,0,need);copied+=need;onProgress(copied,total)}
        destination.flush();return readResponseResult()
    }

    private fun exchange(xml: ByteArray): Result { output.write(xml);output.flush();return readResponseResult() }
    private fun readResponseResult(): Result { val response=readUntilClosingData();val parsed=FirehoseProtocol.parseResponse(response);if(!parsed.value.equals("ACK",true))throw IllegalStateException("Firehose target did not ACK command (${parsed.value}): $response");return Result(response,parsed.value,parsed) }
    private fun readUntilClosingData(): String {
        val marker="</data>".toByteArray(StandardCharsets.US_ASCII);val bytes=java.io.ByteArrayOutputStream();var matched=0
        while(bytes.size()<maxResponseBytes){val b=input.read();if(b<0)throw IllegalStateException("Firehose transport closed before response completed");bytes.write(b);if(b==(marker[matched].toInt() and 0xff)){matched++;if(matched==marker.size)return bytes.toString("UTF-8")}else matched=if(b==(marker[0].toInt() and 0xff))1 else 0}
        throw IllegalStateException("Firehose response exceeded configured limit")
    }
}
