package com.universalflasher.app.mediatek

import java.io.InputStream
import java.io.OutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.charset.StandardCharsets

/** MediaTek XML DA/V6 framing and safe command builders. */
object XmlDaProtocol {
    const val MAGIC = 0xFEEEEEEFu
    const val TYPE_PROTOCOL_FLOW = 1
    const val MAX_XML_BYTES = 4 * 1024 * 1024
    data class Message(val type: Int, val xml: String)

    fun encode(xml: String, type: Int = TYPE_PROTOCOL_FLOW): ByteArray {
        val data=xml.toByteArray(StandardCharsets.UTF_8)
        require(data.isNotEmpty() && data.size<=MAX_XML_BYTES && type==TYPE_PROTOCOL_FLOW)
        return ByteBuffer.allocate(12+data.size).order(ByteOrder.LITTLE_ENDIAN)
            .putInt(MAGIC.toInt()).putInt(type).putInt(data.size).put(data).array()
    }
    fun decode(frame: ByteArray): Message {
        require(frame.size>=12)
        val b=ByteBuffer.wrap(frame).order(ByteOrder.LITTLE_ENDIAN)
        require(b.int.toUInt()==MAGIC)
        val type=b.int;val len=b.int
        require(type==TYPE_PROTOCOL_FLOW && len in 1..MAX_XML_BYTES && len==frame.size-12)
        return Message(type,String(frame,12,len,StandardCharsets.UTF_8))
    }
    fun read(input:InputStream):Message {
        val h=ByteArray(12);readFully(input,h);val b=ByteBuffer.wrap(h).order(ByteOrder.LITTLE_ENDIAN)
        require(b.int.toUInt()==MAGIC);val type=b.int;val len=b.int
        require(type==TYPE_PROTOCOL_FLOW && len in 1..MAX_XML_BYTES)
        val payload=ByteArray(len);readFully(input,payload);return Message(type,String(payload,StandardCharsets.UTF_8))
    }
    fun readPartitionXml(partition:String,targetFile:String):String {
        requireSafe(partition);requireSafe(targetFile)
        return "<?xml version=\"1.0\" encoding=\"utf-8\"?><da><version>1.0</version><command>CMD:READ-PARTITION</command><arg><partition>$partition</partition><target_file>$targetFile</target_file></arg></da>"
    }
    fun writePartitionXml(partition:String,sourceFile:String):String {
        requireSafe(partition);requireSafe(sourceFile)
        return "<?xml version=\"1.0\" encoding=\"utf-8\"?><da><version>1.0</version><command>CMD:WRITE-PARTITION</command><arg><partition>$partition</partition><source_file>$sourceFile</source_file></arg></da>"
    }
    fun erasePartitionXml(partition:String,confirmed:Boolean):String {
        require(confirmed) { "Explicit erase confirmation is required" };requireSafe(partition)
        return "<?xml version=\"1.0\" encoding=\"utf-8\"?><da><version>1.0</version><command>CMD:ERASE-PARTITION</command><arg><partition>$partition</partition></arg></da>"
    }
    fun readFlashXml(address:Long,length:Long,targetFile:String):String {
        require(address>=0 && length>0);requireSafe(targetFile)
        return "<?xml version=\"1.0\" encoding=\"utf-8\"?><da><version>1.0</version><command>CMD:READ-FLASH</command><arg><address>0x${address.toString(16)}</address><length>$length</length><target_file>$targetFile</target_file></arg></da>"
    }
    fun writeFlashXml(address:Long,length:Long,sourceFile:String,confirmed:Boolean):String {
        require(confirmed) { "Explicit flash confirmation is required" };require(address>=0 && length>0);requireSafe(sourceFile)
        return "<?xml version=\"1.0\" encoding=\"utf-8\"?><da><version>1.0</version><command>CMD:WRITE-FLASH</command><arg><address>0x${address.toString(16)}</address><length>$length</length><source_file>$sourceFile</source_file></arg></da>"
    }
    private fun requireSafe(s:String){require(s.matches(Regex("[A-Za-z0-9_.-]{1,128}")) && !s.contains("..")){"Unsafe DA path or partition name"}}
    private fun readFully(i:InputStream,b:ByteArray){var p=0;while(p<b.size){val n=i.read(b,p,b.size-p);if(n<0)throw IllegalStateException("MediaTek XML DA transport closed");if(n>0)p+=n}}
}

class XmlDaSession(private val input:InputStream,private val output:OutputStream){
    fun awaitStart():String { val m=XmlDaProtocol.read(input);check(m.xml.contains("CMD:START")){"MediaTek DA not ready for command"};return m.xml }
    fun sendReadPartition(partition:String,targetFile:String){send(XmlDaProtocol.readPartitionXml(partition,targetFile))}
    fun sendWritePartition(partition:String,sourceFile:String){send(XmlDaProtocol.writePartitionXml(partition,sourceFile))}
    fun sendErasePartition(partition:String,confirmed:Boolean){send(XmlDaProtocol.erasePartitionXml(partition,confirmed))}
    fun sendReadFlash(address:Long,length:Long,targetFile:String){send(XmlDaProtocol.readFlashXml(address,length,targetFile))}
    fun sendWriteFlash(address:Long,length:Long,sourceFile:String,confirmed:Boolean){send(XmlDaProtocol.writeFlashXml(address,length,sourceFile,confirmed))}
    fun send(xml:String){output.write(XmlDaProtocol.encode(xml));output.flush()}
    /** XML DA command acceptance is a raw NUL-terminated OK/ERR token, followed by CMD:END XML. */
    fun readAck():String {
        val bytes=java.io.ByteArrayOutputStream();var terminated=false
        while(bytes.size()<4096){val b=input.read();if(b<0)throw IllegalStateException("MediaTek XML DA transport closed before ACK");if(b==0){terminated=true;break};bytes.write(b)}
        require(terminated) { "MediaTek XML DA ACK terminator missing" }
        val ack=bytes.toString("US-ASCII")
        check(ack=="OK" || ack=="OK!") { "MediaTek XML DA rejected command: $ack" }
        return ack
    }
    fun readResponse():String {
        readAck()
        val response=XmlDaProtocol.read(input).xml
        check(response.contains("CMD:END")) { "MediaTek XML DA did not return CMD:END" }
        return response
    }
}
