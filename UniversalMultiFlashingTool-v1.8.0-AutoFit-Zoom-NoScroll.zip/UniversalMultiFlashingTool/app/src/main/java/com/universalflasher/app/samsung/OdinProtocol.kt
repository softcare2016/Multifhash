package com.universalflasher.app.samsung

import java.io.InputStream
import java.io.OutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Samsung Download Mode / Odin-Thor protocol framing and PIT parser. */
object OdinProtocol {
    const val PACKET_SIZE=1024
    const val REGION_INIT=0x64L
    const val REGION_PIT=0x65L
    const val REGION_XMIT=0x66L
    const val REGION_CLOSE=0x67L
    const val PIT_MAGIC=0x12349876
    data class Response(val id:Long,val ack:Long)
    data class Request(val region:Long,val parameter:Long,val arguments:LongArray=longArrayOf())
    data class PitPartition(val binaryType:Long,val deviceType:Long,val partitionId:Long,val attributes:Long,val updateAttributes:Long,val blockSize:Long,val blockCount:Long,val fileOffset:Long,val fileSize:Long,val partitionName:String,val fileName:String,val deltaName:String)

    fun encode(request:Request):ByteArray {
        require(request.region in 0..0xffffffffL && request.parameter in 0..0xffffffffL && request.arguments.size<=126)
        val b=ByteBuffer.allocate(PACKET_SIZE).order(ByteOrder.LITTLE_ENDIAN)
        b.putInt(request.region.toInt());b.putInt(request.parameter.toInt());request.arguments.forEach { require(it in 0..0xffffffffL);b.putInt(it.toInt()) }
        return b.array()
    }
    fun decodeResponse(bytes:ByteArray):Response {
        require(bytes.size==8);val b=ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        return Response(b.int.toLong() and 0xffffffffL,b.int.toLong() and 0xffffffffL)
    }
    fun readResponse(input:InputStream):Response { val b=ByteArray(8);readFully(input,b);return decodeResponse(b) }
    fun handshake(input:InputStream,output:OutputStream,timeoutNote:String="") {
        output.write("ODIN".toByteArray(Charsets.US_ASCII));output.flush()
        val response=ByteArray(4);readFully(input,response)
        check(String(response,Charsets.US_ASCII)=="LOKE") { "Samsung Download Mode handshake failed $timeoutNote" }
    }
    fun send(input:InputStream,output:OutputStream,request:Request,expectedId:Long?=null):Response {
        output.write(encode(request));output.flush();val response=readResponse(input)
        check(response.id!=0xffffffffL) { "Samsung bootloader failure code ${response.ack}" }
        if(expectedId!=null)check(response.id==expectedId){"Samsung response ID mismatch"}
        return response
    }
    fun parsePit(bytes:ByteArray,maxEntries:Int=4096):List<PitPartition> {
        require(bytes.size>=32)
        val b=ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        require(b.int==PIT_MAGIC){"Samsung PIT magic mismatch"}
        val count=b.int;require(count in 1..maxEntries)
        b.position(28)
        val expected=28L+count.toLong()*132L;require(expected<=bytes.size){"Truncated Samsung PIT"}
        val out=mutableListOf<PitPartition>()
        repeat(count){
            val binary=b.int.toLong() and 0xffffffffL;val device=b.int.toLong() and 0xffffffffL;val id=b.int.toLong() and 0xffffffffL
            val attr=b.int.toLong() and 0xffffffffL;val update=b.int.toLong() and 0xffffffffL;val block=b.int.toLong() and 0xffffffffL
            val blocks=b.int.toLong() and 0xffffffffL;val offset=b.int.toLong() and 0xffffffffL;val size=b.int.toLong() and 0xffffffffL
            fun str(n:Int)=ByteArray(n).also{b.get(it)}.toString(Charsets.US_ASCII).trimEnd('\u0000')
            val partition=str(32);val file=str(32);val delta=str(32)
            require(block>0 && blocks>0 && partition.isNotBlank()) { "Invalid Samsung PIT entry" }
            out+=PitPartition(binary,device,id,attr,update,block,blocks,offset,size,partition,file,delta)
        }
        return out
    }
    private fun readFully(i:InputStream,b:ByteArray){var p=0;while(p<b.size){val n=i.read(b,p,b.size-p);if(n<0)throw IllegalStateException("Samsung Download Mode transport closed");if(n>0)p+=n}}
}

/** Stateful safe subset: negotiate the Odin session and advertise a known firmware byte count. */
class OdinSession(private val input:InputStream,private val output:OutputStream){
    var protocolVersion:Int=-1;private set
    fun begin():Int {
        OdinProtocol.handshake(input,output)
        val r=OdinProtocol.send(input,output,OdinProtocol.Request(OdinProtocol.REGION_INIT,0))
        protocolVersion=(r.ack ushr 16).toInt()
        require(protocolVersion>=0) { "Invalid Samsung Odin protocol version" }
        return protocolVersion
    }
    fun setTotalBytes(total:Long){require(total>0);OdinProtocol.send(input,output,OdinProtocol.Request(OdinProtocol.REGION_INIT,2,longArrayOf(total and 0xffffffffL,(total ushr 32) and 0xffffffffL)))}
}
