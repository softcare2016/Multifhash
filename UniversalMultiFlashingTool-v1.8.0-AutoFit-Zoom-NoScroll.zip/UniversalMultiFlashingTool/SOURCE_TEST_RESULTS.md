# v1.6.0 source and simulation test results

## Executed in this workspace
Command: `./tools/simulation/run.sh`

Result: **20 passed, 0 failed**.

Scenarios include:
1. ADB packet checksum corruption rejection.
2. ADB malformed payload length rejection.
3. Qualcomm Sahara malformed packet length rejection.
4. MediaTek BROM NACK security stop.
5. MediaTek scatter partition overlap rejection.
6. MediaTek XML DA path traversal rejection.
7. Qualcomm Firehose NAK rejection.
8. Firehose final-sector zero padding and final ACK.
9. Firehose truncated raw partition read rejection.
10. GPT invalid signature rejection.
11. GPT header CRC corruption rejection.
12. GPT overlapping partition rejection.
13. Samsung TAR.MD5 valid appended digest accepted.
14. Samsung TAR.MD5 tampering detected.
15. Partition restore model mismatch blocked before transport.
16. Partition restore digest mismatch blocked before transport.
17. Flash job cancellation at safe checkpoint.
18. Qualcomm XML DOCTYPE/external entity rejected.
19. Qualcomm path traversal rejected.
20. Samsung truncated PIT rejected.

## JUnit coverage added
`app/src/test/java/com/universalflasher/app/SimulationRegressionTest.kt` contains corresponding JUnit tests. GitHub Actions runs `testDebugUnitTest` before `assembleDebug`.

## Not executed here
- Android Gradle build/APK assembly.
- Android emulator/instrumentation tests.
- USB OTG and any physical Qualcomm, MediaTek, Samsung, ADB or Fastboot session.
- Physical partition backup/restore/flash.

The offline tests validate source behavior against deterministic synthetic streams/files only. They do not prove real hardware interoperability.


## v1.7.0 re-run
- `tools/simulation/run.sh`: PASS — 20 passed, 0 failed after the UI/ADB transport source update.
- MainActivity and AdbUsbTransport Kotlin parser check: no syntax/parse errors observed. A standalone `kotlinc` check cannot resolve Android/Compose APIs because the Android SDK and Gradle dependency classpath are not installed in this environment; this is not an Android compile result.
- Resource audit: all drawable identifiers referenced by MainActivity resolve to bundled drawable resources.
- ZIP integrity: verified separately after packaging.
- Android Gradle build, APK install, rendering and physical USB device tests: not run in this environment.
