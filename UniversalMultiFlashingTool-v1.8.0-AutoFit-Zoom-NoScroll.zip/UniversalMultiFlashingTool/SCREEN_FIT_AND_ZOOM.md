# Screen Fit, Fixed Layout and Zoom — v1.8.0

## Goals
- Preserve the v1.7 reference-dashboard arrangement and its existing controls.
- Fit the workspace to the available landscape viewport automatically.
- Avoid page-level vertical and horizontal scrolling.
- Keep the workspace layout measurements unchanged when zooming.

## Implementation
- The app remains landscape and immersive.
- A fit scale is calculated from the available screen width and height against the 760 × 410 dp workspace reference.
- Fit scale is applied through the Compose density so the complete default workspace is reduced to fit the phone display.
- Zoom is a separate graphics-layer transform (0.70× to 1.60×); it does not alter layout measurements or reflow controls.
- When zoomed above 1×, drag the workspace to pan to clipped areas. Reset returns zoom and pan to their default values.
- Home flash log shows the latest six entries without a page scroll container.
- Brand catalogue is laid out as a fixed compact grid instead of a LazyColumn.
- ADB output uses a fixed non-scrolling column.
- Existing action callbacks, firmware picker, USB diagnostics and protocol classes are preserved.

## Interaction notes
- At 1×, all content is fitted to the viewport.
- At greater than 1×, only the portion inside the phone screen is visible; drag to move the enlarged workspace. This is intentional magnification, not page scrolling.
- Use the header minus/plus/reset controls to adjust magnification.
- The Settings compact option changes typography density slightly; it does not change the reference panel order.

## Verification boundary
- Source inspection confirms there are no LazyColumn, verticalScroll or horizontalScroll page containers remaining in `MainActivity.kt`.
- ZIP integrity can be verified locally.
- Android compilation, rendering on the user's phone, touch-target feel and physical screen fit still require a GitHub Actions build and device installation. This source update does not claim those tests have passed.
