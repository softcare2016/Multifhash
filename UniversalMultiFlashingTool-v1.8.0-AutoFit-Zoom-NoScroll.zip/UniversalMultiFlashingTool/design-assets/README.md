# Design reference assets
- `reference-dashboard.png` is the user's supplied UI reference and is retained unchanged for implementation comparison.
- `3D-icon-sheet-preview.jpg` is a preview of the 16 custom 3D-style icons bundled individually in `app/src/main/res/drawable-nodpi/`.
