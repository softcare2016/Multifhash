#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
UI="$ROOT/app/src/main/java/com/universalflasher/app/MainActivity.kt"
if grep -nE 'LazyColumn|verticalScroll|horizontalScroll' "$UI"; then
  echo 'FAIL | page scrolling container found in MainActivity.kt'
  exit 1
fi
grep -q 'val fitScale = minOf(config.screenWidthDp / 760f, config.screenHeightDp / 410f)' "$UI"
grep -q 'scaleX = zoom' "$UI"
grep -q 'detectDragGestures' "$UI"
grep -q 'coerceIn(.7f, 1.6f)' "$UI"
echo 'PASS | automatic screen fit, visual zoom, drag-pan and no page-level scroll containers'
