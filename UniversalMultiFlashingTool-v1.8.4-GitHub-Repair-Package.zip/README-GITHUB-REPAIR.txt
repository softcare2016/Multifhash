UNIVERSAL MULTI FLASHING TOOL - GITHUB REPAIR PACKAGE

This package contains:
1) .github/workflows/android-build.yml
2) UniversalMultiFlashingTool-v1.8.4-ADB-Quick-Actions.zip

CRITICAL:
GitHub Actions only runs workflow files committed in the repository at
.github/workflows/*.yml. A workflow file stored inside an uploaded ZIP is NOT
activated automatically.

To apply this repair:
- In the GitHub repository, open .github/workflows/android-build.yml.
- Replace its COMPLETE contents with the android-build.yml included here.
- Commit the change.
- Upload UniversalMultiFlashingTool-v1.8.4-ADB-Quick-Actions.zip to the repository root
  (or keep the existing project ZIP; the workflow recursively searches nested ZIPs).
- Run Actions > Universal Multi Flashing Tool - Android Build > Run workflow.

Do not upload this whole repair package as a single ZIP and expect the workflow
inside it to replace the active repository workflow. It will not.
