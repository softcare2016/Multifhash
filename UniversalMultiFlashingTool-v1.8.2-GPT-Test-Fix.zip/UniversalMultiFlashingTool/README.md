# Universal Multi Flashing Tool — v1.8.0

Android landscape firmware-service workspace based on the supplied blue/white dashboard reference, with bundled 3D phone, chipset, cable, progress and status illustrations.


## v1.8.0 reference UI implementation
- Rebuilt the landscape shell around the user's 1536×1024 blue/neon reference: fixed left navigation, title/version/readiness header, five large toolbar tiles, device badge, central firmware form, right-side device information with phone visual, three large flash controls, terminal log, progress/timer panel and bottom status strip.
- Added a consistent dark navy/cyan beveled panel and illuminated button system across Home and all eight secondary pages.
- Added a fresh 16-piece transparent 3D icon asset set for logo, folders, gear, refresh, broom, home, phone, Android, lightning, fingerprint, tools, info, chipset and USB.
- Home inputs now include brand/model selection, normal/force mode, four quick partition selectors, firmware picker and read-only package inspection summary.
- Rebuilt All Brands, ADB, Fastboot, Recovery, IMEI, Utilities, Settings and About as dedicated page workspaces instead of placeholder paragraphs. Brand selection returns to Home with the selected brand.
- Added an ADB USB stream adapter for host CNXN/AUTH and shell_v2 command execution; ADB shell requires user approval of the Android RSA prompt. Fastboot getvar selection is wired to a live USB diagnostic session.
- Added responsive landscape scaling and title-bar zoom controls.

## v1.6.0 offline/simulation updates
- Hardened GPT geometry checks: GPT entry-array extent must end before the usable partition range.
- Added GPT partition-name validation and overlap rejection after CRC verification.
- Added Samsung `.tar.md5` appended-digest verification (MD5 integrity check only; it is not a publisher signature).
- Added 20 deterministic hardware-free regression scenarios covering positive and negative protocol paths, corrupted packets, NAKs, truncation, unsafe paths, GPT CRC/overlap, Samsung TAR.MD5, restore guards and job cancellation.
- Added `tools/simulation/run.sh` so the protocol/core simulation suite can be compiled and run with the Kotlin command-line compiler without Android Studio or a connected phone.
- Added corresponding JUnit regression tests to `app/src/test`; GitHub Actions already runs `testDebugUnitTest` before APK assembly.

## Included source modules
- Compose dashboard, zoom controls and graphical device/status assets.
- Android USB host enumeration and permission helpers.
- Streaming firmware SHA-256 inspection and image/package metadata foundations.
- Qualcomm rawprogram/patch XML parser with bounds and path validation.
- Qualcomm Sahara 48-byte HELLO negotiation, 32/64-bit image requests and bounded programmer upload state machine.
- Qualcomm Firehose XML command builders, strict ACK parsing, program streaming, raw partition reads and guarded partition backup/restore/erase service.
- Qualcomm programmer SHA-256 validation against an externally trusted digest.
- MediaTek scatter parser, overlap checks and DA package/SoC/DA1 region inspection.
- MediaTek BROM inverted-echo handshake, hardware/config identification, SEND_DA, checksum/status handling and JUMP_DA.
- MediaTek XFlash V5 command/parameter ACK flow and chunk streaming; XML DA V6 framing, session helpers and partition read/write/erase command builders.
- Samsung TAR inventory, appended TAR.MD5 integrity verification, Odin-Thor handshake/packet codec and PIT parser.
- ADB RSA AUTH signing/public-key encoding, app-private identity persistence, CNXN negotiation and shell_v2 command service.
- Fastboot diagnostic USB transport, GPT primary header/entry CRC validation and flash-job lifecycle state machine.

## Important capability boundary
This is a source and offline-simulation update, not a claim of universal 100% hardware compatibility. Exact OEM programmers and Download Agents must match the detected model/chipset and be trusted. Qualcomm Firehose, MediaTek DA, Samsung Odin, ADB and Fastboot still need physical-device validation. Samsung full XMIT firmware transfer, persistent ADB key storage on Android Keystore, MediaTek complete storage-operation flows, backup GPT recovery and cross-engine worker orchestration remain device/protocol follow-up engineering items.

The `.tar.md5` check verifies the appended MD5 digest for file integrity only; MD5 is not a secure publisher signature or trust proof.

No FRP/account bypass, SLA/DAA bypass, bootloader security bypass or IMEI alteration is provided. Unsupported or security-locked targets must fail safely.

## Build with GitHub Actions
The repository contains `settings.gradle.kts`, root `build.gradle.kts`, `app/build.gradle.kts`, `gradle/libs.versions.toml`, `gradle.properties` and `.github/workflows/android-build.yml`. Upload the project folder or ZIP to the repository root and run **Actions → Universal Multi Flasher Android Build**. CI provisions JDK 17, Android SDK 35 and Gradle 8.9, runs unit tests and assembles the debug APK.

A Gradle wrapper JAR is not bundled in this archive; CI uses the Gradle distribution installed by the workflow. Do not run destructive operations without exact-model firmware validation and explicit confirmation.

See `IMPLEMENTATION_STATUS.md` for the precise source-level and hardware-validation boundary.


## v1.8.0 screen-fit update

The original landscape dashboard is kept as the fixed visual workspace. It auto-fits to the available display, zooms independently from layout measurement, and supports drag-panning while magnified. Page-level scrolling containers were removed from the Home log, Brands catalogue and ADB output. See `SCREEN_FIT_AND_ZOOM.md`. Android build and on-device rendering still require external validation.

## v1.8.1 illustrated device-mode guidance
The Device Information panel now opens an Illustrated Mode Guide for Fastboot/Bootloader, Recovery, Samsung Download Mode and Qualcomm EDL. USB manufacturer/product descriptors are displayed when available, but they are not treated as proof of an exact phone model. The guide intentionally refuses to guess model-specific key combinations or EDL test-point locations. The current handset illustration is generic; exact online model-photo retrieval and verified per-model annotated OEM diagrams are not yet implemented. See `IMPLEMENTATION_STATUS.md` for the capability boundary.
