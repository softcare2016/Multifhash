package com.universalflasher.app

import android.content.Context
import android.content.BroadcastReceiver
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.universalflasher.app.adb.AdbUsbTransport
import com.universalflasher.app.adb.AdbHostSession
import com.universalflasher.app.adb.AdbRsaIdentity
import com.universalflasher.app.adb.AdbShellService
import com.universalflasher.app.firmware.FirmwareInspector
import com.universalflasher.app.usb.FastbootUsbTransport
import com.universalflasher.app.usb.UsbPermissionHelper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Navy = Color(0xFF031329)
private val Navy2 = Color(0xFF061B38)
private val Panel = Color(0xFF08244A)
private val Panel2 = Color(0xFF0B3265)
private val Blue = Color(0xFF087DEB)
private val Cyan = Color(0xFF27C9FF)
private val TextMain = Color(0xFFF4F8FF)
private val Muted = Color(0xFFB5CBE5)
private val Green = Color(0xFF38E653)
private val Amber = Color(0xFFFFB72E)
private val Red = Color(0xFFFF4148)
private val Line = Color(0xFF168DD8)

private val navItems = listOf("Home", "All Brands", "ADB Tools", "Fastboot Tools", "Recovery Tools", "IMEI Tools", "Utilities", "Settings", "About")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        applyImmersiveWorkspace()
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { FlasherApp(this) } }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) applyImmersiveWorkspace()
    }

    @Suppress("DEPRECATION")
    private fun applyImmersiveWorkspace() {
        window.decorView.systemUiVisibility = (
            android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                android.view.View.SYSTEM_UI_FLAG_FULLSCREEN or
                android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            )
    }
}

@Composable
private fun FlasherApp(context: Context) {
    val baseDensity = LocalDensity.current
    val config = LocalConfiguration.current
    var zoom by remember { mutableFloatStateOf(1f) }
    var panX by remember { mutableFloatStateOf(0f) }
    var panY by remember { mutableFloatStateOf(0f) }
    var settingsCompact by remember { mutableStateOf(true) }
    // Fit the complete fixed-layout workspace to the available landscape viewport.
    // Zoom is applied as a visual transform afterwards, so it never changes layout measurements.
    val fitScale = minOf(config.screenWidthDp / 760f, config.screenHeightDp / 410f).coerceIn(.25f, 1f)
    CompositionLocalProvider(LocalDensity provides Density(baseDensity.density * fitScale, baseDensity.fontScale * (if (settingsCompact) .86f else .92f))) {
        var page by remember { mutableStateOf("Home") }
        var brand by remember { mutableStateOf("Auto Detect") }
        var model by remember { mutableStateOf("Select model") }
        var firmwareName by remember { mutableStateOf("No firmware selected") }
        var firmwareUri by remember { mutableStateOf<Uri?>(null) }
        var firmwareReport by remember { mutableStateOf<FirmwareInspector.Report?>(null) }
        var deviceStatus by remember { mutableStateOf("Not connected") }
        var deviceName by remember { mutableStateOf("Waiting for USB device") }
        var androidVersion by remember { mutableStateOf("—") }
        var battery by remember { mutableStateOf("—") }
        var flashMode by remember { mutableStateOf("Normal Flash") }
        var partitions by remember { mutableStateOf(setOf("Boot", "Recovery", "System", "Vendor")) }
        var progress by remember { mutableFloatStateOf(0f) }
        var running by remember { mutableStateOf(false) }
        var elapsed by remember { mutableStateOf("00:00:00") }
        var eta by remember { mutableStateOf("--:--:--") }
        var logs by remember { mutableStateOf(listOf("[SYSTEM] Universal Multi Flashing Tool initialized.", "[USB] Waiting for a supported device.", "[READY] Select a firmware package to begin validation.")) }
        var adbCommand by remember { mutableStateOf("getprop ro.product.model") }
        var fastbootVariable by remember { mutableStateOf("product") }
        var utilityHash by remember { mutableStateOf("") }
        var selectedRecoveryAction by remember { mutableStateOf("Reboot to Recovery") }
        var settingsAnimations by remember { mutableStateOf(true) }
        var settingsConfirm by remember { mutableStateOf(true) }
        var settingsLanguage by remember { mutableStateOf("English") }
        var selectedBrandFilter by remember { mutableStateOf("") }

        fun log(message: String) {
            val stamp = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
            logs = (listOf("[$stamp] $message") + logs).take(500)
        }

        val firmwarePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) {
                firmwareUri = uri
                firmwareName = uri.lastPathSegment?.substringAfterLast('/') ?: "Selected firmware"
                runCatching {
                    val report = FirmwareInspector.inspect(context.contentResolver, uri, firmwareName)
                    firmwareReport = report
                    utilityHash = report.sha256
                    log("Firmware inspected: ${report.detectedType}; ${report.sizeBytes} bytes; SHA-256 ${report.sha256}")
                    report.warnings.forEach { log("Firmware warning: $it") }
                }.onFailure {
                    firmwareReport = null
                    log("Firmware inspection failed: ${it.message}")
                }
            }
        }
        val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
            if (uri != null) {
                runCatching { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                log("Folder access granted: $uri")
            }
        }

        DisposableEffect(context) {
            val usbReceiver = object : BroadcastReceiver() {
                override fun onReceive(ctx: Context?, intent: Intent?) {
                    when (intent?.action) {
                        UsbManager.ACTION_USB_DEVICE_ATTACHED -> {
                            deviceStatus = "USB detected"
                            deviceName = "USB attached · checking protocol"
                            log("USB device attached. Run Refresh or the matching protocol diagnostics.")
                        }
                        UsbManager.ACTION_USB_DEVICE_DETACHED -> {
                            deviceStatus = "Not connected"
                            deviceName = "Waiting for USB device"
                            log("USB device detached. Active operations must stop safely.")
                        }
                    }
                }
            }
            val filter = IntentFilter().apply {
                addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
                addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
            }
            if (Build.VERSION.SDK_INT >= 33) context.registerReceiver(usbReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
            else context.registerReceiver(usbReceiver, filter)
            onDispose { runCatching { context.unregisterReceiver(usbReceiver) } }
        }

        Row(
            Modifier.fillMaxSize()
                .background(Navy)
                .clipToBounds()
                .graphicsLayer {
                    scaleX = zoom
                    scaleY = zoom
                    translationX = panX
                    translationY = panY
                    transformOrigin = TransformOrigin.Center
                }
                .pointerInput(zoom) {
                    detectDragGestures { change, dragAmount ->
                        if (zoom > 1.001f) {
                            change.consume()
                            val maxX = size.width * (zoom - 1f) / 2f
                            val maxY = size.height * (zoom - 1f) / 2f
                            panX = (panX + dragAmount.x).coerceIn(-maxX, maxX)
                            panY = (panY + dragAmount.y).coerceIn(-maxY, maxY)
                        }
                    }
                }
                .padding(4.dp)
        ) {
            Sidebar(page, { page = it }, Modifier.width(116.dp).fillMaxHeight())
            Column(Modifier.weight(1f).fillMaxHeight().padding(start = 4.dp)) {
                Header(deviceStatus, zoom, { zoom = (zoom - .05f).coerceIn(.7f, 1.6f); if (zoom <= 1f) { panX = 0f; panY = 0f } }, { zoom = (zoom + .05f).coerceIn(.7f, 1.6f) }, { zoom = 1f; panX = 0f; panY = 0f })
                if (page == "Home") {
                    HomeToolbar(
                        firmwarePicker = { firmwarePicker.launch("*/*") },
                        openFolder = { folderPicker.launch(null) },
                        settings = { page = "Settings" },
                        refresh = {
                            val manager = context.getSystemService(Context.USB_SERVICE) as UsbManager
                            val devices = manager.deviceList.values.toList()
                            if (devices.isEmpty()) {
                                deviceStatus = "Not connected"
                                deviceName = "Waiting for USB device"
                                log("No USB device detected. Check OTG adapter, cable and target mode.")
                            } else {
                                val reports = com.universalflasher.app.usb.UsbDiagnostics.scan(manager)
                                deviceStatus = "USB detected · identity pending"
                                val usbLabels = devices.map { usb ->
                                    val maker = runCatching { usb.manufacturerName }.getOrNull().orEmpty()
                                    val product = runCatching { usb.productName }.getOrNull().orEmpty()
                                    listOf(maker, product).filter { it.isNotBlank() }.distinct().joinToString(" ")
                                        .ifBlank { "USB ${usb.vendorId.toString(16).uppercase()}:${usb.productId.toString(16).uppercase()}" }
                                }
                                deviceName = usbLabels.joinToString("; ")
                                reports.forEach { log("${it.family}: ${it.name}; VID:PID=${it.vendorId.toString(16)}:${it.productId.toString(16)}; ${it.protocolState}") }
                                log("USB descriptors identify the attached interface only; exact phone model requires authorized ADB/Fastboot identification.")
                            }
                        },
                        clearLog = { logs = listOf("[SYSTEM] Log cleared.") },
                        animations = settingsAnimations,
                        status = deviceStatus,
                        device = deviceName
                    )
                    HomeDashboard(
                        modifier = Modifier.weight(1f),
                        brand = brand, onBrand = { brand = it; model = "Select model" },
                        model = model, onModel = { model = it },
                        flashMode = flashMode, onFlashMode = { flashMode = it },
                        partitions = partitions, onPartitions = { partitions = it },
                        firmwareName = firmwareName, onBrowse = { firmwarePicker.launch("*/*") },
                        report = firmwareReport,
                        deviceStatus = deviceStatus, deviceName = deviceName, androidVersion = androidVersion, battery = battery,
                        progress = progress, elapsed = elapsed, eta = eta, logs = logs,
                        running = running,
                        onStart = {
                            if (firmwareReport == null) log("Flash blocked: select and inspect a firmware package first.")
                            else if (deviceStatus != "Connected") log("Flash blocked: a protocol-ready device session has not been established.")
                            else if (model == "Select model") log("Flash blocked: select the exact device model.")
                            else log("Preflight passed. This UI build does not yet connect all vendor write engines to the job runner.")
                        },
                        onPause = { log(if (running) "Pause requested at safe checkpoint." else "No active flash job to pause.") },
                        onStop = { running = false; progress = 0f; log("Stop requested. No active job was running.") },
                        onReadGpt = { log("GPT read requires a protocol-ready device session; use Utilities > Partition Manager.") },
                        onLogs = { log(it) }
                    )
                } else {
                    PageWorkspace(
                        modifier = Modifier.weight(1f),
                        page = page,
                        context = context,
                        brand = brand,
                        model = model,
                        firmwareName = firmwareName,
                        report = firmwareReport,
                        logs = logs,
                        adbCommand = adbCommand,
                        onAdbCommand = { adbCommand = it },
                        fastbootVariable = fastbootVariable,
                        onFastbootVariable = { fastbootVariable = it },
                        utilityHash = utilityHash,
                        onUtilityHash = { utilityHash = it },
                        recoveryAction = selectedRecoveryAction,
                        onRecoveryAction = { selectedRecoveryAction = it },
                        animations = settingsAnimations,
                        onAnimations = { settingsAnimations = it },
                        confirm = settingsConfirm,
                        onConfirm = { settingsConfirm = it },
                        compact = settingsCompact,
                        onCompact = { settingsCompact = it },
                        language = settingsLanguage,
                        onLanguage = { settingsLanguage = it },
                        brandFilter = selectedBrandFilter,
                        onBrandFilter = { selectedBrandFilter = it },
                        onSelectBrand = { brand = it; model = "Select model"; page = "Home" },
                        onNavigate = { page = it },
                        onDeviceConnected = { name -> deviceStatus = "Connected"; deviceName = name },
                        onPickFirmware = { firmwarePicker.launch("*/*") },
                        onLog = { log(it) }
                    )
                }
                Footer(deviceStatus, if (firmwareReport != null) "Firmware inspected" else "Ready to Flash…")
            }
        }
    }
}

@Composable
private fun Sidebar(page: String, onNavigate: (String) -> Unit, modifier: Modifier) {
    Column(modifier.background(Brush.verticalGradient(listOf(Color(0xFF082B5D), Color(0xFF03142C))), RoundedCornerShape(12.dp)).border(1.dp, Cyan.copy(.75f), RoundedCornerShape(12.dp)).padding(5.dp)) {
        Row(Modifier.fillMaxWidth().height(45.dp), verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(R.drawable.icon_logo), null, Modifier.size(44.dp), contentScale = ContentScale.Fit)
            Spacer(Modifier.width(4.dp))
            Text("MULTI\nFLASHING TOOL", color = TextMain, fontSize = 12.sp, fontWeight = FontWeight.Black, lineHeight = 13.sp)
        }
        Spacer(Modifier.height(3.dp))
        navItems.forEach { item ->
            val selected = page == item
            Row(
                Modifier.fillMaxWidth().padding(vertical = 1.dp).height(30.dp)
                    .background(if (selected) Brush.horizontalGradient(listOf(Color(0xFF0D9BFF), Color(0xFF0754C2))) else Brush.horizontalGradient(listOf(Color(0xFF0A2851), Color(0xFF061A35))), RoundedCornerShape(7.dp))
                    .border(if (selected) 1.dp else .5.dp, if (selected) Color(0xFF73E5FF) else Cyan.copy(.22f), RoundedCornerShape(7.dp))
                    .clickable { onNavigate(item) }.padding(horizontal = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Image(painterResource(navAsset(item)), null, Modifier.size(25.dp), contentScale = ContentScale.Fit)
                Spacer(Modifier.width(6.dp))
                Text(item, color = TextMain, fontSize = 10.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (item == "All Brands") { Spacer(Modifier.weight(1f)); Icon(Icons.Default.ChevronRight, null, tint = Cyan, modifier = Modifier.size(15.dp)) }
            }
        }
        Spacer(Modifier.weight(1f))
        Image(painterResource(R.drawable.visual_phone_idle), null, Modifier.fillMaxWidth().height(48.dp), contentScale = ContentScale.Fit)
        Text("Flash Smart", color = TextMain, fontSize = 12.sp, fontWeight = FontWeight.Black, modifier = Modifier.align(Alignment.CenterHorizontally))
        Text("Stay Ahead", color = Color(0xFFFFE23B), fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.align(Alignment.CenterHorizontally))
    }
}

private fun navAsset(item: String): Int = when (item) {
    "Home" -> R.drawable.icon_home
    "All Brands" -> R.drawable.icon_phone
    "ADB Tools" -> R.drawable.icon_android
    "Fastboot Tools" -> R.drawable.icon_bolt
    "Recovery Tools" -> R.drawable.icon_sync
    "IMEI Tools" -> R.drawable.icon_fingerprint
    "Utilities" -> R.drawable.icon_tools
    "Settings" -> R.drawable.icon_gear
    else -> R.drawable.icon_info
}

@Composable
private fun Header(status: String, zoom: Float, minus: () -> Unit, plus: () -> Unit, reset: () -> Unit) {
    Row(Modifier.fillMaxWidth().height(44.dp).background(Brush.horizontalGradient(listOf(Color(0xFF061C3B), Color(0xFF0A3975), Color(0xFF061B38))), RoundedCornerShape(10.dp)).border(1.dp, Cyan.copy(.8f), RoundedCornerShape(10.dp)).padding(horizontal = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("Multi Flashing Tool", color = TextMain, fontSize = 19.sp, fontWeight = FontWeight.Black, maxLines = 1)
            Text("Professional Firmware & Flashing Solution", color = Color(0xFFB9E9FF), fontSize = 9.sp, maxLines = 1)
        }
        Image(painterResource(R.drawable.icon_gear), null, Modifier.size(21.dp))
        Spacer(Modifier.width(5.dp))
        Text("Version 1.8.0", color = Muted, fontSize = 9.sp)
        Spacer(Modifier.width(7.dp))
        Text("●", color = if (status == "Connected") Green else Amber, fontSize = 12.sp)
        Text(if (status == "Connected") "Ready" else "Not connected", color = TextMain, fontSize = 10.sp)
        Spacer(Modifier.width(7.dp))
        Text("−", color = TextMain, fontSize = 16.sp, modifier = Modifier.clickable { minus() }.padding(horizontal = 2.dp))
        Text("+", color = TextMain, fontSize = 16.sp, modifier = Modifier.clickable { plus() }.padding(horizontal = 2.dp))
        Text("↺", color = TextMain, fontSize = 14.sp, modifier = Modifier.clickable { reset() }.padding(horizontal = 2.dp))
    }
}

@Composable
private fun HomeToolbar(
    firmwarePicker: () -> Unit, openFolder: () -> Unit, settings: () -> Unit, refresh: () -> Unit, clearLog: () -> Unit,
    animations: Boolean, status: String, device: String
) {
    Row(Modifier.fillMaxWidth().height(61.dp).padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
        ToolbarTile("Select Firmware", R.drawable.icon_folder, Modifier.weight(1f), firmwarePicker)
        ToolbarTile("Open Folder", R.drawable.icon_folder_download, Modifier.weight(1f), openFolder)
        ToolbarTile("Options", R.drawable.icon_gear, Modifier.weight(.82f), settings)
        ToolbarTile("Refresh", R.drawable.icon_refresh, Modifier.weight(.82f), refresh)
        ToolbarTile("Clear Log", R.drawable.icon_broom, Modifier.weight(.9f), clearLog)
        DeviceStatusBadge(status, device, animations, Modifier.weight(1.35f))
    }
}

@Composable
private fun ToolbarTile(title: String, icon: Int, modifier: Modifier, onClick: () -> Unit) {
    Column(modifier.fillMaxHeight().background(Brush.verticalGradient(listOf(Color(0xFF123D78), Color(0xFF061A37))), RoundedCornerShape(8.dp)).border(1.dp, Cyan.copy(.65f), RoundedCornerShape(8.dp)).clickable { onClick() }.padding(3.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Image(painterResource(icon), null, Modifier.size(27.dp), contentScale = ContentScale.Fit)
        Text(title, color = TextMain, fontSize = 8.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun DeviceStatusBadge(status: String, device: String, animations: Boolean, modifier: Modifier) {
    val pulse = rememberInfiniteTransition(label = "connectionPulse")
    val animatedAlpha by pulse.animateFloat(.72f, 1f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "pulseAlpha")
    val alpha = if (animations) animatedAlpha else 1f
    val connected = status == "Connected"
    Row(modifier.fillMaxHeight().background(Brush.horizontalGradient(listOf(Color(0xFF0A2A55), Color(0xFF06172F))), RoundedCornerShape(8.dp)).border(1.dp, Cyan.copy(.5f), RoundedCornerShape(8.dp)).padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
        Image(painterResource(if (connected) R.drawable.visual_phone_connected else R.drawable.visual_phone_waiting), null, Modifier.size(38.dp).graphicsLayer { this.alpha = alpha }, contentScale = ContentScale.Fit)
        Spacer(Modifier.width(3.dp))
        Column(Modifier.weight(1f)) {
            Text(if (connected) "Device Connected" else status, color = if (connected) Green else Amber, fontSize = 9.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            Text(device, color = TextMain, fontSize = 8.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun HomeDashboard(
    modifier: Modifier = Modifier,
    brand: String, onBrand: (String) -> Unit, model: String, onModel: (String) -> Unit,
    flashMode: String, onFlashMode: (String) -> Unit, partitions: Set<String>, onPartitions: (Set<String>) -> Unit,
    firmwareName: String, onBrowse: () -> Unit, report: FirmwareInspector.Report?,
    deviceStatus: String, deviceName: String, androidVersion: String, battery: String,
    progress: Float, elapsed: String, eta: String, logs: List<String>, running: Boolean,
    onStart: () -> Unit, onPause: () -> Unit, onStop: () -> Unit, onReadGpt: () -> Unit, onLogs: (String) -> Unit
) {
    Column(modifier.fillMaxWidth().padding(top = 4.dp, bottom = 3.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(Modifier.weight(1.05f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            PanelCard("Firmware & Flash Options", Modifier.weight(1.55f), R.drawable.icon_chip) {
                InputRow("Select Brand:") {
                    DarkDropdown(brand, listOf("Auto Detect", "Samsung", "Google Pixel", "Xiaomi", "OnePlus", "Motorola", "Oppo", "Vivo", "Realme", "Other"), onBrand, Modifier.weight(1f))
                }
                InputRow("Select Model:") {
                    val models = when (brand) {
                        "Samsung" -> listOf("Select model", "Galaxy A54 (SM-A546B)", "Galaxy S23", "Galaxy A34", "Other / manual")
                        "Google Pixel" -> listOf("Select model", "Pixel 6a", "Pixel 7", "Pixel 8", "Other / manual")
                        "Xiaomi" -> listOf("Select model", "Redmi Note 10 Pro", "Redmi Note 12", "POCO X3", "Other / manual")
                        "OnePlus" -> listOf("Select model", "OnePlus 9", "OnePlus 10 Pro", "OnePlus 11", "Other / manual")
                        "Motorola" -> listOf("Select model", "Moto G Power", "Moto G Stylus", "Edge series", "Other / manual")
                        "Oppo" -> listOf("Select model", "Find X series", "Reno series", "A series", "Other / manual")
                        "Vivo" -> listOf("Select model", "X series", "V series", "Y series", "Other / manual")
                        "Realme" -> listOf("Select model", "GT series", "Number series", "C series", "Other / manual")
                        else -> listOf("Select model", "Enter exact model manually")
                    }
                    DarkDropdown(model, models, onModel, Modifier.weight(1f))
                }
                InputRow("Flash Mode:") {
                    Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Normal Flash", "Force Flash").forEach { mode ->
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { onFlashMode(mode) }) {
                                RadioButton(flashMode == mode, { onFlashMode(mode) }, modifier = Modifier.size(24.dp), colors = RadioButtonDefaults.colors(selectedColor = Cyan))
                                Text(mode, color = TextMain, fontSize = 9.sp, maxLines = 1)
                            }
                        }
                    }
                }
                InputRow("Partition:") {
                    Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                        listOf("Boot", "Recovery", "System", "Vendor").forEach { part ->
                            Row(Modifier.clickable { onPartitions(if (part in partitions) partitions - part else partitions + part) }, verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(part in partitions, { checked -> onPartitions(if (checked) partitions + part else partitions - part) }, modifier = Modifier.size(22.dp), colors = CheckboxDefaults.colors(checkedColor = Blue))
                                Text(part, color = TextMain, fontSize = 8.sp)
                            }
                        }
                    }
                }
                InputRow("Firmware File:") {
                    Box(Modifier.weight(1f).background(Color(0xFF07182F), RoundedCornerShape(5.dp)).border(1.dp, Color(0xFF5385B6), RoundedCornerShape(5.dp)).padding(horizontal = 7.dp, vertical = 6.dp)) {
                        Text(firmwareName, color = TextMain, fontSize = 8.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    SmallImageButton(R.drawable.icon_folder, "Browse", onBrowse)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(painterResource(if (report != null) R.drawable.visual_success else R.drawable.visual_warning), null, Modifier.size(18.dp))
                    Text(report?.let { "${it.detectedType} · ${it.sizeBytes} bytes · SHA-256 verified locally" } ?: "Select a firmware package for read-only inspection", color = if (report != null) Green else Amber, fontSize = 7.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            PanelCard("Device Information", Modifier.weight(.92f), R.drawable.icon_info) {
                Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        InfoLine("Brand:", if (brand == "Auto Detect") "—" else "$brand (selected)")
                        InfoLine("Model:", if (deviceStatus == "Connected") deviceName else "Waiting for device")
                        InfoLine("Android:", androidVersion)
                        InfoLine("Status:", deviceStatus, if (deviceStatus == "Connected") Green else Amber)
                        InfoLine("Battery:", battery)
                        var showGuides by remember { mutableStateOf(false) }
                        ActionButton("Illustrated Mode Guide") { showGuides = true }
                        if (showGuides) DeviceModeGuideDialog(deviceName, model, deviceStatus) { showGuides = false }
                    }
                    Image(painterResource(if (deviceStatus.startsWith("Connected")) R.drawable.visual_phone_connected else R.drawable.visual_phone_idle), null, Modifier.width(70.dp).fillMaxHeight(), contentScale = ContentScale.Fit)
                }
            }
        }
        Row(Modifier.fillMaxWidth().height(48.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            BigAction("⚡  Start Flash", Green, Modifier.weight(1.2f), onStart)
            BigAction("Ⅱ  Pause", Amber, Modifier.weight(.9f), onPause)
            BigAction("■  Stop", Red, Modifier.weight(.9f), onStop)
        }
        Row(Modifier.weight(.72f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            val latestLog = logs.firstOrNull().orEmpty()
            val logIcon = when {
                latestLog.contains("error", true) || latestLog.contains("fail", true) -> R.drawable.bell_error
                latestLog.contains("warning", true) || latestLog.contains("blocked", true) -> R.drawable.visual_warning
                else -> R.drawable.bell_success
            }
            PanelCard("Flash Log / Status", Modifier.weight(1.5f), logIcon) {
                Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Top) {
                    logs.take(6).forEach { line ->
                        Text(line, color = if (line.contains("fail", true) || line.contains("blocked", true) || line.contains("warning", true)) Amber else Color(0xFFE1F0FF), fontSize = 8.sp, fontFamily = FontFamily.Monospace, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(vertical = 1.dp))
                    }
                }
            }
            PanelCard("Progress", Modifier.weight(.72f), R.drawable.progress_ring) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("${(progress * 100).toInt()}%", color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
                    Image(painterResource(R.drawable.progress_ring), null, Modifier.size(28.dp))
                }
                LinearProgressIndicator(progress = { progress }, Modifier.fillMaxWidth().height(7.dp).clip(RoundedCornerShape(8.dp)), color = Cyan, trackColor = Color(0xFF34577D))
                Text("◷  Elapsed : $elapsed", color = TextMain, fontSize = 8.sp)
                Text("◴  Estimated : $eta", color = Muted, fontSize = 8.sp)
                Text(if (running) "Operation running" else "Idle", color = if (running) Green else Muted, fontSize = 8.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun PanelCard(title: String, modifier: Modifier = Modifier, titleIcon: Int? = null, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.background(Brush.verticalGradient(listOf(Color(0xFF0A2A55), Color(0xFF04162F))), RoundedCornerShape(9.dp)).border(1.dp, Cyan.copy(.72f), RoundedCornerShape(9.dp)).padding(6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (titleIcon != null) Image(painterResource(titleIcon), null, Modifier.size(21.dp), contentScale = ContentScale.Fit)
            Text(title, color = TextMain, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
        }
        HorizontalDivider(color = Cyan.copy(.48f), modifier = Modifier.padding(top = 3.dp, bottom = 4.dp))
        content()
    }
}

@Composable
private fun InputRow(label: String, content: @Composable RowScope.() -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 1.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = TextMain, fontSize = 9.sp, modifier = Modifier.width(78.dp), maxLines = 1)
        content()
    }
}

@Composable
private fun DarkDropdown(value: String, options: List<String>, onSelect: (String) -> Unit, modifier: Modifier = Modifier) {
    var expanded by remember { mutableStateOf(false) }
    Box(modifier) {
        Row(Modifier.fillMaxWidth().height(27.dp).background(Color(0xFF0A2449), RoundedCornerShape(5.dp)).border(1.dp, Color(0xFF4E8FCB), RoundedCornerShape(5.dp)).clickable { expanded = true }.padding(horizontal = 7.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(value, color = TextMain, fontSize = 9.sp, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
            Icon(Icons.Default.ArrowDropDown, null, tint = Cyan, modifier = Modifier.size(17.dp))
        }
        DropdownMenu(expanded, { expanded = false }) {
            options.forEach { item -> DropdownMenuItem(text = { Text(item, fontSize = 11.sp) }, onClick = { onSelect(item); expanded = false }) }
        }
    }
}

@Composable
private fun SmallImageButton(icon: Int, label: String, onClick: () -> Unit) {
    Row(Modifier.height(27.dp).background(Brush.verticalGradient(listOf(Color(0xFF087FE9), Color(0xFF064A9E))), RoundedCornerShape(5.dp)).border(1.dp, Cyan, RoundedCornerShape(5.dp)).clickable { onClick() }.padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Image(painterResource(icon), null, Modifier.size(19.dp))
        Text(label, color = Color.White, fontSize = 8.sp)
    }
}

@Composable
private fun InfoLine(label: String, value: String, valueColor: Color = TextMain) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Muted, fontSize = 8.sp, modifier = Modifier.width(58.dp), maxLines = 1)
        Text(value, color = valueColor, fontSize = 8.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun BigAction(title: String, color: Color, modifier: Modifier, onClick: () -> Unit) {
    Button(onClick = onClick, modifier = modifier.fillMaxHeight().border(1.dp, Color.White.copy(.65f), RoundedCornerShape(10.dp)), shape = RoundedCornerShape(10.dp), colors = ButtonDefaults.buttonColors(containerColor = color), contentPadding = PaddingValues(2.dp)) {
        Text(title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Black, maxLines = 1)
    }
}

@Composable
private fun Footer(status: String, message: String) {
    Row(Modifier.fillMaxWidth().height(20.dp).background(Brush.horizontalGradient(listOf(Color(0xFF061B38), Color(0xFF0B3264))), RoundedCornerShape(7.dp)).border(1.dp, Cyan.copy(.7f), RoundedCornerShape(7.dp)).padding(horizontal = 7.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("●", color = if (status == "Connected") Green else Amber, fontSize = 10.sp)
        Spacer(Modifier.width(4.dp))
        Text(message, color = TextMain, fontSize = 8.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.weight(1f))
        Text("Multi Flashing Tool · Your Ultimate Flashing Partner", color = Color(0xFF79E7FF), fontSize = 8.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

@Composable
private fun DeviceModeGuideDialog(deviceName: String, selectedModel: String, deviceStatus: String, onDismiss: () -> Unit) {
    var mode by remember { mutableStateOf("Fastboot / Bootloader") }
    val exactModel = selectedModel.takeIf { it != "Select model" && it.isNotBlank() }
        ?: deviceName.takeIf { it.isNotBlank() && it != "Waiting for USB device" }
        ?: "Unknown model"
    val modelVerified = selectedModel != "Select model" && selectedModel.isNotBlank()
    val steps = when (mode) {
        "Fastboot / Bootloader" -> listOf(
            "Confirm the exact model shown above before using a key combination.",
            "Use the OEM's documented bootloader-entry method for this exact model; key combinations differ by device.",
            "Connect USB only when the model's guide requests it, then run read-only Fastboot detection.",
            "Continue only when the detected product matches the phone."
        )
        "Recovery" -> listOf(
            "Confirm the exact model and current power state.",
            "Use the manufacturer's documented Recovery key sequence for this model; do not guess the buttons.",
            "Wait for the Recovery screen to appear before selecting any operation.",
            "Never choose wipe, format or install unless you intend that operation and have a verified package."
        )
        "Download Mode (Samsung)" -> listOf(
            "This guide applies only to a positively identified supported Samsung model.",
            "Check the exact model's Samsung/OEM instructions for its Download Mode key sequence; it varies by generation.",
            "Read the on-device warning and confirm only when you understand it.",
            "Do not flash until the firmware model/CSC and package integrity have been checked."
        )
        else -> listOf(
            "EDL is supported only on compatible Qualcomm devices and authorized service workflows.",
            "Do not use an unverified test-point location: board revisions and component placement differ.",
            "Use only an exact-model, board-revision service manual and authorized procedure.",
            "Proceed only after the host detects the expected Qualcomm 9008 interface and the programmer is trusted."
        )
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Navy2,
        title = { Text("Device Mode Guide", color = TextMain, fontWeight = FontWeight.Bold) },
        text = {
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("Target: $exactModel", color = Cyan, fontWeight = FontWeight.Bold)
                Text("USB state: $deviceStatus", color = Muted)
                DarkDropdown(mode, listOf("Fastboot / Bootloader", "Recovery", "Download Mode (Samsung)", "EDL (Qualcomm)"), { mode = it }, Modifier.fillMaxWidth())
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Image(painterResource(R.drawable.phone_front), null, Modifier.width(74.dp).height(125.dp), contentScale = ContentScale.Fit)
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text("Illustrated handset reference", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("This bundled handset graphic is a neutral guide illustration, not a verified photo of the connected model. Numbered steps below are safety guidance, not a device-specific button map.", color = Amber, fontSize = 9.sp)
                    }
                }
                steps.forEachIndexed { index, step ->
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.Top) {
                        Text("${index + 1}", color = Navy, fontWeight = FontWeight.Black, modifier = Modifier.background(Cyan, RoundedCornerShape(20.dp)).padding(horizontal = 7.dp, vertical = 2.dp))
                        Text(step, color = TextMain, fontSize = 9.sp)
                    }
                }
                if (!modelVerified) Text("Exact model is not verified yet. The app must not display model-specific button positions or EDL test points until ADB/Fastboot or a trusted model database confirms the model.", color = Red, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close", color = Cyan) } }
    )
}

@Composable
private fun PageWorkspace(
    modifier: Modifier = Modifier,
    page: String, context: Context, brand: String, model: String, firmwareName: String, report: FirmwareInspector.Report?, logs: List<String>,
    adbCommand: String, onAdbCommand: (String) -> Unit, fastbootVariable: String, onFastbootVariable: (String) -> Unit,
    utilityHash: String, onUtilityHash: (String) -> Unit, recoveryAction: String, onRecoveryAction: (String) -> Unit,
    animations: Boolean, onAnimations: (Boolean) -> Unit, confirm: Boolean, onConfirm: (Boolean) -> Unit,
    compact: Boolean, onCompact: (Boolean) -> Unit, language: String, onLanguage: (String) -> Unit,
    brandFilter: String, onBrandFilter: (String) -> Unit, onSelectBrand: (String) -> Unit, onNavigate: (String) -> Unit,
    onDeviceConnected: (String) -> Unit, onPickFirmware: () -> Unit, onLog: (String) -> Unit
) {
    Column(modifier.fillMaxWidth().padding(top = 4.dp, bottom = 3.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Row(Modifier.fillMaxWidth().height(32.dp).background(Brush.horizontalGradient(listOf(Color(0xFF0B3974), Color(0xFF061A36))), RoundedCornerShape(7.dp)).border(1.dp, Cyan.copy(.55f), RoundedCornerShape(7.dp)).padding(horizontal = 9.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(page, color = TextMain, fontSize = 15.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.weight(1f))
            Text("Professional Device Service Workspace", color = Muted, fontSize = 8.sp)
        }
        when (page) {
            "All Brands" -> BrandsPage(brandFilter, onBrandFilter, onSelectBrand, onLog)
            "ADB Tools" -> AdbPage(context, adbCommand, onAdbCommand, onDeviceConnected, onLog)
            "Fastboot Tools" -> FastbootPage(context, fastbootVariable, onFastbootVariable, onDeviceConnected, onLog)
            "Recovery Tools" -> RecoveryPage(recoveryAction, onRecoveryAction, onPickFirmware, onLog)
            "IMEI Tools" -> ImeiPage(onLog)
            "Utilities" -> UtilitiesPage(context, firmwareName, report, logs, utilityHash, onUtilityHash, onPickFirmware, onLog)
            "Settings" -> SettingsPage(animations, onAnimations, confirm, onConfirm, compact, onCompact, language, onLanguage)
            else -> AboutPage(onNavigate)
        }
    }
}

@Composable
private fun BrandsPage(filter: String, onFilter: (String) -> Unit, onSelectBrand: (String) -> Unit, onLog: (String) -> Unit) {
    val brands = listOf("Samsung", "Google Pixel", "Xiaomi", "OnePlus", "Motorola", "Oppo", "Vivo", "Realme", "Nothing", "Other Android")
    val filtered = brands.filter { it.contains(filter, true) }
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(filter, onFilter, Modifier.weight(1f).height(48.dp), placeholder = { Text("Search brand or model", fontSize = 10.sp) }, singleLine = true, textStyle = androidx.compose.ui.text.TextStyle(color = TextMain, fontSize = 10.sp))
            Spacer(Modifier.width(6.dp))
            Text("Select a brand to load its model catalogue", color = Muted, fontSize = 9.sp)
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            filtered.chunked(5).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    row.forEach { name ->
                        Column(Modifier.weight(1f).padding(vertical = 2.dp).background(Panel, RoundedCornerShape(8.dp)).border(1.dp, Cyan.copy(.5f), RoundedCornerShape(8.dp)).clickable { onLog("Brand selected: $name. Choose exact model and verify firmware before flashing."); onSelectBrand(name) }.padding(7.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Image(painterResource(if (name == "Samsung" || name == "Google Pixel") R.drawable.visual_phone_connected else R.drawable.icon_phone), null, Modifier.size(42.dp))
                            Text(name, color = TextMain, fontSize = 9.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                            Text("Model catalogue", color = Muted, fontSize = 7.sp)
                        }
                    }
                    repeat(5 - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
        }
        Text("Brand listing is not a compatibility guarantee. Device model, region, bootloader state and firmware build must match.", color = Amber, fontSize = 8.sp)
    }
}

@Composable
private fun AdbPage(context: Context, command: String, onCommand: (String) -> Unit, onDeviceConnected: (String) -> Unit, onLog: (String) -> Unit) {
    Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        PanelCard("ADB Device & Connection", Modifier.weight(.9f)) {
            Image(painterResource(R.drawable.icon_android), null, Modifier.size(42.dp))
            Text("USB debugging must be enabled. Unlock the target phone and approve its RSA debugging prompt.", color = Muted, fontSize = 8.sp)
            ActionButton("Detect ADB Device") {
                val manager = context.getSystemService(Context.USB_SERVICE) as UsbManager
                val device = manager.deviceList.values.firstOrNull { d -> (0 until d.interfaceCount).any { d.getInterface(it).let { f -> f.interfaceClass == 0xff && f.interfaceSubclass == 0x42 && f.interfaceProtocol == 0x01 } } }
                if (device == null) onLog("ADB: no standard ADB USB interface detected.")
                else if (!manager.hasPermission(device)) { UsbPermissionHelper.request(context, device); onLog("ADB: USB permission requested; grant it and retry.") }
                else runCatching { AdbUsbTransport(context, device).use { t -> check(t.open()) { "Could not claim ADB interface" }; val reply = t.probeHandshake(); onLog("ADB handshake: command=${reply.command}, arg0=${reply.arg0}, arg1=${reply.arg1}") } }.onFailure { onLog("ADB probe failed: ${it.message}") }
            }
        }
        PanelCard("ADB Command Console", Modifier.weight(1.35f)) {
            Text("Command input", color = Muted, fontSize = 8.sp)
            OutlinedTextField(command, onCommand, Modifier.fillMaxWidth().height(52.dp), singleLine = true, textStyle = androidx.compose.ui.text.TextStyle(color = TextMain, fontSize = 10.sp))
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                ActionButton("Run shell command") {
                    val manager = context.getSystemService(Context.USB_SERVICE) as UsbManager
                    val device = manager.deviceList.values.firstOrNull { d -> (0 until d.interfaceCount).any { d.getInterface(it).let { f -> f.interfaceClass == 0xff && f.interfaceSubclass == 0x42 && f.interfaceProtocol == 0x01 } } }
                    if (device == null) onLog("ADB shell: no ADB USB interface detected.")
                    else if (!manager.hasPermission(device)) { UsbPermissionHelper.request(context, device); onLog("ADB shell: USB permission requested; grant it and retry.") }
                    else runCatching {
                        AdbUsbTransport(context, device).use { transport ->
                            check(transport.open()) { "Could not claim ADB USB interface" }
                            val identity = AdbRsaIdentity.loadOrCreate(java.io.File(context.filesDir, "adb-identity"))
                            val session = AdbHostSession(transport.inputStream(), transport.outputStream(), identity)
                            val banner = session.connect()
                            val productName = Regex("ro.product.(?:model|name)=([^;\\s]+)").find(banner)?.groupValues?.get(1) ?: "ADB authorized device"
                            onDeviceConnected(productName)
                            onLog("ADB authorized: ${banner.take(180)}")
                            val result = AdbShellService(session).execute(command)
                            onLog("ADB exit=${result.exitCode}; stdout=${result.stdout.take(1500)}; stderr=${result.stderr.take(1000)}")
                        }
                    }.onFailure { onLog("ADB command failed: ${it.message}") }
                }
                ActionButton("ADB connection probe") {
                    val manager = context.getSystemService(Context.USB_SERVICE) as UsbManager
                    val device = manager.deviceList.values.firstOrNull { d -> (0 until d.interfaceCount).any { d.getInterface(it).let { f -> f.interfaceClass == 0xff && f.interfaceSubclass == 0x42 && f.interfaceProtocol == 0x01 } } }
                    if (device == null) onLog("ADB: no standard ADB USB interface detected.")
                    else if (!manager.hasPermission(device)) { UsbPermissionHelper.request(context, device); onLog("ADB: USB permission requested; retry after granting it.") }
                    else runCatching { AdbUsbTransport(context, device).use { t -> check(t.open()); val p = t.probeHandshake(); onLog("ADB probe response=${p.command}; arg0=${p.arg0}; arg1=${p.arg1}") } }.onFailure { onLog("ADB probe failed: ${it.message}") }
                }
            }
            Text("Available planned commands: devices, get-state, get-serialno, shell, install, uninstall, push, pull, reboot and logcat. Shell/file execution is not enabled until authenticated ADB services are integrated.", color = Amber, fontSize = 8.sp)
        }
        PanelCard("ADB Output", Modifier.weight(1f)) {
            Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                listOf("ADB host transport", "RSA authorization: device approval required", "Shell service: pending integration").forEach { Text(it, color = Muted, fontSize = 8.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }
            }
        }
    }
}

@Composable
private fun FastbootPage(context: Context, variable: String, onVariable: (String) -> Unit, onDeviceConnected: (String) -> Unit, onLog: (String) -> Unit) {
    Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        PanelCard("Fastboot Device", Modifier.weight(.9f)) {
            Image(painterResource(R.drawable.icon_bolt), null, Modifier.size(42.dp))
            Text("Connect a supported device in bootloader / Fastboot mode.", color = Muted, fontSize = 8.sp)
            ActionButton("Run Read-only Detection") {
                val manager = context.getSystemService(Context.USB_SERVICE) as UsbManager
                val device = manager.deviceList.values.firstOrNull { d -> (0 until d.interfaceCount).any { d.getInterface(it).let { f -> f.interfaceClass == 0xff && f.interfaceSubclass == 0x42 && f.interfaceProtocol == 0x03 && (0 until f.endpointCount).any { f.getEndpoint(it).type == android.hardware.usb.UsbConstants.USB_ENDPOINT_XFER_BULK } } } }
                if (device == null) onLog("Fastboot: no vendor-specific USB bulk device detected.")
                else if (!manager.hasPermission(device)) { UsbPermissionHelper.request(context, device); onLog("Fastboot: USB permission requested; grant it and retry.") }
                else runCatching { FastbootUsbTransport(context, device).use { t -> check(t.open()) { "Could not claim Fastboot interface" }; onLog("Fastboot connected; product=${t.getVar("product")}, version=${t.getVar("version")}, serial=${t.getVar("serialno")}") } }.onFailure { onLog("Fastboot diagnostics failed: ${it.message}") }
            }
        }
        PanelCard("Read-only Getvar", Modifier.weight(1.1f)) {
            DarkDropdown(variable, listOf("product", "version", "serialno", "is-userspace", "unlocked", "current-slot", "slot-count"), onVariable, Modifier.fillMaxWidth())
            ActionButton("Query selected variable") {
                val manager = context.getSystemService(Context.USB_SERVICE) as UsbManager
                val device = manager.deviceList.values.firstOrNull { d -> (0 until d.interfaceCount).any { d.getInterface(it).let { f -> f.interfaceClass == 0xff && f.interfaceSubclass == 0x42 && f.interfaceProtocol == 0x03 && (0 until f.endpointCount).any { f.getEndpoint(it).type == android.hardware.usb.UsbConstants.USB_ENDPOINT_XFER_BULK } } } }
                if (device == null) onLog("Fastboot getvar: no Fastboot USB device detected.")
                else if (!manager.hasPermission(device)) { UsbPermissionHelper.request(context, device); onLog("Fastboot getvar: USB permission requested; retry after granting it.") }
                else runCatching { FastbootUsbTransport(context, device).use { t -> check(t.open()); val value = t.getVar(variable); if (variable == "product") onDeviceConnected(value.ifBlank { "Fastboot device" }); onLog("Fastboot getvar $variable = $value") } }.onFailure { onLog("Fastboot getvar failed: ${it.message}") }
            }
            Text("The current transport supports read-only diagnostics in this screen. Flash and erase controls remain gated until product-specific validation is complete.", color = Amber, fontSize = 8.sp)
        }
        PanelCard("Supported Operations", Modifier.weight(1f)) {
            listOf("getvar all", "reboot", "reboot-bootloader", "boot image (validation required)", "flash partition (gated)", "erase partition (gated)").forEach { Text("• $it", color = TextMain, fontSize = 8.sp, modifier = Modifier.padding(vertical = 3.dp)) }
        }
    }
}

@Composable
private fun RecoveryPage(action: String, onAction: (String) -> Unit, onPickFirmware: () -> Unit, onLog: (String) -> Unit) {
    Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        PanelCard("Recovery Actions", Modifier.weight(1f)) {
            Image(painterResource(R.drawable.icon_sync), null, Modifier.size(42.dp))
            DarkDropdown(action, listOf("Reboot to Recovery", "Reboot to Bootloader", "ADB Sideload", "Inspect Recovery Image"), onAction, Modifier.fillMaxWidth())
            ActionButton("Prepare action") { onLog("Recovery action selected: $action. Execution requires a connected authenticated ADB/Fastboot session and model-specific validation.") }
            Text("Only signed or trusted recovery images built for the exact device model should be used.", color = Amber, fontSize = 8.sp)
        }
        PanelCard("Recovery Package", Modifier.weight(1.1f)) {
            Text("Package: no recovery package selected", color = TextMain, fontSize = 9.sp)
            Text("Compatibility: not checked", color = Amber, fontSize = 8.sp)
            Text("Sideload state: idle", color = Muted, fontSize = 8.sp)
            ActionButton("Select recovery package", onClick = onPickFirmware)
        }
        PanelCard("Recovery Log", Modifier.weight(1f)) {
            Text("No recovery operation started.", color = Muted, fontSize = 8.sp)
            Text("Actions become available when a supported transport session is active.", color = Amber, fontSize = 8.sp)
        }
    }
}

@Composable
private fun ImeiPage(onLog: (String) -> Unit) {
    Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        PanelCard("Device Identity Diagnostics", Modifier.weight(1.1f)) {
            Image(painterResource(R.drawable.icon_fingerprint), null, Modifier.size(46.dp))
            InfoLine("Serial:", "Unavailable")
            InfoLine("IMEI slot 1:", "Restricted / not read")
            InfoLine("IMEI slot 2:", "Restricted / not read")
            InfoLine("Baseband:", "Unavailable")
            ActionButton("Refresh read-only diagnostics") { onLog("Identity diagnostics requested. Android privacy and OEM restrictions may prevent IMEI access.") }
        }
        PanelCard("Privacy & Safety", Modifier.weight(1f)) {
            Text("This page is for lawful, read-only device diagnostics. It does not modify, rewrite, repair, or generate IMEI values.", color = TextMain, fontSize = 9.sp)
            Text("IMEI access may be restricted by Android version, permissions, OEM policy and device state.", color = Amber, fontSize = 8.sp)
        }
        PanelCard("Diagnostic Result", Modifier.weight(1f)) { Text("No device identity data received.", color = Muted, fontSize = 8.sp) }
    }
}

@Composable
private fun UtilitiesPage(context: Context, firmwareName: String, report: FirmwareInspector.Report?, logs: List<String>, hash: String, onHash: (String) -> Unit, onPickFirmware: () -> Unit, onLog: (String) -> Unit) {
    Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        PanelCard("Firmware Inspector", Modifier.weight(1.2f)) {
            Text(firmwareName, color = TextMain, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            ActionButton("Select firmware", onClick = onPickFirmware)
            InfoLine("Format:", report?.detectedType ?: "Unknown")
            InfoLine("Size:", report?.let { "${it.sizeBytes} bytes" } ?: "—")
            InfoLine("Partitions:", report?.partitionNames?.size?.toString() ?: "—")
            InfoLine("SHA-256:", report?.sha256?.take(16)?.plus("…") ?: "Not calculated")
        }
        PanelCard("Partition Manager", Modifier.weight(1.2f)) {
            Text("Verified device GPT is required before showing physical partition offsets.", color = Amber, fontSize = 8.sp)
            ActionButton("Read GPT from device", enabled = false) { onLog("GPT read requires a live, protocol-ready device session.") }
            ActionButton("Copy package partition list", enabled = report != null) {
                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Firmware partition inventory", report?.partitionNames?.joinToString("\n").orEmpty()))
                onLog("Package partition inventory copied. These are package entries, not live GPT offsets.")
            }
            Text("Firmware package entries are not device GPT addresses.", color = Muted, fontSize = 8.sp)
        }
        PanelCard("Checksum & Logs", Modifier.weight(1.1f)) {
            Text("SHA-256", color = Muted, fontSize = 8.sp)
            OutlinedTextField(hash, onHash, Modifier.fillMaxWidth().height(48.dp), readOnly = true, textStyle = androidx.compose.ui.text.TextStyle(color = TextMain, fontSize = 8.sp))
            ActionButton("Copy checksum", enabled = hash.isNotBlank()) {
                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Firmware SHA-256", hash))
                onLog("Firmware SHA-256 copied to clipboard.")
            }
            ActionButton("Export diagnostic log") {
                runCatching {
                    val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_SUBJECT, "Universal Multi Flashing Tool diagnostic log"); putExtra(Intent.EXTRA_TEXT, logs.joinToString("\n")) }
                    context.startActivity(Intent.createChooser(send, "Export Flash Log"))
                }.onFailure { onLog("Could not open log export: ${it.message}") }
            }
        }
    }
}

@Composable
private fun SettingsPage(animations: Boolean, onAnimations: (Boolean) -> Unit, confirm: Boolean, onConfirm: (Boolean) -> Unit, compact: Boolean, onCompact: (Boolean) -> Unit, language: String, onLanguage: (String) -> Unit) {
    Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        PanelCard("Appearance", Modifier.weight(1f)) {
            InfoLine("Theme:", "Reference Neon Blue")
            InfoLine("Layout:", "Landscape workspace")
            SettingSwitch("UI animations", animations, onAnimations)
            SettingSwitch("Compact screen fit", compact, onCompact)
            DarkDropdown(language, listOf("English", "বাংলা"), onLanguage, Modifier.fillMaxWidth())
        }
        PanelCard("Safety & Confirmation", Modifier.weight(1f)) {
            SettingSwitch("Confirm destructive operations", confirm, onConfirm)
            Text("Critical write/erase operations must retain a mandatory final confirmation regardless of this preference.", color = Amber, fontSize = 8.sp)
            InfoLine("USB:", "Android USB Host / OTG")
            InfoLine("Log retention:", "Last 500 entries")
        }
        PanelCard("Display & Scale", Modifier.weight(1f)) {
            Text("The workspace auto-fits the screen. Use + / − / reset to zoom; drag the workspace while zoomed in to reach clipped areas.", color = TextMain, fontSize = 9.sp)
            Text("The reference layout stays fixed. No page-level scrolling is used; zoom and drag are available when controls need enlargement.", color = Muted, fontSize = 8.sp)
        }
    }
}

@Composable
private fun SettingSwitch(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = TextMain, fontSize = 9.sp, modifier = Modifier.weight(1f))
        Switch(checked, onChange)
    }
}

@Composable
private fun AboutPage(onNavigate: (String) -> Unit) {
    Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        PanelCard("Application", Modifier.weight(1f)) {
            Image(painterResource(R.drawable.icon_logo), null, Modifier.size(58.dp))
            Text("Multi Flashing Tool", color = TextMain, fontSize = 14.sp, fontWeight = FontWeight.Black)
            InfoLine("Version:", "1.8.0")
            InfoLine("Edition:", "Android OTG")
            InfoLine("Build:", "Engineering release")
        }
        PanelCard("Capabilities", Modifier.weight(1.2f)) {
            listOf("USB host diagnostics", "Firmware package inspection", "ADB/Fastboot protocol foundations", "Qualcomm / MediaTek / Samsung modules", "GPT and partition validation", "3D connection and status graphics").forEach { Text("✓  $it", color = TextMain, fontSize = 8.sp, modifier = Modifier.padding(vertical = 2.dp)) }
        }
        PanelCard("Support & Documentation", Modifier.weight(1f)) {
            Text("See README.md and IMPLEMENTATION_STATUS.md for the exact supported feature matrix and known limitations.", color = Muted, fontSize = 9.sp)
            ActionButton("Open Settings") { onNavigate("Settings") }
            Text("This release does not claim universal model compatibility. Hardware-tested support must be documented per model.", color = Amber, fontSize = 8.sp)
        }
    }
}

@Composable
private fun ActionButton(label: String, enabled: Boolean = true, onClick: () -> Unit) {
    Button(onClick = onClick, enabled = enabled, modifier = Modifier.padding(vertical = 2.dp), contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp), colors = ButtonDefaults.buttonColors(containerColor = Blue, disabledContainerColor = Color(0xFF253D5D))) {
        Text(label, fontSize = 8.sp, maxLines = 1)
    }
}
