package com.universalflasher.app

import android.content.Context
import android.hardware.usb.UsbManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Navy = Color(0xFF06152C)
private val Panel = Color(0xFF0B2345)
private val Panel2 = Color(0xFF102D57)
private val Blue = Color(0xFF087CEB)
private val Cyan = Color(0xFF20C8FF)
private val TextMain = Color(0xFFF3F8FF)
private val Muted = Color(0xFF9EB5D3)
private val Green = Color(0xFF39D66F)
private val Amber = Color(0xFFFFB52E)
private val Red = Color(0xFFFF4545)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { FlasherApp(this) } }
    }
}

@Composable
private fun FlasherApp(context: Context) {
    var selectedPage by remember { mutableStateOf("Home") }
    var selectedPlatform by remember { mutableStateOf("Qualcomm") }
    var selectedBrand by remember { mutableStateOf("Auto Detect") }
    var selectedModel by remember { mutableStateOf("Select model") }
    var firmware by remember { mutableStateOf("No firmware selected") }
    var deviceStatus by remember { mutableStateOf("Not connected") }
    var deviceName by remember { mutableStateOf("Waiting for USB device") }
    var operation by remember { mutableStateOf("Flash Firmware") }
    var flashMode by remember { mutableStateOf("Normal") }
    var progress by remember { mutableFloatStateOf(0f) }
    var isRunning by remember { mutableStateOf(false) }
    var logLines by remember { mutableStateOf(listOf("Universal Multi Flashing Tool initialized.", "Connect a supported device using a USB OTG adapter.", "Choose a platform and load a compatible firmware package.")) }
    var queue by remember { mutableStateOf(listOf("Waiting for firmware and device validation")) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            firmware = uri.lastPathSegment?.substringAfterLast('/') ?: "Firmware selected"
            logLines = listOf("Firmware selected: $firmware", "Package parsing is not enabled in this starter build.") + logLines
        }
    }
    fun log(message: String) {
        val stamp = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        logLines = listOf("[$stamp] $message") + logLines
    }

    Row(Modifier.fillMaxSize().background(Navy).padding(8.dp)) {
        Column(Modifier.width(176.dp).fillMaxHeight().background(Brush.verticalGradient(listOf(Color(0xFF0C2A55), Color(0xFF06152C))), RoundedCornerShape(14.dp)).border(1.dp, Cyan.copy(.45f), RoundedCornerShape(14.dp)).padding(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(5.dp)) {
                Icon(Icons.Default.Bolt, null, tint = Cyan, modifier = Modifier.size(28.dp))
                Spacer(Modifier.width(6.dp))
                Text("MULTI\nFLASHER", color = TextMain, fontWeight = FontWeight.Black, fontSize = 16.sp, lineHeight = 17.sp)
            }
            Spacer(Modifier.height(10.dp))
            listOf("Home", "All Brands", "ADB Tools", "Fastboot Tools", "Recovery Tools", "IMEI Tools", "Utilities", "Settings", "About").forEach { item ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 2.dp).background(if (selectedPage == item) Brush.horizontalGradient(listOf(Blue, Color(0xFF0751B5))) else Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent)), RoundedCornerShape(9.dp)).clickable { selectedPage = item }.padding(horizontal = 9.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(navIcon(item), null, tint = if (selectedPage == item) Color.White else Cyan, modifier = Modifier.size(19.dp))
                    Spacer(Modifier.width(9.dp))
                    Text(item, color = TextMain, fontSize = 12.sp, fontWeight = if (selectedPage == item) FontWeight.Bold else FontWeight.Medium)
                }
            }
            Spacer(Modifier.weight(1f))
            Text("FLASH SMART", color = Cyan, fontWeight = FontWeight.Black, fontSize = 17.sp)
            Text("Device-safe workflow", color = Muted, fontSize = 10.sp)
        }

        Column(Modifier.weight(1f).fillMaxHeight().padding(start = 8.dp)) {
            Row(Modifier.fillMaxWidth().height(52.dp).background(Brush.horizontalGradient(listOf(Color(0xFF09264C), Color(0xFF0A3971))), RoundedCornerShape(12.dp)).border(1.dp, Cyan.copy(.55f), RoundedCornerShape(12.dp)).padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Universal Multi Flashing Tool", color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                    Text("Professional Firmware & Device Service Workspace", color = Muted, fontSize = 10.sp)
                }
                Text("v1.0.0", color = Muted, fontSize = 11.sp)
                Spacer(Modifier.width(12.dp))
                Text("●", color = if (deviceStatus == "Connected") Green else Amber, fontSize = 17.sp)
                Spacer(Modifier.width(5.dp))
                Text(deviceStatus, color = TextMain, fontSize = 12.sp)
                Spacer(Modifier.width(18.dp))
                Text("—   □   ✕", color = TextMain, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            }

            if (selectedPage == "Home") {
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    ToolTile("Select Firmware", Icons.Default.FolderOpen, Modifier.weight(1f)) { picker.launch("*/*") }
                    ToolTile("Open Folder", Icons.Default.Folder, Modifier.weight(1f)) { log("Use Select Firmware to choose a package.") }
                    ToolTile("Options", Icons.Default.Settings, Modifier.weight(1f)) { selectedPage = "Settings" }
                    ToolTile("Refresh", Icons.Default.Refresh, Modifier.weight(1f)) {
                        val manager = context.getSystemService(Context.USB_SERVICE) as UsbManager
                        val devices = manager.deviceList.values
                        if (devices.isNotEmpty()) {
                            deviceStatus = "USB detected"
                            deviceName = devices.joinToString { "USB ${it.vendorId.toString(16)}:${it.productId.toString(16)}" }
                            log("USB device(s) detected: $deviceName. Protocol identification is pending.")
                        } else {
                            deviceStatus = "Not connected"
                            deviceName = "Waiting for USB device"
                            log("No USB host device found.")
                        }
                    }
                    ToolTile("Clear Log", Icons.Default.DeleteSweep, Modifier.weight(1f)) { logLines = listOf("Log cleared.") }
                    DeviceBadge(deviceStatus, deviceName, Modifier.weight(1.45f))
                }

                Row(Modifier.weight(1f).fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Column(Modifier.weight(1.55f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        PanelCard("Firmware & Flash Options", Modifier.weight(1.1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Label("Platform")
                                listOf("MediaTek", "Qualcomm", "Fastboot", "Mi Assistant").forEach { p ->
                                    FilterChip(selected = selectedPlatform == p, onClick = { selectedPlatform = p; log("Platform selected: $p") }, label = { Text(p, fontSize = 10.sp) }, modifier = Modifier.padding(end = 3.dp), colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Blue, labelColor = TextMain, selectedLabelColor = Color.White))
                                }
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Label("Brand")
                                CompactDrop(selectedBrand, listOf("Auto Detect", "Samsung", "Xiaomi", "Google", "OnePlus", "Motorola", "Oppo", "Vivo", "Realme", "Other")) { selectedBrand = it }
                                Spacer(Modifier.width(8.dp))
                                Label("Model")
                                CompactDrop(selectedModel, listOf("Select model", "Pixel 6a", "Galaxy A54", "Redmi Note 10 Pro", "Other / manual")) { selectedModel = it }
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Label("Operation")
                                CompactDrop(operation, listOf("Flash Firmware", "Erase Selected", "Wipe Data", "Read Partition Table", "Backup Selected", "Restore Backup", "Create Partition")) { operation = it }
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Label("Flash Mode")
                                listOf("Normal", "Force").forEach { mode ->
                                    Row(Modifier.clickable { flashMode = mode }.padding(end = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                                        RadioButton(selected = flashMode == mode, onClick = { flashMode = mode }, colors = RadioButtonDefaults.colors(selectedColor = Cyan), modifier = Modifier.size(28.dp))
                                        Text(mode, color = TextMain, fontSize = 11.sp)
                                    }
                                }
                                Spacer(Modifier.width(8.dp))
                                Text("Firmware:", color = Muted, fontSize = 11.sp)
                                Text(firmware, color = TextMain, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f).padding(start = 5.dp))
                                Button(onClick = { picker.launch("*/*") }, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp), colors = ButtonDefaults.buttonColors(containerColor = Blue)) { Text("Browse", fontSize = 10.sp) }
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                var autoReboot by remember { mutableStateOf(true) }
                                var skipEfs by remember { mutableStateOf(false) }
                                var backupEfs by remember { mutableStateOf(false) }
                                var verify by remember { mutableStateOf(true) }
                                CheckOpt("Auto Reboot", autoReboot) { autoReboot = it }
                                CheckOpt("Skip EFS", skipEfs) { skipEfs = it }
                                CheckOpt("Backup EFS", backupEfs) { backupEfs = it }
                                CheckOpt("Verify", verify) { verify = it }
                            }
                            Text("Safety gate: destructive actions remain disabled until a real device-specific protocol, package parser and compatibility checks are implemented.", color = Amber, fontSize = 9.sp)
                        }
                        PanelCard("Partition Table · Preview", Modifier.weight(1f)) {
                            Row(Modifier.fillMaxWidth().background(Color(0xFF173A68)).padding(5.dp)) {
                                listOf("Select", "Partition", "File", "Start", "End", "Location").forEachIndexed { i, s ->
                                    Text(s, color = Cyan, fontSize = 9.sp, modifier = Modifier.weight(listOf(.55f,1f,1.2f,.8f,.8f,1.2f)[i]))
                                }
                            }
                            val rows = listOf("boot" to "boot.img", "recovery" to "recovery.img", "system" to "system.img", "vendor" to "vendor.img", "userdata" to "userdata.img")
                            rows.forEach { (name, file) ->
                                Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                                    var checked by remember(name) { mutableStateOf(name != "userdata") }
                                    Checkbox(checked, { checked = it }, modifier = Modifier.size(23.dp), colors = CheckboxDefaults.colors(checkedColor = Blue))
                                    Text(name, color = TextMain, fontSize = 9.sp, modifier = Modifier.weight(1f))
                                    Text(file, color = Muted, fontSize = 9.sp, modifier = Modifier.weight(1.2f))
                                    Text("—", color = Muted, fontSize = 9.sp, modifier = Modifier.weight(.8f))
                                    Text("—", color = Muted, fontSize = 9.sp, modifier = Modifier.weight(.8f))
                                    Text("Not parsed", color = Muted, fontSize = 9.sp, modifier = Modifier.weight(1.2f))
                                }
                            }
                            Text("Preview rows only — actual GPT/partition data must come from the connected device or parsed firmware.", color = Muted, fontSize = 9.sp)
                        }
                    }

                    Column(Modifier.weight(.92f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        PanelCard("Device Information", Modifier.weight(.95f)) {
                            InfoLine("Connection", deviceStatus)
                            InfoLine("Device", deviceName)
                            InfoLine("Platform", selectedPlatform)
                            InfoLine("Brand / Model", "$selectedBrand / $selectedModel")
                            InfoLine("Transport", "USB host · protocol pending")
                            InfoLine("Battery / Android", "Not available")
                        }
                        PanelCard("Quick Actions", Modifier.weight(.65f)) {
                            listOf("Read GPT", "Backup Selected", "Erase Selected", "Wipe Data", "Create Partition").forEach { action ->
                                OutlinedButton(onClick = { log("$action requested. Safety validation required; no device command was sent.") }, modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp), contentPadding = PaddingValues(4.dp), colors = ButtonDefaults.outlinedButtonColors(contentColor = TextMain)) {
                                    Text(action, fontSize = 10.sp)
                                }
                            }
                        }
                    }
                }

                Row(Modifier.fillMaxWidth().height(66.dp).padding(top = 7.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    BigAction("⚡  START FLASH", Green, Modifier.weight(1.2f)) {
                        log("Start requested for $operation. This build is a UI and workflow foundation; flashing backend is not yet implemented.")
                        queue = listOf("Blocked safely: no verified device protocol / firmware parser.")
                    }
                    BigAction("Ⅱ  PAUSE", Amber, Modifier.weight(.8f)) { log("Pause requested. No active flash job.") }
                    BigAction("■  STOP", Red, Modifier.weight(.8f)) { isRunning = false; log("Stop requested. No active flash job.") }
                }

                Row(Modifier.weight(.78f).fillMaxWidth().padding(top = 7.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PanelCard("Flash Log / Status", Modifier.weight(1.55f)) {
                        LazyColumn(Modifier.fillMaxSize()) { items(logLines) { Text(it, color = if (it.contains("Blocked") || it.contains("not") || it.contains("pending")) Amber else Color(0xFFD8E9FF), fontSize = 10.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace, modifier = Modifier.padding(vertical = 1.dp)) } }
                    }
                    PanelCard("Progress", Modifier.weight(.8f)) {
                        Text(if (isRunning) "Running" else "Idle", color = TextMain, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Text("${(progress * 100).toInt()}%", color = TextMain, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                        LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth(), color = Cyan, trackColor = Color(0xFF24446C))
                        Text(queue.firstOrNull() ?: "No queued operation", color = Muted, fontSize = 9.sp)
                    }
                }
            } else {
                PanelCard(selectedPage, Modifier.fillMaxSize().padding(top = 8.dp)) {
                    Text(pageDescription(selectedPage), color = TextMain, fontSize = 14.sp)
                    Spacer(Modifier.height(10.dp))
                    when (selectedPage) {
                        "All Brands" -> Text("Brand families: Samsung · Xiaomi · Google Pixel · OnePlus · Motorola · Oppo · Vivo · Realme · Other", color = Cyan, fontSize = 12.sp)
                        "ADB Tools" -> Text("Device reboot · shell · sideload · install APK · pull / push files (ADB host transport module required).", color = Muted)
                        "Fastboot Tools" -> Text("Reboot bootloader · reboot system · getvar · flash / erase (device and partition validation required).", color = Muted)
                        "Recovery Tools" -> Text("Recovery reboot · sideload · recovery image workflow. Only use images matching the exact model and build.", color = Muted)
                        "IMEI Tools" -> Text("Read-only diagnostics and lawful device identity support. IMEI alteration is not provided.", color = Muted)
                        "Utilities" -> Text("Firmware checksum · package inspection · log export · driver / connection diagnostics.", color = Muted)
                        "Settings" -> Text("Landscape workspace · confirmation prompts · log retention · theme selection. More settings can be added as backend modules mature.", color = Muted)
                        else -> Text("Universal Multi Flashing Tool · Android Studio starter project · Version 1.0.0", color = Muted)
                    }
                }
            }
        }
    }
}

@Composable
private fun navIcon(name: String) = when (name) {
    "Home" -> Icons.Default.Home
    "All Brands" -> Icons.Default.PhoneAndroid
    "ADB Tools" -> Icons.Default.Android
    "Fastboot Tools" -> Icons.Default.Bolt
    "Recovery Tools" -> Icons.Default.Refresh
    "IMEI Tools" -> Icons.Default.Fingerprint
    "Utilities" -> Icons.Default.Build
    "Settings" -> Icons.Default.Settings
    else -> Icons.Default.Info
}

@Composable
private fun ToolTile(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Column(modifier.height(62.dp).background(Brush.verticalGradient(listOf(Color(0xFF123D75), Color(0xFF091E3D))), RoundedCornerShape(10.dp)).border(1.dp, Cyan.copy(.45f), RoundedCornerShape(10.dp)).clickable { onClick() }.padding(5.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(icon, null, tint = Cyan, modifier = Modifier.size(23.dp))
        Text(title, color = TextMain, fontSize = 9.sp, maxLines = 1)
    }
}

@Composable
private fun DeviceBadge(status: String, name: String, modifier: Modifier) {
    Row(modifier.height(62.dp).background(Panel, RoundedCornerShape(10.dp)).border(1.dp, Cyan.copy(.35f), RoundedCornerShape(10.dp)).padding(7.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.PhoneAndroid, null, tint = Cyan, modifier = Modifier.size(28.dp))
        Spacer(Modifier.width(6.dp))
        Column {
            Text(status, color = if (status == "Connected") Green else Amber, fontWeight = FontWeight.Bold, fontSize = 11.sp)
            Text(name, color = TextMain, fontSize = 9.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun PanelCard(title: String, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.background(Brush.verticalGradient(listOf(Color(0xFF0D2A52), Color(0xFF081B36))), RoundedCornerShape(11.dp)).border(1.dp, Cyan.copy(.48f), RoundedCornerShape(11.dp)).padding(9.dp)) {
        Text(title, color = TextMain, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        HorizontalDivider(color = Cyan.copy(.3f), modifier = Modifier.padding(vertical = 5.dp))
        content()
    }
}

@Composable
private fun Label(text: String) { Text(text, color = Muted, fontSize = 10.sp, modifier = Modifier.width(75.dp)) }

@Composable
private fun CompactDrop(value: String, options: List<String>, onSelect: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        Surface(color = Color(0xFF102D57), shape = RoundedCornerShape(6.dp), modifier = Modifier.widthIn(min = 105.dp).clickable { expanded = true }.border(1.dp, Cyan.copy(.35f), RoundedCornerShape(6.dp))) {
            Row(Modifier.padding(horizontal = 8.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(value, color = TextMain, fontSize = 10.sp, maxLines = 1, modifier = Modifier.weight(1f, fill = false))
                Icon(Icons.Default.ArrowDropDown, null, tint = Cyan, modifier = Modifier.size(16.dp))
            }
        }
        DropdownMenu(expanded, { expanded = false }) {
            options.forEach { opt -> DropdownMenuItem(text = { Text(opt, fontSize = 12.sp) }, onClick = { onSelect(opt); expanded = false }) }
        }
    }
}

@Composable
private fun CheckOpt(text: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.clickable { onChange(!checked) }.padding(end = 9.dp), verticalAlignment = Alignment.CenterVertically) {
        Checkbox(checked, onChange, modifier = Modifier.size(24.dp), colors = CheckboxDefaults.colors(checkedColor = Blue))
        Text(text, color = TextMain, fontSize = 9.sp)
    }
}

@Composable
private fun InfoLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(label, color = Muted, fontSize = 10.sp, modifier = Modifier.weight(.8f))
        Text(value, color = TextMain, fontSize = 10.sp, modifier = Modifier.weight(1.2f))
    }
}

@Composable
private fun BigAction(title: String, color: Color, modifier: Modifier, onClick: () -> Unit) {
    Button(onClick = onClick, modifier = modifier.fillMaxHeight(), shape = RoundedCornerShape(12.dp), colors = ButtonDefaults.buttonColors(containerColor = color), contentPadding = PaddingValues(6.dp)) {
        Text(title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Black)
    }
}

private fun pageDescription(page: String) = when (page) {
    "All Brands" -> "Select a supported manufacturer and exact model before loading firmware."
    "ADB Tools" -> "ADB utilities workspace. Requires an implemented ADB-over-USB transport."
    "Fastboot Tools" -> "Fastboot workspace. Commands must be validated against the connected product."
    "Recovery Tools" -> "Recovery and sideload workspace."
    "IMEI Tools" -> "Device identity diagnostics. IMEI rewriting is intentionally excluded."
    "Utilities" -> "Package checks, hashes, logs and connection utilities."
    "Settings" -> "Application preferences and safety controls."
    else -> "About this application."
}
