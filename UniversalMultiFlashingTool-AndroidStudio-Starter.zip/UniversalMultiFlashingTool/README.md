# Universal Multi Flashing Tool — Android Studio Starter

A new Android Studio project based on the supplied two reference mockups.

## Included
- Landscape-first Windows/PC-style dashboard
- Left navigation: Home, All Brands, ADB, Fastboot, Recovery, IMEI, Utilities, Settings, About
- Platform selector: MediaTek, Qualcomm, Fastboot, Mi Assistant
- Firmware file picker, operation/mode selectors, EFS/verification options
- Partition table preview, device information panel, quick-action controls
- Live local operation log and progress panel
- Basic USB-host device enumeration through Android `UsbManager`

## Open
1. Extract the ZIP.
2. Open the `UniversalMultiFlashingTool` folder in Android Studio.
3. Use JDK 17.
4. Allow Gradle sync; Android SDK Platform 35 is required.
5. Run on an Android device/tablet that supports USB host/OTG.

## Important implementation boundary
This is a functional UI/workflow foundation, **not yet a universal flashing engine**. The Start/Erase/Wipe/Partition actions deliberately do not send destructive commands. The partition rows are preview placeholders, not parsed GPT data. USB enumeration does not identify a phone model or establish ADB, Fastboot, MediaTek BROM/Preloader, Qualcomm EDL/Firehose, Samsung Download Mode, or Xiaomi authentication sessions.

Real flashing support requires separate, tested protocol backends and model-specific compatibility checks, firmware parsers, signed/authenticated loaders where required, and safe recovery/error handling. Do not use this starter to flash a device. The project does not bypass OEM security or account authentication.

## Next engineering modules
- ADB host transport and device state machine
- Fastboot protocol transport and partition metadata
- MediaTek preloader/BROM transport with supported DA packages
- Qualcomm EDL Sahara/Firehose transport with authorized programmer packages
- Firmware package parsers (scatter, rawprogram/patch XML, payload, sparse images, OEM packages)
- GPT reader/parser and verified partition backup/restore
- Job queue, cancellation, checksum verification, persistent logs
- Per-device capability matrix and safety confirmation gates

## Build note
Gradle dependency resolution and compilation must be verified in Android Studio with network access and Android SDK installed. This environment did not run an Android Gradle build.
