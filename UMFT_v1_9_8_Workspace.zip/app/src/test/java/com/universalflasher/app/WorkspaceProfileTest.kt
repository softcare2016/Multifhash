package com.universalflasher.app

import com.universalflasher.app.workspace.SamsungSlot
import com.universalflasher.app.workspace.SamsungSlots
import com.universalflasher.app.workspace.WorkspaceKind
import com.universalflasher.app.workspace.WorkspaceProfile
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.security.MessageDigest

class WorkspaceProfileTest {
    @Test fun chipsetIdsOutrankBrandText() {
        assertEquals(WorkspaceKind.QUALCOMM, WorkspaceProfile.fromUsb(0x05c6, 0x9008, "Samsung", "Samsung").kind)
        assertEquals(WorkspaceKind.MEDIATEK, WorkspaceProfile.fromUsb(0x0e8d, 0x0003, "Xiaomi").kind)
        assertEquals(WorkspaceKind.SAMSUNG, WorkspaceProfile.fromUsb(0x04e8, 0x6860, "").kind)
    }
    @Test fun brandTextIsOnlyAHint() {
        assertEquals(WorkspaceKind.XIAOMI, WorkspaceProfile.fromUsb(0x18d1, 0x4ee0, "Redmi Note").kind)
        assertEquals(WorkspaceKind.REALME, WorkspaceProfile.fromUsb(0x18d1, 0x4ee0, "", "Realme").kind)
        val other = WorkspaceProfile.fromUsb(0x1234, 0x5678, "")
        assertEquals(WorkspaceKind.OTHER, other.kind)
        assertTrue(other.evidence.contains("No brand evidence"))
    }
    @Test fun disconnectKeepsWorkspaceAsHistory() {
        val live = WorkspaceProfile.fromUsb(0x04e8, 0x685d, "Samsung")
        assertTrue(live.live)
        val gone = WorkspaceProfile.disconnected(live)!!
        assertEquals(WorkspaceKind.SAMSUNG, gone.kind)
        assertFalse(gone.live)
        assertTrue(WorkspaceProfile.statusLine(gone).startsWith("DISCONNECTED"))
        assertNull(WorkspaceProfile.disconnected(null))
        assertTrue(WorkspaceProfile.statusLine(null).contains("QUALCOMM"))
    }
    @Test fun slotClassificationAndConflicts() {
        assertEquals(SamsungSlot.HOME_CSC, SamsungSlots.classify("HOME_CSC_OXM.tar.md5"))
        assertEquals(SamsungSlot.CSC, SamsungSlots.classify("csc_oxm.tar.md5"))
        assertNull(SamsungSlots.classify("fw.zip"))
        assertTrue(SamsungSlots.validateSet(mapOf(SamsungSlot.CSC to "CSC_a.tar.md5", SamsungSlot.HOME_CSC to "HOME_CSC_a.tar.md5")).any { it.contains("mutually exclusive") })
        assertTrue(SamsungSlots.validateSet(mapOf(SamsungSlot.AP to "BL_a.tar.md5")).any { it.contains("looks like a BL") })
    }
    private fun md5(b: ByteArray) = MessageDigest.getInstance("MD5").digest(b).joinToString("") { "%02x".format(it) }
    @Test fun md5TrailerStreaming() {
        val body = ByteArray(5000) { (it % 251).toByte() }
        assertEquals(true, SamsungSlots.verifyTarMd5((body + "${md5(body)}  AP_x.tar\n".toByteArray()).inputStream()).verified)
        assertEquals(false, SamsungSlots.verifyTarMd5((body + "${md5(body).reversed()}  AP_x.tar\n".toByteArray()).inputStream()).verified)
        assertNull(SamsungSlots.verifyTarMd5(ByteArray(2048).inputStream()).verified)
    }
}
