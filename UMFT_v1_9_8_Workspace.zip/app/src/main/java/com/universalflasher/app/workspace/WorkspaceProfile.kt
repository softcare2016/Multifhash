package com.universalflasher.app.workspace

import java.io.InputStream
import java.security.MessageDigest

/**
 * Pure-Kotlin logic for the single dynamic Home flashing workspace.
 * A profile is a UI/workflow selection only. It never proves protocol compatibility and never
 * enables a write; destructive operations stay behind the existing engine and Flash gates.
 */
enum class WorkspaceKind(val title: String, val protocol: String, val note: String) {
    QUALCOMM("QUALCOMM", "Sahara / Firehose", "Requires an exact-model OEM programmer validated by SHA-256. EDL is not available on every device and no authorization bypass is provided."),
    SAMSUNG("SAMSUNG", "Odin-style Download Mode", "Handshake, packet codec and PIT parsing exist; full firmware transfer is not complete. Slots are inspected and MD5-checked only."),
    XIAOMI("XIAOMI", "Mi Flash-style Fastboot ROM", "Fastboot diagnostics only; locked bootloaders are not bypassed."),
    MEDIATEK("MEDIATEK", "BROM / Scatter / DA", "Needs an OEM-authorized DA; SLA/DAA/secure boot are not bypassed. DA storage data flow is not complete."),
    VIVO("VIVO", "Vivo workflow", "No Vivo-specific protocol is implemented. Chipset protocol must be identified first."),
    OPPO("OPPO", "Oppo workflow", "No Oppo-specific protocol is implemented. Chipset protocol must be identified first."),
    REALME("REALME", "Realme workflow", "No Realme-specific protocol is implemented. Chipset protocol must be identified first."),
    OTHER("OTHER", "Verified compatible workflow", "Brand alone does not prove protocol compatibility.")
}

data class WorkspaceSnapshot(
    val kind: WorkspaceKind,
    val usbId: String,
    val descriptor: String,
    val evidence: String,
    val live: Boolean
)

object WorkspaceProfile {
    /** Workspace label shown before any device has ever been detected. */
    val DEFAULT = WorkspaceKind.QUALCOMM

    private fun hex(i: Int) = "%04X".format(i)

    /**
     * USB VID/PID and descriptor text are detection hints only. Chipset download-mode IDs win over
     * brand text; an explicit brand choice in the UI is used only when USB evidence is not decisive.
     */
    fun fromUsb(vendorId: Int, productId: Int, descriptor: String, selectedBrand: String = ""): WorkspaceSnapshot {
        val text = (descriptor + " " + selectedBrand).lowercase()
        fun has(vararg k: String) = k.any { text.contains(it) }
        val (kind, evidence) = when {
            vendorId == 0x05c6 && productId == 0x9008 -> WorkspaceKind.QUALCOMM to "USB 05C6:9008 (EDL hint)"
            vendorId == 0x0e8d && productId in setOf(0x0003, 0x2000, 0x2001) -> WorkspaceKind.MEDIATEK to "USB 0E8D (BROM/Preloader hint)"
            vendorId == 0x04e8 -> WorkspaceKind.SAMSUNG to "Samsung USB vendor ID (hint)"
            has("samsung") -> WorkspaceKind.SAMSUNG to "Descriptor/brand text (hint)"
            has("xiaomi", "redmi", "poco") -> WorkspaceKind.XIAOMI to "Descriptor/brand text (hint)"
            has("realme") -> WorkspaceKind.REALME to "Descriptor/brand text (hint)"
            has("oppo") -> WorkspaceKind.OPPO to "Descriptor/brand text (hint)"
            has("vivo", "iqoo") -> WorkspaceKind.VIVO to "Descriptor/brand text (hint)"
            else -> WorkspaceKind.OTHER to "No brand evidence"
        }
        return WorkspaceSnapshot(kind, hex(vendorId) + ":" + hex(productId), descriptor.trim(), evidence, true)
    }

    /** Disconnect keeps the brand workspace as history and marks it not live. */
    fun disconnected(last: WorkspaceSnapshot?): WorkspaceSnapshot? = last?.copy(live = false)

    fun statusLine(s: WorkspaceSnapshot?): String = when {
        s == null -> "No device detected yet. Default ${DEFAULT.title} workspace shown."
        !s.live -> "DISCONNECTED. Last: ${s.kind.title} (${s.usbId}). Writing disabled until a compatible device reconnects."
        else -> "CONNECTED. ${s.kind.title} workspace. ${s.evidence}."
    }
}

/** Samsung BL / AP / CP / CSC / HOME_CSC slots. Inspection and integrity checks only. */
enum class SamsungSlot(val label: String, val prefix: String) {
    BL("BL", "BL_"), AP("AP", "AP_"), CP("CP", "CP_"), CSC("CSC", "CSC_"), HOME_CSC("HOME_CSC", "HOME_CSC_")
}

object SamsungSlots {
    fun classify(fileName: String): SamsungSlot? {
        val n = fileName.uppercase()
        return SamsungSlot.values().firstOrNull { n.startsWith(it.prefix) }
    }

    fun validateSet(chosen: Map<SamsungSlot, String>): List<String> = buildList {
        if (SamsungSlot.CSC in chosen && SamsungSlot.HOME_CSC in chosen) add("CSC and HOME_CSC are mutually exclusive: CSC wipes user data, HOME_CSC preserves it.")
        chosen.forEach { (slot, name) ->
            val guess = classify(name)
            if (guess != null && guess != slot) add("${slot.label} slot holds '$name', which looks like a ${guess.label} file.")
            val l = name.lowercase()
            if (!(l.endsWith(".tar") || l.endsWith(".tar.md5") || l.endsWith(".md5"))) add("${slot.label}: '$name' is not a .tar / .tar.md5 file.")
        }
    }

    data class Md5Result(val verified: Boolean?, val message: String)

    private const val HOLD = 1024
    private val trailer = Regex("([0-9a-fA-F]{32})[ \\t]+[^\\r\\n]+\\s*$")

    /**
     * Streaming check of the MD5 trailer on *.tar.md5 content (for Uri streams that are not Files;
     * [com.universalflasher.app.samsung.SamsungPackageInspector.verifyTarMd5] covers File input).
     * verified = null means no trailer: integrity unverified, not failed. MD5 is integrity only,
     * never publisher trust.
     */
    fun verifyTarMd5(input: InputStream): Md5Result {
        val md = MessageDigest.getInstance("MD5")
        var held = ByteArray(0)
        val buf = ByteArray(64 * 1024)
        while (true) {
            val n = input.read(buf)
            if (n < 0) break
            if (n == 0) continue
            val combined = held + buf.copyOf(n)
            if (combined.size > HOLD) {
                md.update(combined, 0, combined.size - HOLD)
                held = combined.copyOfRange(combined.size - HOLD, combined.size)
            } else held = combined
        }
        val m = trailer.find(String(held, Charsets.ISO_8859_1)) ?: return Md5Result(null, "No MD5 trailer; integrity unverified.")
        md.update(held, 0, m.range.first)
        val actual = md.digest().joinToString("") { "%02x".format(it) }
        val expected = m.groupValues[1].lowercase()
        return if (actual == expected) Md5Result(true, "MD5 matches trailer (integrity only).")
        else Md5Result(false, "MD5 MISMATCH: trailer $expected, computed $actual. Package corrupted or modified.")
    }
}
