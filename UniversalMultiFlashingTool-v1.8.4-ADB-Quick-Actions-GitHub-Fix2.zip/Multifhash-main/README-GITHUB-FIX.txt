# Universal Multi Flashing Tool v1.8.4 — GitHub Workflow Repair

This package contains:
- `.github/workflows/android-build.yml` — updated workflow with recursive nested-ZIP discovery.
- `UniversalMultiFlashingTool-v1.8.4-ADB-Quick-Actions.zip` — Android project archive.

IMPORTANT:
1. Upload/replace the workflow file at `.github/workflows/android-build.yml` in the GitHub repository.
2. Upload the Android project ZIP to the repository root.
3. Remove older project ZIP archives from the repository root to avoid stale archive selection.
4. Commit both changes, then run the workflow from Actions.

The supplied log showed GitHub was still executing the old one-level extraction script. Merely uploading the new ZIP without replacing the workflow will reproduce the same failure.
